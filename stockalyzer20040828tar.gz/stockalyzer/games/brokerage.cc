/**  brokerage.cc  ************************************************************* 


    The brokerage_o object acts as the stock broker in the game simulation.
    A trader_o can ask the broker to buy, sell, etc, the broker will allow/ 
    deny and record the transactions.  Since real brokers make mistakes,
    execute partial fills, and other unexpected events, this object will
    simulate these.


when      who   what
04.26.04  Dan   Creation.
04.29.04  Dan   Added.  Accounts.


Debug Level 5600-5699
*******************************************************************************/


#include "log/log.h"
#include "brokerage.h"
#include "game.h"
#include "analdata.h"


extern log_o logg;
extern game_o game;

brokerage_o::brokerage_o()  {
    State       = 0;
    TotalAssets = 0;
}

brokerage_o::~brokerage_o()  {}

#include <stdlib.h>
int brokerage_o::trade(int transaction,const char* traderId,symboldata_o* symbol,int price,int amount)  {
    string_o s;
    string_o message;
    trader_o* trader;
    position_o* position;
    bstreeSearch_o<trader_o> as(&Accounts);

    s = traderId;
    trader = (trader_o*)as.find(&s);
    if(!trader)  return -1;

    (message = "brokerage_o: ") << "Trader " << traderId;


    s = symbol->symbol();
    position = trader->Positions.first();
    while(position)  {
        if(s == position->symbol()->symbol())  break;
        position = trader->Positions.next();
    }
    if(!position)  return -2;


    if(transaction == ACTION_BUY)  {
        message << " buy limit ";
        trader->cash(trader->cash() - amount * price);
        position->Shares += amount;
    }
    if(transaction == ACTION_SELL)  {
        message << " sell limit ";
        trader->cash(trader->cash() + amount * price);
        position->Shares -= amount;
    }
    message << amount << " @ " << price;
    message << " symbol " << symbol->symbol();
//  message << " low " << ad->low() << " hi " << ad->high();
    message << " cash " << trader->cash() << " shares " << position->Shares;
    ::logg << message;



}

int brokerage_o::addAccount(const char* traderId)  {
    string_o s;
    trader_o* trader;
    bstreeSearch_o<trader_o> bst(&Accounts);

    if(!traderId)  return -1;

    s = traderId;
    trader = (trader_o*)bst.find(&s);
    if(trader)  {
        return -2;
    }

    trader = new trader_o;
    trader->Id = traderId;

    trader->cash(1000);
    Accounts.insert(traderId,trader);
    
}


list_o<position_o>* brokerage_o::traderPositions(const char* traderId)  {
    string_o s;
    list_o<position_o>* pl;
    trader_o* trader;
    bstreeSearch_o<trader_o> bst(&Accounts);

    s = traderId;
    trader = (trader_o*)bst.find(&s);
    if(!trader)  return NULL;

    pl = &trader->Positions;

    return pl;
}


void brokerage_o::displayTraderAccount(const char* traderId,string_o& message)  {
    string_o date;
    string_o t;
    string_o s;
    trader_o* trader;
    bstreeSearch_o<trader_o> bst(&Accounts);
    position_o* position;
    int value;

    analdata_o* ad;
    bstree_o<analdata_o>* adt;
    bstreeSearch_o<analdata_o>* sadt;



    t = traderId;
    trader = (trader_o*)bst.find(&t);
    if(!trader)  return;

    value = trader->cash();
    t.justifyRight(5);
    message << "brokerage_o:traderid " << t << "$";

    (t = "") << trader->cash();
    t.justifyRight(9);
    s << t << ":cash ";
    position = trader->Positions.first();
    while(position)  {
        if(position->Shares > 0)  {
adt = (bstree_o<analdata_o>*)position->Symbol->voidp();
sadt = new bstreeSearch_o<analdata_o>(adt);
(date = "") << game.date();
ad = (analdata_o*)sadt->find(&date);
value += ad->close() * position->shares();

            (t = "") << position->shares();
            s << t << ":";
            t = position->symbol()->symbol();
            t.justifyLeft(4);
            s << t << " ";
        }
        position = trader->Positions.next();
    }

    (t = "") << value;
    t.justifyRight(9);
    message << t << " |" << s;

    TotalAssets += value;
}



/******************************************************************************/
