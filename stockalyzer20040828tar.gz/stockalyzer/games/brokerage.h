/**  brokerage.h  **************************************************************


    The brokerage_o object acts as the stock broker in the game simulation.
    A trader_o can ask the broker to buy, sell, etc, the broker will allow/
    deny and record the transactions.  Since real brokers make mistakes,
    execute partial fills, and other unexpected events, this object will
    simulate these.


when      who   what
04.26.04  Dan   Creation.
04.29.04  Dan   Added.  Binary Search Tree Accounts of trader_o objects.


Debug Level 5600-5699
*******************************************************************************/


#ifndef BROKERAGEOBJECT_H
#define BROKERAGEOBJECT_H

#include "string/string.h"
#include "memory/bstree.h"
#include "trader.h"
#include "symboldata.h"

#define ACTION_BUY 2
#define ACTION_SELL 3

#define BROKERAGEOBJECT_BUY_LIMIT 2
#define BROKERAGEOBJECT_SELL_LIMIT 3

class brokerage_o  {
  private:
    int                State;
    bstree_o<trader_o> Accounts;

    long int           TotalAssets;


  public:
    brokerage_o();
    brokerage_o(const brokerage_o&);
   ~brokerage_o();
    brokerage_o& operator = (const brokerage_o&);

    int state() const;


    int trade(int transaction,const char* traderId,symboldata_o*,int price,int amount);


    int addAccount(const char* traderId);

    list_o<position_o>* traderPositions(const char* traderId);

    void displayTraderAccount(const char* traderId,string_o&);

    long int totalAssets() const;
    int totalNumberOfTraders() const;
};

/******************************************************************************/

inline int brokerage_o::state() const  {
    return State;
}

inline long int brokerage_o::totalAssets() const  {
    return TotalAssets;
}

inline int brokerage_o::totalNumberOfTraders() const  {
    return Accounts.cardinality();
}


#endif

/******************************************************************************/
