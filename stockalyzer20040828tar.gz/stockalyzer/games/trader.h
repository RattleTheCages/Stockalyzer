/**  trader.h  *****************************************************************


when      who   what
04.24.04  Dan   Creation.



Debug Level  5600-5699
*******************************************************************************/


#ifndef TRADEROBJECT_H
#define TRADEROBJECT_H

#include "string/string.h"
#include "symboldata.h"


#define TRADERULEOBJECT_ACTION_BUY 1
#define TRADERULEOBJECT_ACTION_SELL 2


class traderule_o  {
  friend class trader_o;
  friend class game_o;
  private:
    int Rule;
    int StopLoss;
    int Volume;
    int Price;
    int Amount;
    int Action;

  public:
    traderule_o();
    traderule_o(const traderule_o&);
   ~traderule_o();
    traderule_o& operator = (const traderule_o&);
};


class position_o  {
  friend class game_o;
  friend class brokerage_o;
  private:
    symboldata_o* Symbol;
    int Shares;
    traderule_o* TradeRule;

  public:
    position_o();
    position_o(const position_o&);
   ~position_o();
    position_o& operator = (const position_o&);

    symboldata_o* symbol();
    int shares();
};


class trader_o  {
  private:
public:
    string_o Id;
    int Cash;
    list_o<position_o> Positions;


  public:
    trader_o();
    trader_o(const trader_o&);
   ~trader_o();
    trader_o& operator = (const trader_o&);

    void operator << (const char*);
    void operator >> (string_o&);

    int cash() const;
    void cash(int);

    const char* id() const;
};

/******************************************************************************/


inline symboldata_o* position_o::symbol()  {
    return Symbol;
}

inline int position_o::shares()  {
    return Shares;
}


inline int trader_o::cash() const  {
    return Cash;
}


inline void trader_o::cash(int c)  {
    Cash = c;
}

inline const char* trader_o::id() const  {
    return Id.string();
}

#endif

/******************************************************************************/
