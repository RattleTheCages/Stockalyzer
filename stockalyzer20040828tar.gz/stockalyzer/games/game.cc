/**  game.cc  ******************************************************************


changes log
when      who   what
04.24.04  Dan   Creation.
04.29.04  Dan   Added.  List of trader ids.


Debug Level 5000-5499

*******************************************************************************/

#include <fstream.h>

#include "other/sysinfo.h"
#include "log/log.h"
#include "game.h"
#include "brokerage.h"


sysinfo_o sysinfo;
log_o logg;
game_o game;
brokerage_o brokerage;


game_o::game_o()  {
    State = GAMEOBJECT_STATE_CLEAR;

    Date = 20011017;
}

game_o::~game_o()  {}


int game_o::setup()  {
    int      x;
    int      ret;
    int      index;
    string_o s;
    string_o message;
    string_o* traderId;
    symboldata_o* symbol;


    ret = Symbols.directory();
    ret = Symbols.merge();

    AdArray = new analdata_o*[Symbols.cardinality()];

    for(index=0;index<Symbols.cardinality();index++)  AdArray[index] = 0;

    symbol = Symbols.first();
    while(symbol)  {

        loadAnaldata(symbol);

        symbol = Symbols.next();
    }


    Traders.put(new string_o("Jay"));
    Traders.put(new string_o("Scott"));
    Traders.put(new string_o("Jill"));
    Traders.put(new string_o("Ray"));
    Traders.put(new string_o("Mike"));

    for(x=0;x<250;x++)  {
        (s = "") << "Trader" << x;
        Traders.put(new string_o(s.string()));
    }

    traderId = Traders.first();
    while(traderId)  {

        brokerage.addAccount(traderId->string());

        traderId = Traders.next();
    }

    return 0;
}


int game_o::loadAnaldata(symboldata_o* symb)  {
    int x;
string_o s;
    string_o message;
    string_o filename;
    analdata_o* ad;
    char buffer[2048];
    ifstream in;
    bstree_o<analdata_o>* adt;

    list_o<analdata_o> list;
    list_o<analdata_o> list2;
    list_o<analdata_o>* adl;
bstreeSearch_o<analdata_o>* ss;

    if(!symb)  {
        State = GAMEOBJECT_STATE_VOID;
        return State;
    }

    filename = Symbols.dirname();
    filename << '/' << symb->symbol();
    filename << ".analdata_o";
    in.open(filename.string());
    if(!in)  {
        State = GAMEOBJECT_STATE_VOID;

        (message = "game_o: ")  << "Analdata file \"" << filename << "\" missing.";
        ::logg.error(message);

        return State;
    }

    adt = new bstree_o<analdata_o>;

    for(int x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        ad = new analdata_o;
        *ad << buffer;
        list.put(ad);

        (s ="")<< ad->date();
        adt->insert(s,ad);
    }
    in.close();



/*
    adl = new list_o<analdata_o>;

    symb->voidp((void*)list.first());
    x = list.cardinality();
    while(adl->cardinality() < x)  {
        ad = list.get();
        while(list.cardinality())  {
            list2.put(ad);
            ad = list.get();
        }
        adl->put(ad);
        ad = list2.get();
        while(list2.cardinality())  {
            list.put(ad);
            ad = list2.get();
        }
        list.put(ad);
    }
*/



    if(::logg.debug(4609))  {
        (message = "game_o: ")  << "Analdata file \"" << filename << "\" loaded ";
        message << adl->cardinality() << " dates.";
        ::logg << message;
    }

    AnaldataTree.insert(symb->symbol(),adl);

    symb->voidp((void*)adt);

    return State;
}

int game_o::move()  {
    int x;
    int index;
    string_o s;
    string_o message;
    analdata_o* ad;
    symboldata_o* symbol;
    bstreeSearch_o<list_o<analdata_o> >  treeSearch(&AnaldataTree);
    bstreeSearch_o<analdata_o>*  adts;


    if(::logg.debug(5020))  {
        (message = "game_o: ")  << "move() " << Date;
        ::logg << message;
    }

    index = 0;
    symbol = Symbols.first();
    while(symbol)  {
        adts = new bstreeSearch_o<analdata_o>((bstree_o<analdata_o>*)symbol->voidp());
        (s = "") << Date;
        ad = (analdata_o*)adts->find(&s);
        delete adts;


        AdArray[index] = ad;

//        index++;
        symbol = Symbols.next();
    }


/*
    x = ad->support();
    x = x + rand();
    ad->support(x);

    x = ad->dsupport();
    x = x + rand();
    ad->support(x);
*/


    return 0;
}


int game_o::executePreviousDaysTradeRules(const char* traderId)  {
    string_o s;
    string_o message;
    int index;
    symboldata_o* symbol;
    analdata_o* ad;
    position_o* position;
    list_o<position_o>* pl;
    bstreeSearch_o<analdata_o>*  adts;

    if(::logg.debug(5030))  {
        (message = "game_o: ")  << "executePreviousDaysTradeRules(" << traderId << ") ";
        ::logg << message;
    }

    pl = brokerage.traderPositions(traderId);

    if(pl)  {
        position = pl->first();
        while(position)  {

            if(::logg.debug(5031))  {
                (message = "game_o: ")  << "executePreviousDaysTradeRules(" << traderId << ") ";
                message << "Checking position " << position->symbol()->symbol();
                ::logg << message;
            }

            index = 0;
            symbol = Symbols.first();
            while(symbol)  {
                s = symbol->symbol();
                if(s == position->Symbol->symbol())  break;
                index++;
                symbol = Symbols.next();
            }
            if(!symbol)  return 0;

            adts = new bstreeSearch_o<analdata_o>((bstree_o<analdata_o>*)symbol->voidp());
            (s = "") << Date;
(message = "")<<"Looking for `" << s <<"' on tree.";
::logg<<message;
            ad = (analdata_o*)adts->find(&s);

/*
s="XX";
        ad = (analdata_o*)adts->find(&s);
*/
if(!ad)  {
(message = "")<<"Not found.";
::logg<<message;
}
if(ad)  {
(message = "")<<"found.";
::logg<<message;
}
            delete adts;

        //ad = AdArray[index];

            if(ad)  {
                if(position->TradeRule && position->TradeRule->Rule == 0)  {
if(::logg.debug(5035))  {
(message = "game_o: ")  << "executePreviousDaysTradeRules(" << traderId << ") ";
message << " ad->low " << ad->low() << " ad->hi " << ad->high() << " price " << position->TradeRule->Price;
::logg << message;
}
                    if((ad->low() < position->TradeRule->Price) &&
                       (position->TradeRule->Price < ad->high()))  {

brokerage.trade(position->TradeRule->Action,traderId,symbol,position->TradeRule->Price,100);

delete position->TradeRule;
position->TradeRule = NULL;
                    }

                }
            }

            position = pl->next();
        }
    }


    return 0;
}


int game_o::createTodaysTradeRules(const char* traderId)  {
    int      x,y;
    string_o s;
    string_o message;
    symboldata_o* symbol;
    analdata_o* ad;
    position_o* position;
    list_o<position_o>* pl;

    if(::logg.debug(5040))  {
        (message = "game_o: ")  << "createTodaysTradeRules(" << traderId << ") ";
        ::logg << message;
    }


    pl = brokerage.traderPositions(traderId);
    if(!pl)  {
        (message = "game_o: ")  << "createTodaysTradeRules(" << traderId << ") ";
        message << ": Trader account not found?";
        ::logg.error(message);

        return -1;
    }

    position = pl->first();
    while(position)  {
        if(::logg.debug(5041))  {
            (message = "game_o: ")  << "createTodaysTradeRules(" << traderId << ") ";
            message << "exam position " << position->symbol()->symbol();
            ::logg << message;
        }

        if(position->Shares > 0)  {
            if(rnd(5) == 1)  {
                if(::logg.debug(5045))  {
                    (message = "game_o: ")  << "createTodaysTradeRules(" << traderId << ") ";
                    message << "Creating new sell order.";
                    ::logg << message;
                }


                if(!position->TradeRule)  {
                    position->TradeRule = new traderule_o;

                    if(::logg.debug(5045))  {
                        (message = "game_o: ")<<"createTodaysTradeRules("<< traderId << ") ";
                        message << "Creating new traderule_o.";
                        ::logg << message;
                    }
                }

                position->TradeRule->Action = ACTION_SELL;
                position->TradeRule->Price  = 1410;
                position->TradeRule->Price  = rnd(4444);
                position->TradeRule->Amount = 100;
                position->TradeRule->Rule   = 0;


                if(::logg.debug(5045))  {
                    (message = "game_o: ") << "Creating new sell order for ";
                    message << position->symbol()->symbol();
                    message << " @ price " << position->TradeRule->Price;
                    ::logg << message;
                }
            }
        }


        position = pl->next();
    }


    if(rnd(5) == 1)  {
        x = rnd(Symbols.cardinality());
        symbol = Symbols.first();
        for(y=0;y<x;y++)  symbol = Symbols.next();


        position = pl->first();
        while(position)  {
            s = symbol->symbol();
            if(s == position->symbol()->symbol())  break;
            position = pl->next();
        }

        if(!position)  {

            position = new position_o;
            position->Symbol = symbol;

            position->TradeRule = new traderule_o;


            position->TradeRule->Action = ACTION_BUY;
            position->TradeRule->Price  = 1410;
            position->TradeRule->Price  = rnd(9999);
            position->TradeRule->Amount = 100;
            position->TradeRule->Rule   = 0;


            if(::logg.debug(5045))  {
                (message = "game_o: ")  << "Creating new buy order for " << symbol->symbol();
                message << " @ price " << position->TradeRule->Price;
                ::logg << message;
            }

            pl->put(position);
        }
    }


    return 0;
}

int game_o::decide()  {
    int index;
    string_o message;
    symboldata_o* symbol;
    symboldata_o* bestsymbol;
    analdata_o* bestad;
    traderule_o* traderule;
    position_o* position;

    if(::logg.debug(5050))  {
        (message = "game_o: ")  << "decide()";
        ::logg << message;
    }

    //prevDayRuleTrade();


    index = 0;
    symbol = Symbols.first();
    bestad = AdArray[index];
    while(symbol)  {

        if(AdArray[index]->support() > bestad->support())  {
            bestad = AdArray[index];
            bestsymbol = symbol;
        }

        index++;
        symbol = Symbols.next();
    }


(message = "game_o: ") << "Symbol " << bestsymbol->symbol() << " is best.";
::logg << message;

/*
    if(Trader.symbol())  {
        if(rnd(10) > 8)  {
            (message = "game_o: ") << "Symbol " << bestsymbol->symbol() << " is best.";
            ::logg << message;
        }
    }
*/



    traderule = new traderule_o;
    traderule->StopLoss = rnd(2000);
    traderule->Volume = rnd(2000);
    traderule->Price = rnd((bestad->high()-bestad->low()))+bestad->low();
    traderule->Rule = rnd(2);

    position = new position_o;
    position->Symbol = bestsymbol;
    position->TradeRule = traderule;
    position->Shares = 100;

//    Trader.Cash = Trader.Cash - position->Shares * bestad->close();
//(message = "game_o: ") << "Trader Cash " << Trader.Cash;
//::logg << message;

//    Trader.Positions.put(position);

    return 0;
}

int game_o::rnd(int l)  {
    return  (((float)rand())/RAND_MAX)*l;
}


int game_o::play()  {
    string_o message;
    string_o s;
    int x;
    int ret;
    int index;
    symboldata_o* symbol;
    analdata_o* ad;
    bstreeSearch_o<list_o<analdata_o> >  treeSearch(&AnaldataTree);
    list_o<analdata_o>* adl;



/*
    index = 0;
    symbol = Symbols.first();
    while(symbol)  {
        s = symbol->symbol();
        adl = (list_o<analdata_o>*)treeSearch.find(&s);
        ad = adl->first();
        while(ad)  {
            AdArray[index] = ad;
            ad = adl->next();
        }
        index++;
        symbol = Symbols.next();
    }
*/


    while(2)  {


        if(::logg.debug(5011))  {
            (message = "game_o: ")  << "Gaming date " << Date;
            ::logg << message;
        }


/*
        index = 0;
        symbol = Symbols.first();
        while(symbol)  {
            if(::logg.debug(5012))  {
                (message = "game_o: ")  << "Gaming symbol " << symbol->symbol() << " on Date " << Date;
                ::logg << message;
            }


            if(!AdArray[index])  {
                if(::logg.debug(5099))  {
                    (message = "game_o: ")  << "Date " << Date << " not found in analdata_o";
                    message << " for symbol " << symbol->symbol();
                    ::logg << message;
                }
            }
            else  {
                move();

            }

            index++;
            symbol = Symbols.next();
        }
*/

move();

        executePreviousDaysTradeRules("Jill");
        executePreviousDaysTradeRules("Jay");
        executePreviousDaysTradeRules("Scott");
        executePreviousDaysTradeRules("Ray");
        executePreviousDaysTradeRules("Mike");
        createTodaysTradeRules("Jill");
        createTodaysTradeRules("Jay");
        createTodaysTradeRules("Scott");
        createTodaysTradeRules("Ray");
        createTodaysTradeRules("Mike");

        for(x=0;x<250;x++)  {
            (s = "") << "Trader" << x;
            executePreviousDaysTradeRules(s.string());
            createTodaysTradeRules(s.string());
        }



        Date = incrementDate(Date);
        if(Date > 20040422)  break;

    }

    message = "";
    brokerage.displayTraderAccount("Jill",message);
    ::logg << message;
    message = "";
    brokerage.displayTraderAccount("Jay",message);
    ::logg << message;
    message = "";
    brokerage.displayTraderAccount("Scott",message);
    ::logg << message;
    message = "";
    brokerage.displayTraderAccount("Ray",message);
    ::logg << message;
    message = "";
    brokerage.displayTraderAccount("Mike",message);
    ::logg << message;

    for(x=0;x<250;x++)  {
        (s = "") << "Trader" << x;
        brokerage.displayTraderAccount(s.string(),message);
        ::logg << message;
    }

    message = "";
    message << "Trader average value:$ " << brokerage.totalAssets()/brokerage.totalNumberOfTraders();
    ::logg << message;
    

    return ret;
}


int game_o::incrementDate(int date)  {
    date++;
    if((date % 100) > 31)  {
        date = date + (100 - (date % 100));
    }
    if(((date/100) % 100) > 12)  {
        date = date + (100 - (date/100 % 100))*100;
        date = date + 100;
    }
    return date;
}


int main(int argc,char* argv[])  {
    int       x;
    int       ret;
    symboldata_o* symbol;


sranddev();
      ::logg.setDebugLevel(5000); //game_o.
      ::logg.setDebugLevel(5011); //game_o: Examining date.
//    ::logg.setDebugLevel(5012); //game_o: Examoning symbol/date.
//    ::logg.setDebugLevel(5020); //game_o: move().
//    ::logg.setDebugLevel(5030); //game_o: executePreviousDaysTradeRules().
      for(x=5030;x<=5039;x++)  ::logg.setDebugLevel(x); //game_o: createTodaysTradeRules().

//    for(x=5040;x<=5049;x++)  ::logg.setDebugLevel(x); //game_o: createTodaysTradeRules().
//    ::logg.setDebugLevel(5045);
      ::logg.setDebugLevel(5050); //game_o: decide().
      ::logg.setDebugLevel(5090); //game_o: Examoning symbol/date.



    ret = game.setup();
    ret = game.play();


    return ret;
}



/******************************************************************************/
