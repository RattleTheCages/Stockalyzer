/**  trader.cc  ****************************************************************


changes log
when      who   what
04.24.04  Dan   Creation.


Debug Level 2600-2699
*******************************************************************************/


#include "trader.h"

traderule_o::traderule_o()  {
    Rule     = -1;
    StopLoss = -1;
    Volume   = -1;
    Price    = -1;
    Amount   = -1;
    Action   = -1;
}

traderule_o::~traderule_o()  {}

position_o::position_o()  {
    Shares = 0;
}

position_o::~position_o()  {}

trader_o::trader_o()  {
    Cash     = 0;

}

trader_o::~trader_o()  {}



/******************************************************************************/
