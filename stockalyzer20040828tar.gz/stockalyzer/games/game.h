/**  game.h  *******************************************************************


when      who   what
04.24.04  Dan   Creation.
04.29.04  Dan   Added.  List of trader ids.


*******************************************************************************/


#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#ifndef NULL
#define NULL 0
#endif


#include "string/string.h"
#include "memory/list.h"
#include "memory/bstree.h"
#include "other/sysinfo.h"
#include "log/log.h"

#include "analdata.h"
#include "movingavg.h"
#include "support.h"
#include "symboldata.h"
#include "trader.h"

#define GAMEOBJECT_STATE_CLEAR   0
#define GAMEOBJECT_STATE_VOID  255


class game_o  {
  private:
    int       State;
    int       Date;
    symbols_o Symbols;
    analdata_o** AdArray;
    list_o<string_o> Traders;

    bstree_o<list_o<analdata_o> >  AnaldataTree;
    int loadAnaldata(symboldata_o*);

    int move();
    int decide();

    int executePreviousDaysTradeRules(const char* traderId);
    int createTodaysTradeRules(const char* traderId);

    int rnd(int);
    int incrementDate(int);

  public:
    game_o();
    game_o(const game_o&);
   ~game_o();
    game_o& operator = (const game_o&);


    int setup();
    int play();

    int date();
};

/******************************************************************************/


inline int game_o::date()  {
    return Date;
}


#endif

/******************************************************************************/
