/**  marketdates.h  ************************************************************


    A list of valid dates that the market was open.

    This list is gaithered by the datacheck_o process in the datagather
        directory.  That process examons all histdata_o files and gets
        the open dates.


when      who   what
07.14.04  Dan   Creation.
07.27.04  Dan   Added.    MarketDay data and method members.


marketdates_o: Debug Level 0000-0000

*******************************************************************************/


#ifndef MARKETDATESOBJECT_H
#define MARKETDATESOBJECT_H

#include "string/string.h"
#include "memory/bstree.h"
#include "memory/list.h"

#define MARKETDATESOBJECT_MARKETDAY_VOID        0
#define MARKETDATESOBJECT_NON_MARKETDAY         1
#define MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN  2
#define MARKETDATESOBJECT_MARKETDAY_PREHOURS    17
#define MARKETDATESOBJECT_MARKETDAY_OPEN        31
#define MARKETDATESOBJECT_MARKETDAY_AFTERHOURS  19
#define MARKETDATESOBJECT_MARKETDAY_CLOSED      3

class marketdate_o  {
  friend class marketdates_o;
  private:
    int   Date;
    short Index;
    void* V;

  public:
    marketdate_o();
    marketdate_o(const marketdate_o&);
   ~marketdate_o();
    marketdate_o& operator = (const marketdate_o&);

    void operator << (const char*);
    void operator >> (string_o&);

    int   date()  const;
    int   index() const;
    void* v()     const;

    void  date(int);
    void  v(void*);
};

class marketdates_o  {
  private:
    list_o<marketdate_o> MarketdateList;
    bstree_o<marketdate_o> MarketdateTree;

    int MarketDay;
    int Date;
    int Time;

    string_o Filename;
    string_o Directory;
    marketdate_o* LastMarketdate;


public:
    marketdates_o();
    marketdates_o(const marketdates_o&);
   ~marketdates_o();
    marketdates_o& operator = (const marketdates_o&);

    int  save(const char*);
    int  save();
    int  load();
    int  directory();

    marketdate_o* first();
    marketdate_o* next();
    void          put(marketdate_o*);
    int           cardinality() const;
    marketdate_o* find(int);
    int           marketDay();
    int           date();
    int           time();

    const char* dirname() const;
    const char* filename() const;
    void dirname(const char*);
    void filename(const char*);
};

/******************************************************************************/

inline int marketdate_o::date() const  {
    return Date;
}

inline int marketdate_o::index() const  {
    return Index;
}

inline void* marketdate_o::v() const  {
    return V;
}

inline int marketdates_o::cardinality() const  {
    return MarketdateList.cardinality();
}

inline void marketdate_o::date(int d)  {
    Date = d;
}

inline void marketdate_o::v(void* v)  {
    V = v;
}


#endif

/******************************************************************************/
