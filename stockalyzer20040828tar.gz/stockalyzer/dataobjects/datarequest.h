/**  datarequest.h  ************************************************************


when      who   what
04.16.04  Dan   Creation.
04.22.04  Dan   Added.  Trailer to packet.
08.04.04  Dan   Added.  Data field.

*******************************************************************************/


#ifndef DATAREQUESTOBJECT_H
#define DATAREQUESTOBJECT_H

#include "string/string.h"

#define DATAREQUESTOBJECT_TRAILER "datarequest_oCompletexoxoxoxoxoxoxoxoxoxoxoxoxoxoxoxoxoxo"

#define DATAREQUESTOBJECT_OBJECT  "datarequest_o"
#define DATAREQUESTOBJECT_REQUEST "request"
#define DATAREQUESTOBJECT_TYPE    "type"
#define DATAREQUESTOBJECT_DATA    "data"
#define DATAREQUESTOBJECT_REPLY   "reply"


class datarequest_o  {
  private:
    string_o  Request;
    string_o  Type;
    string_o  Data;

    string_o  Reply;

  public:
    datarequest_o();
    datarequest_o(const datarequest_o&);
   ~datarequest_o();
    datarequest_o& operator = (const datarequest_o&);

    void clear();

    void operator << (const char*);
    void operator >> (string_o&);

    const char* request() const;
    const char* type() const;
    const char* data() const;
    const char* reply() const;

    void request(const char*);
    void type(const char*);
    void data(const char*);
    void reply(const char*);
};

/******************************************************************************/

inline const char* datarequest_o::request() const  {
    return Request.string();
}

inline const char* datarequest_o::type() const  {
    return Type.string();
}

inline const char* datarequest_o::data() const  {
    return Data.string();
}

inline const char* datarequest_o::reply() const  {
    return Reply.string();
}

inline void datarequest_o::request(const char* r)  {
    Request = r;
}

inline void datarequest_o::type(const char* t)  {
    Type = t;
}

inline void datarequest_o::data(const char* d)  {
    Data = d;
}

inline void datarequest_o::reply(const char* r)  {
    Reply = r;
}


#endif

/******************************************************************************/
