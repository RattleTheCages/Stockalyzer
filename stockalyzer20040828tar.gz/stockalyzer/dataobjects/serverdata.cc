/**  serverdata.cc  ************************************************************


changes log
when      who   what
08.24.04  Dan   Creation.

*******************************************************************************/


#include "serverdata.h"

serverdata_o::serverdata_o()  {
    Ip    = "2.2.2.42";
    Port  = 0;
    Type  = SERVERDATAOBJECT_TYPE_VOID;
    Id    = "server";
}

serverdata_o::serverdata_o(const serverdata_o& cd)  {
    Ip    = cd.Ip;
    Port  = cd.Port;
    Type  = cd.Type;
    Id    = cd.Id;
}

serverdata_o::~serverdata_o()  {}

serverdata_o& serverdata_o::operator = (const serverdata_o& cd)  {
    Ip    = cd.Ip;
    Port  = cd.Port;
    Type  = cd.Type;
    Id    = cd.Id;
    return *this;
}


void serverdata_o::operator >> (string_o& s)  {
    s << SERVERDATAOBJECT_OBJECT << ":\n";
    s << SERVERDATAOBJECT_IP << '=' << Ip << '\n';
    s << SERVERDATAOBJECT_PORT << '=' << Port << '\n';
    s << SERVERDATAOBJECT_TYPE << '=' << Type << '\n';
    s << SERVERDATAOBJECT_ID << '=' << Id << '\n';
    s << "\n\n";
}

void serverdata_o::operator << (const char* o)  {
    string_o s;
    string_o t;

    s = o;
    s.upcut(SERVERDATAOBJECT_OBJECT);
    s.upcut(":\n");
    s.cut("\n\n");

    t = s;
    t.upcut(SERVERDATAOBJECT_IP);
    t.upcut('=');
    t.cut('\n');
    Ip = t;

    t = s;
    t.upcut(SERVERDATAOBJECT_PORT);
    t.upcut('=');
    t.cut('\n');
    Port = t.stoi();

    t = s;
    t.upcut(SERVERDATAOBJECT_TYPE);
    t.upcut('=');
    t.cut('\n');
    Type = t.stoi();

    t = s;
    t.upcut(SERVERDATAOBJECT_ID);
    t.upcut('=');
    t.cut('\n');
    Id = t;

}


/******************************************************************************/
