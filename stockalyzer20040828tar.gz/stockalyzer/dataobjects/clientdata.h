/**  clientdata.h  *************************************************************


    This object contains information about data processing clients, analysis
    client, parser client, etc.  Information includes client type, port and ip.
    

when      who   what
08.06.04  Dan   Creation.
08.24.04  Dan   Added.    Socket data member.


*******************************************************************************/


#ifndef CLIENTDATAOBJECT_H
#define CLIENTDATAOBJECT_H

#include "string/string.h"

#define CLIENTDATAOBJECT_TYPE_ANALYSIS  2
#define CLIENTDATAOBJECT_TYPE_VOID      255

#define CLIENTDATAOBJECT_OBJECT "clientdata_o"
#define CLIENTDATAOBJECT_IP     "ip"
#define CLIENTDATAOBJECT_PORT   "port"
#define CLIENTDATAOBJECT_TYPE   "type"
#define CLIENTDATAOBJECT_ID     "id"
#define CLIENTDATAOBJECT_SOCKET "socket"

class clientdata_o  {
  private:
    string_o  Ip;
    int       Port;
    int       Type;
    string_o  Id;
    int       Socket;

  public:
    clientdata_o();
    clientdata_o(const clientdata_o&);
   ~clientdata_o();
    clientdata_o& operator = (const clientdata_o&);

    void operator << (const char*);
    void operator >> (string_o&);

    const char* ip()    const;
    int         port()  const;
    int         type()  const;
    const char* id()    const;
    int         socket() const;

    void ip(const char*);
    void port(int);
    void type(int);
    void id(const char*);

    void socket(int);
};

/******************************************************************************/

inline const char* clientdata_o::ip() const  {
    return Ip.string();
}

inline int clientdata_o::port() const  {
    return Port;
}

inline int clientdata_o::type() const  {
    return Type;
}

inline const char* clientdata_o::id() const  {
    return Id.string();
}

inline int clientdata_o::socket() const  {
    return Socket;
}


inline void clientdata_o::ip(const char* i)  {
    Ip = i;
}

inline void clientdata_o::port(int p)  {
    Port = p;
}

inline void clientdata_o::type(int t)  {
    Type = t;
}

inline void clientdata_o::id(const char* i)  {
    Id = i;
}

inline void clientdata_o::socket(int s)  {
    Socket = s;
}


#endif

/******************************************************************************/
