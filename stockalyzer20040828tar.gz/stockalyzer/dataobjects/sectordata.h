/**  sectordata.h  *************************************************************


    A list of string_o to use to lookup a symboldata_o and this
    object includes an id and a description.


when      who   what
07.14.04  Dan   Creation.


*******************************************************************************/


#ifndef SECTORDATAOBJECT_H
#define SECTORDATAOBJECT_H

#include "string/string.h"
#include "memory/list.h"

class sectordata_o  {
  private:
    string_o  Id;
    string_o  Description;
    list_o<string_o>  List;

  public:
    sectordata_o();
    sectordata_o(const sectordata_o&);
   ~sectordata_o();
    sectordata_o& operator = (const sectordata_o&);

    void operator << (const char*);
    void operator >> (string_o&);

    const char* id() const;
    const char* description() const;

    void id(const char*);
    void decription(const char*);
};

/******************************************************************************/

inline const char* sectordata_o::id() const  {
    return Id.string();
}

inline const char* sectordata_o::description() const  {
    return Description.string();
}

inline void sectordata_o::id(const char* i)  {
    if(i)  Id = i;
}

inline void sectordata_o::decription(const char* d)  {
    if(d)  Description = d;
}

#endif

/******************************************************************************/
