/**  analdata.cc  **************************************************************


changes log
when      who   what
04.12.04  Dan   Creation.
04.18.04  Dan   Added.  Average volume.
05.22.04  Dan   Added.  Trend data.
08.24.04  Dan   Changed.  The entire histdata_o object is no longer serilized
                and recontructed, only the date from it.  The analdata_o and
                histdata_o are going to reside in different files.
                Added.  Overloaded operator << histdata_o&.

*******************************************************************************/


#include "analdata.h"

analdata_o::analdata_o(): histdata_o()  {
    MA50     = 0;
    MA200    = 0;
    EMA9     = 0;
    EMA12    = 0;
    EMA26    = 0;
    EMA33    = 0;
    VMA50    = 0;
    VMA200   = 0;
    MACD1226 = 0;
    MACD1226EMA9 = 0;
    Support  = 0;
    DSupport = 0;
    TrendXCord = 0;
    TrendPoint = 0;
}

analdata_o::analdata_o(histdata_o& hd) : histdata_o(hd)  {
    MA50     = 0;
    MA200    = 0;
    EMA9     = 0;
    EMA12    = 0;
    EMA26    = 0;
    EMA33    = 0;
    MACD1226 = 0;
    MACD1226EMA9 = 0;
    VMA50    = 0;
    VMA200   = 0;
    Support  = 0;
    DSupport = 0;
    TrendXCord = 0;
    TrendPoint = 0;
}

analdata_o::analdata_o(const analdata_o& ad) : histdata_o(ad)  {
    MA50     = ad.MA50;
    MA200    = ad.MA200;
    EMA9     = ad.EMA9;
    EMA12    = ad.EMA12;
    EMA26    = ad.EMA26;
    EMA33    = ad.EMA33;
    MACD1226 = ad.MACD1226;
    MACD1226EMA9 = ad.MACD1226EMA9;
    VMA50    = ad.VMA50;
    VMA200   = ad.VMA200;
    Support  = ad.Support;
    DSupport = ad.DSupport;
    TrendXCord = ad.TrendXCord;
    TrendPoint = ad.TrendPoint;
}

analdata_o::~analdata_o()  {}

analdata_o& analdata_o::operator = (const analdata_o& ad)  {
    *(histdata_o*)this = *(histdata_o*)&ad;
    MA50     = ad.MA50;
    MA200    = ad.MA200;
    EMA9     = ad.EMA9;
    EMA12    = ad.EMA12;
    EMA26    = ad.EMA26;
    EMA33    = ad.EMA33;
    MACD1226 = ad.MACD1226;
    MACD1226EMA9 = ad.MACD1226EMA9;
    VMA50    = ad.VMA50;
    VMA200   = ad.VMA200;
    Support  = ad.Support;
    DSupport = ad.DSupport;
    TrendXCord = ad.TrendXCord;
    TrendPoint = ad.TrendPoint;
    return *this;
}

void analdata_o::clear()  {
    MA50     = 0;
    MA200    = 0;
    EMA9     = 0;
    EMA12    = 0;
    EMA26    = 0;
    EMA33    = 0;
    MACD1226 = 0;
    MACD1226EMA9 = 0;
    VMA50    = 0;
    VMA200   = 0;
    Support  = 0;
    DSupport = 0;
    TrendXCord = 0;
    TrendPoint = 0;
    Date = 0;
}

int* analdata_o::operator [](int x)  {
    if(x == 0)  return &MA50;
    if(x == 1)  return &MA200;
    if(x == 2)  return &VMA50;
    if(x == 3)  return &VMA200;
    if(x == 4)  return &Support;
//  if(x == 5)  return &DSupport;
    return '\0';
}

void analdata_o::operator >> (string_o& s)  {
    s << " analdata_o:" << Date << " " << MA50 << " " << MA200 << " ";
    s << EMA9 << " " << EMA12 << " " << EMA26 << " " << EMA33 << " " << MACD1226 << " " << MACD1226EMA9 << " ";
    s << VMA50 << " " << VMA200 << " " << Support;
    s << " " << DSupport;
    s << " " << TrendXCord;
    s << " " << TrendPoint;
}

void analdata_o::operator << (const histdata_o& hd)  {
    Open      = hd.open();
    High      = hd.high();
    Low       = hd.low();
    Close     = hd.close();
    Volume    = hd.volume();
    Adjusted  = hd.adjusted();
    Date      = hd.date();
}


void analdata_o::operator << (const char* o)  {
    string_o s;
    string_o t;
    s = o;

    s = o;
    s.upcut(" analdata_o:");
    t = s;
    t.cut(' ');
    Date = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    MA50 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    MA200 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    EMA9 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    EMA12 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    EMA26 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    EMA33 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    MACD1226 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    MACD1226EMA9 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    VMA50 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    VMA200 = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Support = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    DSupport = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    TrendXCord = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    TrendPoint = t.stoi();
}



/******************************************************************************/
