/**  dataconvert.h  *************************************************************


when      who   what
04.10.04  Dan   Creation.
05.22.04  Dan   Changed.  Abstracted some data conversions originaly
                          in support_o.


*******************************************************************************/


#ifndef DATACONVERTOBJECT_H
#define DATACONVERTOBJECT_H


#include "string/string.h"
#include "analdata.h"

class dataconvert_o  {
  private:
  public:
    dataconvert_o();
    dataconvert_o(const dataconvert_o&);
   ~dataconvert_o();
    dataconvert_o& operator = (const dataconvert_o&);

//  void stringDate(analdata_o*,string_o&);
    void stringInt(int,string_o&);
//  void stringDatePrice(analdata_o*,string_o&);
};

/******************************************************************************/



#endif

/******************************************************************************/
