/**  histdata.cc  **************************************************************


changes log
when      who   what
11.25.03  Dan   Creation.
04.03.04  Dan   Added.  Date object to the = operator and clear.
04.10.04  Dan   Added.  Copy constructor.
04.12.04  Dan   Added.  Date in integer form (as well as the string_o),
                        for easier seaching and sorting.


*******************************************************************************/


#include "histdata.h"

histdata_o::histdata_o()  {
    Open     = 0;
    High     = 0;
    Low      = 0;
    Close    = 0;
    Volume   = 0;
    Adjusted = 0;
    Date     = 0;
/*
    Year     = 0;
    Month    = 0;
    Day      = 0;
*/
}

histdata_o::histdata_o(const histdata_o& hd)  {
    Open     = hd.Open;
    High     = hd.High;
    Low      = hd.Low;
    Close    = hd.Close;
    Volume   = hd.Volume;
    Adjusted = hd.Adjusted;
    Date     = hd.Date;
/*
    Year     = hd.Year;
    Month    = hd.Month;
    Day      = hd.Day;
*/
}

histdata_o::~histdata_o()  {}

histdata_o& histdata_o::operator = (const histdata_o& hd)  {
    Open     = hd.Open;
    High     = hd.High;
    Low      = hd.Low;
    Close    = hd.Close;
    Volume   = hd.Volume;
    Adjusted = hd.Adjusted;
    Date     = hd.Date;
/*
    Year     = hd.Year;
    Month    = hd.Month;
    Day      = hd.Day;
*/
    return *this;
}

void histdata_o::clear()  {
    Open     = 0;
    High     = 0;
    Low      = 0;
    Close    = 0;
    Volume   = 0;
    Adjusted = 0;
    Date     = 0;
/*
    Year     = 0;
    Month    = 0;
    Day      = 0;
*/
}

int* histdata_o::operator [](int x)  {
    if(x == 0)  return &Open;
    if(x == 1)  return &High;
    if(x == 2)  return &Low;
    if(x == 3)  return &Close;
    if(x == 4)  return &Volume;
    if(x == 5)  return &Adjusted;
    return '\0';
}

void histdata_o::operator >> (string_o& s)  {
    s << " histdata_o:";
    s << Date << " " << Open << " "<< High << " " << Low;
    s << " " << Close << " " << Volume << " " << Adjusted;
}


void histdata_o::operator << (const char* o)  {
    string_o s;
    string_o t;
    s = o;

    s.upcut(" histdata_o:");
    t = s;

    t.cut(' ');
    Date = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Open = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    High = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Low = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Close = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Volume = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Adjusted = t.stoi();

}



/******************************************************************************/
