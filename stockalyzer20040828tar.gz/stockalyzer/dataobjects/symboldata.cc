/**  symboldata.cc  ************************************************************


changes log
when      who   what
04.16.04  Dan   Creation.
04.24.04  Dan   Added.  New object symbols_o to hold trees of symboldata_o.
                Moved.  Symbol lists from dgtasker.  These are trees now.
                        Load from file and find in directory methods from
                        dgtasker to this.
06.08.04  Dan   Added.  Last Trade, Range, Open, Market Cap, Volume, and PE.



symboldata_o: Debug Level 4600-4610

*******************************************************************************/


#include <fstream.h>
#include "symboldata.h"
#include "log/log.h"

extern log_o logg;

symboldata_o::symboldata_o()  {}

symboldata_o::symboldata_o(const symboldata_o& sd)  {
    Symbol = sd.Symbol;
    CompanyName = sd.CompanyName;
    Exchange = sd.Exchange;
    LastTrade = sd.LastTrade;
    Open = sd.Open;
    Range = sd.Range;
    MarketCap = sd.MarketCap;
    Volume = sd.Volume;
    PE = sd.PE;
}

symboldata_o::~symboldata_o()  {}

symboldata_o& symboldata_o::operator = (const symboldata_o& sd)  {
    Symbol = sd.Symbol;
    CompanyName = sd.CompanyName;
    Exchange = sd.Exchange;
    LastTrade = sd.LastTrade;
    Open = sd.Open;
    Range = sd.Range;
    MarketCap = sd.MarketCap;
    Volume = sd.Volume;
    PE = sd.PE;
    return *this;
}

void symboldata_o::clear()  {
    Symbol = "";
    CompanyName = "";
    Exchange = "";
    LastTrade = "";
    Open = "";
    Range = "";
    MarketCap = "";
    Volume = "";
    PE = "";
}

void symboldata_o::operator >> (string_o& s)  {
    s << " symboldata_o:";
    s << Symbol.string() << " " << CompanyName.string();
    s << " " << Exchange.string();
    s << " " << LastTrade.string();
    s << " " << Open.string();
    s << " " << Range.string();
    s << " " << MarketCap.string();
    s << " " << Volume.string();
    s << " " << PE.string();
}


void symboldata_o::operator << (const char* o)  {
    string_o s;
    string_o t;

    s = o;
    s.upcut(" symboldata_o:");
    t = s;
    t.cut(' ');
    Symbol = t;
    s.upcut(' ');
    if(s.length() < 1)  return;
    t = s;
    t.cut(' ');
    CompanyName = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Exchange = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    LastTrade = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Open = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Range = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    MarketCap = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Volume = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    PE = t;
}


symbols_o::symbols_o()  {
    SymbolTreeSearch = new bstreeSearch_o<symboldata_o>(&SymbolTree);
}

symbols_o::~symbols_o()  {
    delete SymbolTreeSearch;
}

int symbols_o::save(const char* filename)  {
    string_o message;
    string_o s;
    symboldata_o* symbol;
    ofstream out;
    bstreeSearch_o<symboldata_o> treeSearch(&SymbolTree);

    if(!filename)  return -1;

    if(::logg.debug(4600))  {
        (message = "symboldata_o: ")  << "save().  Saving symbols to file `";
        message << filename << "'";
        ::logg << message;
    }

    out.open(filename);
    if(!out)  return -1;

    symbol = (symboldata_o*)treeSearch.first();
    while(symbol)  {
        s = "";
        *symbol >> s;

        out << s.string() << '\n';

        symbol = (symboldata_o*)treeSearch.next();
    }
    out.close();


    return 0;
}


int symbols_o::load()  {
    string_o message;
    symboldata_o* symbol;
    char buffer[2048];
    ifstream in;

    if(Filename.length() < 1)  {
        Filename = "symbols.symboldata_o";
    }

    if(::logg.debug(4600))  {
        (message = "symboldata_o: ")  << "load().  Loading symbols from file `";
        message << Filename << "'";
        ::logg << message;
    }
    (message = "symboldata_o: ") << "Loaded symbols: ";

    in.open(Filename.string());
    if(!in)  {
        (message ="symboldata_o: ") << "Symbol file \"" << Filename << "\" missing.";
        ::logg << message;
        return -1;
    }

    for(int x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        symbol = new symboldata_o;
        *symbol << buffer;
        SymbolTreeFile.insert(symbol->symbol(),symbol);

        message << symbol->symbol() << ' ';
    }


    if(::logg.debug(4601))  {
        ::logg << message;
        (message = "symboldata_o: ") << "Number of symbols in file: " << SymbolTreeFile.cardinality();
        ::logg << message;
    }

    return  SymbolTreeFile.cardinality();
}


int symbols_o::directory()  {
    string_o s;
    string_o message;
    string_o syscall;
    char buff[32767];
    ifstream in;
    symboldata_o* symbol;
    bstreeSearch_o<symboldata_o>* dirtreeSearch;
    dirtreeSearch = new bstreeSearch_o<symboldata_o>(&SymbolTreeDirectory);

    if(Dirname.length() < 1)  {
        Dirname = "./livedata";
    }

    if(::logg.debug(4600))  {
        (message = "symboldata_o: ")  << "directory().  Look in directory `";
        message << Dirname << "' to find symbols.";
        ::logg << message;
    }
    (message = "symboldata_o: ") << "Directory symbols: ";

    (syscall = "") << "ls " << Dirname << " > /tmp/symboldata_o.tmp";
    system(syscall.string());
    in.open("/tmp/symboldata_o.tmp");
    while(in)  {
        in >> buff;
        if(in.eof())  break;

        (s = "") << buff;
        s.cut('.');

        symbol = new symboldata_o;
        *symbol << s.string();

        s = symbol->symbol();
        if(!dirtreeSearch->contains(&s))  {
            SymbolTreeDirectory.insert(symbol->symbol(),symbol);
            message << symbol->symbol() << ' ';
        }
    }
    in.close();
    system("rm -f /tmp/symboldata_o.tmp");


    if(::logg.debug(4601))  {
        ::logg << message;
        (message = "symboldata_o: ") << "Number of symbols in directory: ";
        message << SymbolTreeDirectory.cardinality();
        ::logg << message;
    }

    return  SymbolTreeDirectory.cardinality();
}


int symbols_o::invalid()  {
    string_o message;
    int x;
    string_o s,t;
    string_o syscall;
    char buff[32767];
    ifstream in;
    const symboldata_o* symboldata;

    bstree_o<string_o> tree;
    bstreeSearch_o<symboldata_o> filetreeSearch(&SymbolTreeFile);
    bstreeSearch_o<string_o> treeSearch(&tree);


    if(Dirname.length() < 1)  {
        Dirname = "./livedata";
    }

    if(::logg.debug(4600))  {
        (message = "symboldata_o: ")  << "invalid().  Look in directory `";
        message << Dirname << "' to find symbols.";
        ::logg << message;
    }
    (message = "symboldata_o: ") << "Directory symbols: ";

    (syscall = "") << "ls -l " << Dirname << " > /tmp/symboldata_o.tmp";
    system(syscall.string());
    in.open("/tmp/symboldata_o.tmp");
    while(in)  {
        in.getline(buff,sizeof(buff)-1,'\n');
        if(in.eof())  break;

        (s = "") << buff;

        s.upcut(' ');
        s.upcut(' ');
        s.upcut(' ');
        s.trim();
        s.upcut(' ');
        s.trim();
        s.upcut(' ');
        s.trim();
 
        if(!s.contains("histdata_o"))  {
            t = s;
            t.cut(' ');
            x = t.stoi();
            if(x < 12000)  {
                t = s;
                t.reverse();
                t.cut(' ');
                t.reverse();
                t.cut('.');

                tree.insert(t,new string_o(t));
///::logg<< t;
            }
        }


    }
    in.close();
    system("rm -f /tmp/symboldata_o.tmp");

    symboldata = filetreeSearch.first();
    while(symboldata)  {
        s = symboldata->symbol();
        if(!treeSearch.contains(&s))  {
            SymbolTree.insert(s,new symboldata_o(*symboldata));
        }
        symboldata = filetreeSearch.next();
    }

    if(::logg.debug(4601))  {
        ::logg << message;
        (message = "symboldata_o: ") << "Number of vaild symbols: ";
        message << SymbolTree.cardinality();
        ::logg << message;
    }

    return  tree.cardinality();
}


int symbols_o::merge()  {
    string_o message;
    string_o s;
    symboldata_o* symbol;
    bstreeSearch_o<symboldata_o>* treeSearch;
    bstreeSearch_o<symboldata_o>* dirtreeSearch;
    bstreeSearch_o<symboldata_o>* filetreeSearch;
    treeSearch = new bstreeSearch_o<symboldata_o>(&SymbolTree);
    dirtreeSearch = new bstreeSearch_o<symboldata_o>(&SymbolTreeDirectory);
    filetreeSearch = new bstreeSearch_o<symboldata_o>(&SymbolTreeFile);


    if(::logg.debug(4600))  {
        (message = "symboldata_o: ")  << "merge().";
        ::logg << message;
    }


    symbol = (symboldata_o*)dirtreeSearch->first();
    while(symbol)  {
        s = symbol->symbol();
        if(!treeSearch->contains(&s))  SymbolTree.insert(symbol->symbol(),new symboldata_o(*symbol));
        symbol = (symboldata_o*)dirtreeSearch->next();
    }

    symbol = (symboldata_o*)filetreeSearch->first();
    while(symbol)  {
        s = symbol->symbol();
        if(!treeSearch->contains(&s))  SymbolTree.insert(symbol->symbol(),new symboldata_o(*symbol));
        symbol = (symboldata_o*)filetreeSearch->next();
    }

    delete treeSearch;
    delete dirtreeSearch;
    delete filetreeSearch;

    return  SymbolTree.cardinality();
}


int symbols_o::filter()  {
    string_o message;
    string_o s;
    symboldata_o* symbol;
    bstreeSearch_o<symboldata_o> treeSearch(&SymbolTree);
    bstreeSearch_o<symboldata_o> dirtreeSearch(&SymbolTreeDirectory);
    bstreeSearch_o<symboldata_o> filetreeSearch(&SymbolTreeFile);

    if(::logg.debug(4600))  {
        (message = "symboldata_o: ")  << "filter().";
        ::logg << message;
    }

    symbol = (symboldata_o*)filetreeSearch.first();
    while(symbol)  {
        s = symbol->symbol();
        if(!treeSearch.contains(&s) &&
           !dirtreeSearch.contains(&s))
            SymbolTree.insert(symbol->symbol(),new symboldata_o(*symbol));
        symbol = (symboldata_o*)filetreeSearch.next();
    }

    return  SymbolTree.cardinality();
}

symboldata_o* symbols_o::first()  {
    return  (symboldata_o*)SymbolTreeSearch->first();
}

symboldata_o* symbols_o::next()  {
    return  (symboldata_o*)SymbolTreeSearch->next();
}

void symbols_o::put(symboldata_o* sd)  {
    string_o s;
    if(sd)  {
        s = sd->symbol();
        SymbolTree.insert(s,sd);
    }
}


/******************************************************************************/
