/**  dataconvert.cc  ************************************************************


changes log
when      who   what
04.10.04  Dan   Creation.
05.22.04  Dan   Changed.  Abstracted some data conversions originaly
                          in support_o.


*******************************************************************************/


#include "dataconvert.h"

dataconvert_o::dataconvert_o()  {}

dataconvert_o::~dataconvert_o()  {}


void dataconvert_o::stringInt(int i,string_o& s)  {
    s << i;
    s.reverse();
    s << "0000000000000000";
    s.cut(s.length()-10);
    s.reverse();
}


/*
void dataconvert_o::stringDate(analdata_o* ad,string_o& s)  {
    string_o t;

    (t = "") << ad->year();
    t.justifyRight(2);
    t.transpose(" ","0");
    s << t;
    (t = "") << ad->month();
    t.justifyRight(2);
    t.transpose(" ","0");
    s << t;
    (t = "") << ad->day();
    t.justifyRight(2);
    t.transpose(" ","0");
    s << t;
}*/


/*
void dataconvert_o::stringDatePrice(analdata_o* ad,string_o& s)  {
    stringDate(ad,s);
    s  << ';' << ad->close() << ';';
}*/


/******************************************************************************/
