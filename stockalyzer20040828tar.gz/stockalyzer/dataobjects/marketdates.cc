/**  marketdates.cc  ************************************************************


    A list of valid dates that the market was open.

    This list is gaithered by the datacheck_o process in the datagather
        directory.  That process examons all histdata_o files and gets
        the open dates.


when      who   what
07.14.04  Dan   Creation.
07.27.04  Dan   Added.    MarketDay data and method members.


marketdates_o: Debug Level 0000-0000

*******************************************************************************/


#include <fstream.h>
#include "marketdates.h"
#include "log/log.h"
#include "other/sysinfo.h"

extern log_o logg;
extern sysinfo_o sysinfo;

marketdate_o::marketdate_o()  {
    Date = 0;
    Index = -1;
    V = '\0';
}

marketdate_o::marketdate_o(const marketdate_o& md)  {
    Date = md.Date;
    Index = md.Index;
    V = md.V;
}

marketdate_o::~marketdate_o()  {}

marketdate_o& marketdate_o::operator = (const marketdate_o& md)  {
    Date = md.Date;
    Index = md.Index;
    V = md.V;
    return *this;
}

void marketdate_o::operator >> (string_o& s)  {
    s << " marketdate_o:";
    s << Date;
    s << " " << Index;
}

void marketdate_o::operator << (const char* o)  {
    string_o s;
    string_o t;

    s = o;
    s.upcut(" marketdate_o:");
    t = s;
    t.cut(' ');
    Date = t.stoi();
    s.upcut(' ');
    if(s.length() < 1)  return;
    t = s;
    t.cut(' ');
    Index = t.stoi();
}


marketdates_o::marketdates_o()  {
    LastMarketdate = '\0';
    Filename  = "marketdate.marketdates_o";
    Directory = "./config/";
    MarketDay = MARKETDATESOBJECT_MARKETDAY_VOID;
    Date      = -1;
    Time      = -1;
}

marketdates_o::~marketdates_o()  {
}

int marketdates_o::save()  {
    string_o s;
    s << Directory << Filename;
    return  save(s.string());
}

int marketdates_o::save(const char* filename)  {
    string_o message;
    string_o s;
    marketdate_o* md;
    ofstream out;

    if(!filename)  return -1;

    if(::logg.debug(4600))  {
        (message = "marketdates_o: ")  << "save().  Saving marketdate_o to file `";
        message << filename << "'";
        ::logg << message;
    }

    out.open(filename);
    if(!out)  return -1;

    md = MarketdateList.first();
    while(md)  {
        s = "";
        *md >> s;

        out << s.string() << '\n';

        md = MarketdateList.next();
    }
    out.close();


    return 0;
}


int marketdates_o::load()  {
    string_o message;
    string_o s;
    string_o filename;
    marketdate_o* md;
    char buffer[2048];
    ifstream in;

    filename << Directory << Filename;

    if(::logg.debug(4600))  {
        (message = "marketdates_o: ")  << "load().  Loading marketdate_o from file `";
        message << filename << "'";
        ::logg << message;
    }

    in.open(filename.string());
    if(!in)  {
        (message ="marketdates_o: ") << "marketdate_o file \"" << filename << "\" missing.";
        ::logg << message;
        return -1;
    }

    for(int x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        md = new marketdate_o;
        *md << buffer;
        MarketdateList.put(md);
        (s = "") << md->date();
        MarketdateTree.insert(s,md);
        LastMarketdate = md;
    }

    if(::logg.debug(4601))  {
        (message = "marketdates_o: ") << "Loaded marketdate_os: ";
        message << "Number of marketdate_os in file: " << MarketdateList.cardinality();
        ::logg << message;
    }

    return  MarketdateList.cardinality();
}


int marketdates_o::directory()  {
/*
    string_o s;
    string_o message;
    string_o syscall;
    char buff[32767];
    ifstream in;
    symboldata_o* symbol;
    bstreeSearch_o<symboldata_o>* dirtreeSearch;
    dirtreeSearch = new bstreeSearch_o<symboldata_o>(&SymbolTreeDirectory);

    if(Dirname.length() < 1)  {
        Dirname = "./livedata";
    }

    if(::logg.debug(4600))  {
        (message = "marketdates_o: ")  << "directory().  Look in directory `";
        message << Dirname << "' to find symbols.";
        ::logg << message;
    }
    (message = "marketdates_o: ") << "Directory symbols: ";

    (syscall = "") << "ls " << Dirname << " > /tmp/symboldata_o.tmp";
    system(syscall.string());
    in.open("/tmp/symboldata_o.tmp");
    while(in)  {
        in >> buff;
        if(in.eof())  break;

        (s = "") << buff;
        s.cut('.');

        symbol = new symboldata_o;
        *symbol << s.string();

        s = symbol->symbol();
        if(!dirtreeSearch->contains(&s))  {
            SymbolTreeDirectory.insert(symbol->symbol(),symbol);
            message << symbol->symbol() << ' ';
        }
    }
    in.close();
    system("rm -f /tmp/symboldata_o.tmp");


    if(::logg.debug(4601))  {
        ::logg << message;
        (message = "marketdates_o: ") << "Number of symbols in directory: ";
        message << SymbolTreeDirectory.cardinality();
        ::logg << message;
    }

    return  SymbolTreeDirectory.cardinality();
*/
return -1;
}

int marketdates_o::date()  {
    int cday;
    string_o s;

    s << sysinfo.currentYear();
    if(sysinfo.currentMonth()+1 < 10)  s << '0';
    s << sysinfo.currentMonth()+1;

    cday = sysinfo.currentDay();

    if(cday <  10)  s << '0';
    s << cday;

    Date = s.stoi();

    return Date;
}

int marketdates_o::time()  {
    string_o s;

    if(sysinfo.currentHour() < 10)  s << '0';
    s << sysinfo.currentHour();
    if(sysinfo.currentMinute() < 10)  s << '0';
    s << sysinfo.currentMinute();
    if(sysinfo.currentSecond() < 10)  s << '0';
    s << sysinfo.currentSecond();

    Time = s.stoi();

    return Time;
}

int marketdates_o::marketDay()  {
    string_o message;

    MarketDay = MARKETDATESOBJECT_NON_MARKETDAY;
    date();
    time();

    if(sysinfo.currentDayOfWeek() > 0 && sysinfo.currentDayOfWeek() < 6)  {

        if(Time < 80000)  MarketDay = MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN;
        else  if(Time < 93000)  MarketDay = MARKETDATESOBJECT_MARKETDAY_PREHOURS;
        else  if(Time < 160000)  MarketDay = MARKETDATESOBJECT_MARKETDAY_OPEN;
        else  if(Time < 200000)  MarketDay = MARKETDATESOBJECT_MARKETDAY_AFTERHOURS;
        else  MarketDay = MARKETDATESOBJECT_MARKETDAY_CLOSED;
    }

    if(::logg.debug(4600))  {
        (message = "marketdates_o: ") << "marketDay(): ";
        message << Date << ':' << Time << "  reports: ";
        if(MarketDay == MARKETDATESOBJECT_NON_MARKETDAY)  message << "non-market day.";
        if(MarketDay == MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN)
            message << "market day, before open (closed).";
        if(MarketDay == MARKETDATESOBJECT_MARKETDAY_PREHOURS)
            message << "market day, pre-open hours.";
        if(MarketDay == MARKETDATESOBJECT_MARKETDAY_OPEN)  message << "market day, open.";
        if(MarketDay == MARKETDATESOBJECT_MARKETDAY_AFTERHOURS) message << "market day, after-hours.";
        if(MarketDay == MARKETDATESOBJECT_MARKETDAY_CLOSED)  message << "market day, closed.";
        ::logg << message;

        if(MarketDay != MARKETDATESOBJECT_NON_MARKETDAY && !find(Date))  {
            (message = "marketdates_o: ") << "marketDay(): ";
            message << "today not found among valid market day list.";
            ::logg << message;
        }
    }

    return MarketDay;
}

marketdate_o* marketdates_o::first()  {
    return  MarketdateList.first();
}

marketdate_o* marketdates_o::next()  {
    return  MarketdateList.next();
}

void marketdates_o::put(marketdate_o* mdin)  {
    string_o      s;
    int           index;

    if(mdin)  {
        if(!LastMarketdate)  index = 1;
        else  index = LastMarketdate->index()+1;
        mdin->Index = index;

        MarketdateList.put(mdin);
        s << mdin->date();
        MarketdateTree.insert(s,mdin);
        LastMarketdate = mdin;
    }
}

marketdate_o* marketdates_o::find(int date)  {
    string_o      s;
    marketdate_o* md;
    bstreeSearch_o<marketdate_o> mts(&MarketdateTree);

    s << date;
    md = (marketdate_o*)mts.find(&s);

    return md;
}


/******************************************************************************/
