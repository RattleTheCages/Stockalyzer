/**  analdata.h  ***************************************************************


when      who   what
04.12.04  Dan   Creation.
04.18.04  Dan   Added.  Average volume.
05.02.04  Dan   Added.  Exponential moving average.
05.22.04  Dan   Added.  Trend data.
08.24.04  Dan   Added.  Overloaded operator << histdata_o&.


*******************************************************************************/


#ifndef ANALDATAOBJECT_H
#define ANALDATAOBJECT_H

#include "string/string.h"
#include "histdata.h"

#define ANALDATAOBJECT_OBJECT "analdata_o"

class analdata_o: public histdata_o  {
  private:
    int       MA50;
    int       MA200;
    int       EMA9;
    int       EMA12;
    int       EMA26;
    int       EMA33;
    int       MACD1226;
    int       MACD1226EMA9;
    int       VMA50;
    int       VMA200;
    int       Support;
    int       DSupport;
    int       TrendXCord;
    int       TrendPoint;

  public:
    analdata_o();
    analdata_o(const analdata_o&);
    analdata_o(histdata_o&);
   ~analdata_o();
    analdata_o& operator = (const analdata_o&);

    void clear();

    int* operator [](int);
    void operator << (const char*);
    void operator >> (string_o&);

    void operator << (const histdata_o&);

    int ma50() const;
    int ma200() const;
    int ema9() const;
    int ema12() const;
    int ema26() const;
    int ema33() const;
    int macd1226() const;
    int macd1226ema9() const;
    int vma50() const;
    int vma200() const;
    int support() const;
    int dsupport() const;
    int trendXCord() const;
    int trendPoint() const;

    void ma50(int);
    void ma200(int);
    void ema9(int);
    void ema12(int);
    void ema26(int);
    void ema33(int);
    void macd1226(int);
    void macd1226ema9(int);
    void vma50(int);
    void vma200(int);
    void support(int);
    void dsupport(int);
    void trendXCord(int);
    void trendPoint(int);
};

/******************************************************************************/


inline int analdata_o::ma50() const  {
    return MA50;
}

inline int analdata_o::ma200() const  {
    return MA200;
}

inline int analdata_o::ema9() const  {
    return EMA9;
}

inline int analdata_o::ema12() const  {
    return EMA12;
}

inline int analdata_o::ema26() const  {
    return EMA26;
}

inline int analdata_o::ema33() const  {
    return EMA33;
}

inline int analdata_o::macd1226() const  {
    return MACD1226;
}

inline int analdata_o::macd1226ema9() const  {
    return MACD1226EMA9;
}

inline int analdata_o::vma50() const  {
    return VMA50;
}

inline int analdata_o::vma200() const  {
    return VMA200;
}

inline int analdata_o::support() const  {
    return Support;
}

inline int analdata_o::dsupport() const  {
    return DSupport;
}

inline int analdata_o::trendXCord() const  {
    return TrendXCord;
}

inline int analdata_o::trendPoint() const  {
    return TrendPoint;
}


inline void analdata_o::support(int s)  {
    Support = s;
}

inline void analdata_o::dsupport(int ds)  {
    DSupport = ds;
}

inline void analdata_o::trendXCord(int xcord)  {
    TrendXCord = xcord;
}

inline void analdata_o::trendPoint(int tlp)  {
    TrendPoint = tlp;
}

inline void analdata_o::ma50(int ma)  {
    MA50 = ma;
}

inline void analdata_o::ma200(int ma)  {
    MA200 = ma;
}

inline void analdata_o::ema9(int ma)  {
    EMA9 = ma;
}

inline void analdata_o::ema12(int ma)  {
    EMA12 = ma;
}

inline void analdata_o::ema26(int ma)  {
    EMA26 = ma;
}

inline void analdata_o::ema33(int ma)  {
    EMA33 = ma;
}

inline void analdata_o::macd1226(int macd)  {
    MACD1226 = macd;
}

inline void analdata_o::macd1226ema9(int macd)  {
    MACD1226EMA9 = macd;
}

inline void analdata_o::vma50(int vma)  {
    VMA50 = vma;
}

inline void analdata_o::vma200(int vma)  {
    VMA200 = vma;
}


#endif

/******************************************************************************/
