/**  serverdata.h  *************************************************************


    This object contains information about servers, I.e. tasker.
    Information includes server type, port and ip.
    

when      who   what
08.24.04  Dan   Creation.


*******************************************************************************/


#ifndef SERVERDATAOBJECT_H
#define SERVERDATAOBJECT_H

#include "string/string.h"

#define SERVERDATAOBJECT_TYPE_TASKER    2
#define SERVERDATAOBJECT_TYPE_VOID      255

#define SERVERDATAOBJECT_OBJECT "serverdata_o"
#define SERVERDATAOBJECT_IP     "ip"
#define SERVERDATAOBJECT_PORT   "port"
#define SERVERDATAOBJECT_TYPE   "type"
#define SERVERDATAOBJECT_ID     "id"

class serverdata_o  {
  private:
    string_o  Ip;
    int       Port;
    int       Type;
    string_o  Id;

  public:
    serverdata_o();
    serverdata_o(const serverdata_o&);
   ~serverdata_o();
    serverdata_o& operator = (const serverdata_o&);

    void operator << (const char*);
    void operator >> (string_o&);

    const char* ip()    const;
    int         port()  const;
    int         type()  const;
    const char* id()    const;

    void ip(const char*);
    void port(int);
    void type(int);
    void id(const char*);
};

/******************************************************************************/

inline const char* serverdata_o::ip() const  {
    return Ip.string();
}

inline int serverdata_o::port() const  {
    return Port;
}

inline int serverdata_o::type() const  {
    return Type;
}

inline const char* serverdata_o::id() const  {
    return Id.string();
}


inline void serverdata_o::ip(const char* i)  {
    Ip = i;
}

inline void serverdata_o::port(int p)  {
    Port = p;
}

inline void serverdata_o::type(int t)  {
    Type = t;
}

inline void serverdata_o::id(const char* i)  {
    Id = i;
}


#endif

/******************************************************************************/
