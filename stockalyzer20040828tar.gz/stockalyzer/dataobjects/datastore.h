/**  datastore.h  **************************************************************


when      who   what
06.01.04  Dan   Creation. Created this object as single place to load
                          data objects.  Oringinally from analysis and plotchart.
07.14.04  Dan   Added.    Function loadHistdata(const char*,histdata_o*),
                          to load the most recent histdata_o as an single datum
                          (not the entire list; used for a quick look to see
                          if the data is current.)
08.24.04  Dan   Changed.  When storing analdata_o in a file, the histdata_o
                          portion is no longer saved with it, so, look for
                          and load the indepenent histdata_o file with the
                          loadAnaldata method.  (However, the histdata_o
                          file is not stored with a saveAnaldata call, because
                          this file should already exsit.)  And changed the 
                          signeture of the load and saveAnaldata method from
                          requiering a filename to requiering a symboldata_o.
                Added.    load and saveTrenddata methods.  (Used to be part of
                          load/saveAnaldata.)
08.26.04  Dan   Added.    Method loadAnaldata with one datum, used to check
                          if the analdata_o is current.  And added data member
                          directory and methods.


Debug Level: 4690-4699
*******************************************************************************/


#ifndef DATASTOREOBJECT_H
#define DATASTOREOBJECT_H


#include "memory/list.h"
#include "symboldata.h"
#include "histdata.h"
#include "analdata.h"
#include "trenddata.h"

#define DATASTOREOBJECT_STATE_CLEAR             0
#define DATASTOREOBJECT_STATE_LOADED_HISTDATA   1
#define DATASTOREOBJECT_STATE_SAVED_HISTDATA    2
#define DATASTOREOBJECT_STATE_LOADED_ANALDATA   3
#define DATASTOREOBJECT_STATE_SAVED_ANALDATA    4
#define DATASTOREOBJECT_STATE_LOADED_TRENDDATA  5
#define DATASTOREOBJECT_STATE_SAVED_TRENDDATA   6
#define DATASTOREOBJECT_STATE_FILE_NOT_FOUND    253
#define DATASTOREOBJECT_STATE_NULL_PASSED       254
#define DATASTOREOBJECT_STATE_VOID              255


class datastore_o  {
  private:
    int State;
    string_o Directory;

  public:
    datastore_o();
    datastore_o(const datastore_o&);
   ~datastore_o();
    datastore_o& operator = (const datastore_o&);


    const char* directory() const;
    void directory(const char*);


    int loadHistdata(const symboldata_o&,histdata_o*);
    int loadHistdata(const symboldata_o&,list_o<histdata_o>*);
    int saveHistdata(const symboldata_o&,list_o<histdata_o>*);
    int loadAnaldata(const symboldata_o&,analdata_o*);
    int loadAnaldata(const symboldata_o&,list_o<analdata_o>*);
    int saveAnaldata(const symboldata_o&,list_o<analdata_o>*);
    int loadTrenddata(const symboldata_o&,list_o<trenddata_o>*);
    int saveTrenddata(const symboldata_o&,list_o<trenddata_o>*);
};

/******************************************************************************/

inline const char* datastore_o::directory() const  {
    return Directory.string();
}

inline void datastore_o::directory(const char* d)  {
    if(d)  Directory = d;
}



#endif

/******************************************************************************/
