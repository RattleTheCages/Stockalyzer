/**  trenddata.h  **************************************************************


when      who   what
05.22.04  Dan   Creation.
06.12.04  Dan   Added.    Datum tomorrowY.


*******************************************************************************/


#ifndef TRENDDATAOBJECT_H
#define TRENDDATAOBJECT_H

#include "histdata.h"
#include "string/string.h"

#define TRENDDATAOBJECT_OBJECT "trenddata_o"

class trenddata_o  {
  private:
    int       X;
    int       Y;
    int       M;
    int       B;
    int       Hits;
public:
    int       Xx[256];
    int       Valid;
    int       TomorrowY;

  public:
    trenddata_o();
    trenddata_o(const trenddata_o&);
   ~trenddata_o();
    trenddata_o& operator = (const trenddata_o&);

    void clear();

    void operator << (const char*);
    void operator >> (string_o&);

    int x() const;
    int y() const;
    int m() const;
    int b() const;
    int hits() const;
    int valid() const;
    int tomorrowY() const;
    int date() const;

    void x(int);
    void y(int);
    void m(int);
    void b(int);
    void hits(int);
    void valid(int);
    void tomorrowY(int);
};

/******************************************************************************/


inline int trenddata_o::date() const  {
    return X;
}

inline int trenddata_o::x() const  {
    return X;
}

inline int trenddata_o::y() const  {
    return Y;
}

inline int trenddata_o::m() const  {
    return M;
}

inline int trenddata_o::b() const  {
    return B;
}

inline int trenddata_o::hits() const  {
    return Hits;
}

inline int trenddata_o::valid() const  {
    return Valid;
}

inline int trenddata_o::tomorrowY() const  {
    return TomorrowY;
}


inline void trenddata_o::x(int x)  {
    X = x;
}

inline void trenddata_o::y(int y)  {
    Y = y;
}

inline void trenddata_o::m(int m)  {
    M = m;
}

inline void trenddata_o::b(int b)  {
    B = b;
}

inline void trenddata_o::hits(int h)  {
    Hits = h;
}

inline void trenddata_o::valid(int v)  {
    Valid = v;
}

inline void trenddata_o::tomorrowY(int ty)  {
    TomorrowY = ty;
}


#endif

/******************************************************************************/
