/**  sectordata.cc  ***********************************************************

    A list of string_o used to look up symboldata_o and this object
    includes an id and a description.

changes log
when      who   what
07.14.04  Dan   Creation.


*******************************************************************************/


#include "sectordata.h"

sectordata_o::sectordata_o()  {}

sectordata_o::~sectordata_o()  {}

void sectordata_o::operator >> (string_o& s)  {
    int x;
    string_o* sy;

    s << " sectordata_o:";
    s << Id << " " << Description << " ";
    s << List.cardinality() << " ";
    sy = List.first();
    for(x=0;x<List.cardinality();x++)  {
        s << sy->string() << " ";
        sy = List.next();
    }
}

void sectordata_o::operator << (const char* o)  {
/*
    string_o s;
    string_o t;
    s = o;

    s.upcut(" histdata_o:");
    t = s;

    t.cut(' ');
    Date = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Open = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    High = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Low = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Close = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Volume = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Adjusted = t.stoi();

*/
}



/******************************************************************************/
