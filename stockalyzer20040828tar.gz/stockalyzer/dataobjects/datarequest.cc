/**  datarequest.cc  **********************************************************


changes log
when      who   what
04.16.04  Dan   Creation.
04.22.04  Dan   Added.  Trailer to packet.
08.04.04  Dan   Added.  Data feild.

*******************************************************************************/


#include "datarequest.h"

datarequest_o::datarequest_o()  {}

datarequest_o::datarequest_o(const datarequest_o& dr)  {
    Request  = dr.Request;
    Type     = dr.Type;
    Data     = dr.Data;
    Reply    = dr.Reply;
}

datarequest_o::~datarequest_o()  {}

datarequest_o& datarequest_o::operator = (const datarequest_o& dr)  {
    Request  = dr.Request;
    Type     = dr.Type;
    Data     = dr.Data;
    Reply    = dr.Reply;
    return *this;
}

void datarequest_o::clear()  {
    Request  = ".";
    Type     = ".";
    Data     = ".";
    Reply    = ".";
}

void datarequest_o::operator >> (string_o& s)  {
    s << DATAREQUESTOBJECT_OBJECT << ":\n";
    s << DATAREQUESTOBJECT_REQUEST << '=' << Request << '\n';
    s << DATAREQUESTOBJECT_TYPE << '=' << Type << '\n';
    s << DATAREQUESTOBJECT_DATA << '=' << Data << '\n';
    s << DATAREQUESTOBJECT_REPLY << '=' << Reply << '\n';
    s << '\n';
    s << DATAREQUESTOBJECT_TRAILER;
}

void datarequest_o::operator << (const char* o)  {
    string_o s;
    string_o t;

    s = o;
    s.upcut(DATAREQUESTOBJECT_OBJECT);
    s.upcut(":\n");
    s.cut("\n\n");

    t = s;
    t.upcut(DATAREQUESTOBJECT_REQUEST);
    t.upcut('=');
    t.cut('\n');
    Request = t;

    t = s;
    t.upcut(DATAREQUESTOBJECT_TYPE);
    t.upcut('=');
    t.cut('\n');
    Type = t;

    t = s;
    t.upcut(DATAREQUESTOBJECT_DATA);
    t.upcut('=');
    t.cut('\n');
    Data = t;

    t = s;
    t.upcut(DATAREQUESTOBJECT_REPLY);
    t.upcut('=');
    t.cut('\n');
    Reply = t;

}


/******************************************************************************/
