/**  histdata.h  ***************************************************************


when      who   what
11.21.03  Dan   Creation.
04.03.04  Dan   Added.    Some data hideing assignment and value methods.
04.12.04  Dan   Added.    Date in integer form (as well as the string_o),
                          for easier seaching and sorting.
04.24.04  Dan   Changed.  Date from a string to an int.
08.24.04  Dan   Changed.  Data members from private to protected.
                Removed.  Data members Year, Month, Day; they are no
                          longer used.


*******************************************************************************/


#ifndef HISTDATAOBJECT_H
#define HISTDATAOBJECT_H

#include "string/string.h"

#define HISTDATAOBJECT_OBJECT "histdata_o"

class histdata_o  {
  protected:
    int       Date;
    int       Open;
    int       High;
    int       Low;
    int       Close;
    int       Volume;
    int       Adjusted;
/*
    int       Year;
    int       Month;
    int       Day;
*/


  public:
    histdata_o();
    histdata_o(const histdata_o&);
   ~histdata_o();
    histdata_o& operator = (const histdata_o&);

    void clear();

    int* operator [](int);
    void operator << (const char*);
    void operator >> (string_o&);

    int open() const;
    int high() const;
    int low() const;
    int close() const;
    int volume() const;
    int adjusted() const;
    int date() const;
/*
    int year() const;
    int month() const;
    int day() const;
*/

    void open(int);
    void high(int);
    void low(int);
    void close(int);
    void volume(int);
    void adjusted(int);
    void date(int);
};

/******************************************************************************/

inline int histdata_o::open() const  {
    return Open;
}

inline int histdata_o::high() const  {
    return High;
}

inline int histdata_o::low() const  {
    return Low;
}

inline int histdata_o::close() const  {
    return Close;
}

inline int histdata_o::volume() const  {
    return Volume;
}

inline int histdata_o::adjusted() const  {
    return Adjusted;
}

inline int histdata_o::date() const  {
    return Date;
}

/*
inline int histdata_o::year() const  {
    return Year;
}

inline int histdata_o::month() const  {
    return Month;
}

inline int histdata_o::day() const  {
    return Day;
}
*/

inline void histdata_o::open(int i)  {
    Open = i;
}

inline void histdata_o::high(int i)  {
    High = i;
}

inline void histdata_o::low(int i)  {
    Low = i;
}

inline void histdata_o::close(int i)  {
    Close = i;
}

inline void histdata_o::volume(int i)  {
    Volume = i;
}

inline void histdata_o::adjusted(int i)  {
    Adjusted = i;
}

inline void histdata_o::date(int i)  {
    Date = i;
}


#endif

/******************************************************************************/
