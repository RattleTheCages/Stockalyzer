/**  clientdata.cc  ************************************************************


changes log
when      who   what
08.06.04  Dan   Creation.

*******************************************************************************/


#include "clientdata.h"

clientdata_o::clientdata_o()  {
    Ip    = "2.2.2.42";
    Port  = 0;
    Type  = CLIENTDATAOBJECT_TYPE_VOID;
    Id    = "client";
    Socket = 0;
}

clientdata_o::clientdata_o(const clientdata_o& cd)  {
    Ip    = cd.Ip;
    Port  = cd.Port;
    Type  = cd.Type;
    Id    = cd.Id;
    Socket = cd.Socket;
}

clientdata_o::~clientdata_o()  {}

clientdata_o& clientdata_o::operator = (const clientdata_o& cd)  {
    Ip    = cd.Ip;
    Port  = cd.Port;
    Type  = cd.Type;
    Id    = cd.Id;
    Socket = cd.Socket;
    return *this;
}


void clientdata_o::operator >> (string_o& s)  {
    s << CLIENTDATAOBJECT_OBJECT << ":\n";
    s << CLIENTDATAOBJECT_IP << '=' << Ip << '\n';
    s << CLIENTDATAOBJECT_PORT << '=' << Port << '\n';
    s << CLIENTDATAOBJECT_TYPE << '=' << Type << '\n';
    s << CLIENTDATAOBJECT_ID << '=' << Id << '\n';
    s << CLIENTDATAOBJECT_SOCKET << '=' << Socket << '\n';
    s << "\n\n";
}

void clientdata_o::operator << (const char* o)  {
    string_o s;
    string_o t;

    s = o;
    s.upcut(CLIENTDATAOBJECT_OBJECT);
    s.upcut(":\n");
    s.cut("\n\n");

    t = s;
    t.upcut(CLIENTDATAOBJECT_IP);
    t.upcut('=');
    t.cut('\n');
    Ip = t;

    t = s;
    t.upcut(CLIENTDATAOBJECT_PORT);
    t.upcut('=');
    t.cut('\n');
    Port = t.stoi();

    t = s;
    t.upcut(CLIENTDATAOBJECT_TYPE);
    t.upcut('=');
    t.cut('\n');
    Type = t.stoi();

    t = s;
    t.upcut(CLIENTDATAOBJECT_ID);
    t.upcut('=');
    t.cut('\n');
    Id = t;

    t = s;
    t.upcut(CLIENTDATAOBJECT_SOCKET);
    t.upcut('=');
    t.cut('\n');
    Socket = t.stoi();
}


/******************************************************************************/
