/**  symboldata.h  *************************************************************

when      who   what
04.16.04  Dan   Creation.
04.24.04  Dan   Added.  New object symbols_o to hold trees of symboldata_o.
                Moved.  Symbol lists from dgtasker.  These are trees now.
                        Load from file and find in directory methods from
                        dgtasker to this.
06.08.04  Dan   Added.  Last Trade, Range, Open, Market Cap, Volume, and PE.



symboldata_o: Debug Level 4600-4610

*******************************************************************************/


#ifndef SYMBOLDATAOBJECT_H
#define SYMBOLDATAOBJECT_H

#include "string/string.h"
#include "memory/bstree.h"
#include "memory/list.h"

class symboldata_o  {
  private:
    string_o  Symbol;
    string_o  CompanyName;
    string_o  Exchange;
    string_o  LastTrade;
    string_o  Range;
    string_o  Open;
    string_o  MarketCap;
    string_o  Volume;
    string_o  PE;
    void*     V;

  public:
    symboldata_o();
    symboldata_o(const symboldata_o&);
   ~symboldata_o();
    symboldata_o& operator = (const symboldata_o&);

    void clear();

    void operator << (const char*);
    void operator >> (string_o&);

    const char* symbol() const;
    const char* companyName() const;
    const char* exchange() const;
    const char* lastTrade() const;
    const char* open() const;
    const char* range() const;
    const char* marketCap() const;
    const char* volume() const;
    const char* pe() const;
    void* voidp() const;

    void symbol(const char*);
    void companyName(const char*);
    void exchange(const char*);
    void lastTrade(const char*);
    void range(const char*);
    void open(const char*);
    void marketCap(const char*);
    void volume(const char*);
    void pe(const char*);
    void voidp(void*);

};

class symbols_o  {
  private:
    string_o Dirname;
    string_o Filename;

    bstree_o<symboldata_o> SymbolTreeDirectory;
    bstree_o<symboldata_o> SymbolTreeFile;
    bstree_o<symboldata_o> SymbolTree;

    bstreeSearch_o<symboldata_o>* SymbolTreeSearch;


public:
    symbols_o();
    symbols_o(const symbols_o&);
   ~symbols_o();
    symbols_o& operator = (const symbols_o&);

    int  save(const char*);
    int  load();
    int  directory();
    int  merge();
    int  filter();
    int  invalid();

    symboldata_o* first();
    symboldata_o* next();
    void          put(symboldata_o*);
    int           cardinality() const;

    const char* dirname() const;
    const char* filename() const;
    void dirname(const char*);
    void filename(const char*);
};

/******************************************************************************/

inline const char* symboldata_o::symbol() const  {
    return Symbol.string();
}

inline const char* symboldata_o::companyName() const  {
    return CompanyName.string();
}

inline const char* symboldata_o::exchange() const  {
    return Exchange.string();
}

inline const char* symboldata_o::lastTrade() const  {
    return LastTrade.string();
}

inline const char* symboldata_o::open() const  {
    return Open.string();
}

inline const char* symboldata_o::range() const  {
    return Range.string();
}

inline const char* symboldata_o::marketCap() const  {
    return MarketCap.string();
}

inline const char* symboldata_o::volume() const  {
    return Volume.string();
}

inline const char* symboldata_o::pe() const  {
    return PE.string();
}

inline void* symboldata_o::voidp() const  {
    return V;
}

inline int symbols_o::cardinality() const  {
    return SymbolTree.cardinality();
}

inline void symboldata_o::symbol(const char* s)  {
    Symbol = s;
}

inline void symboldata_o::companyName(const char* cn)  {
    CompanyName = cn;
}

inline void symboldata_o::exchange(const char* e)  {
    Exchange = e;
}

inline void symboldata_o::lastTrade(const char* lt)  {
    LastTrade = lt;
}

inline void symboldata_o::range(const char* r)  {
    Range = r;
}

inline void symboldata_o::open(const char* o)  {
    Open = o;
}

inline void symboldata_o::marketCap(const char* mc)  {
    MarketCap = mc;
}

inline void symboldata_o::volume(const char* v)  {
    Volume = v;
}

inline void symboldata_o::pe(const char* pe)  {
    PE = pe;
}

inline void symboldata_o::voidp(void* v)  {
    V = v;
}


inline void symbols_o::dirname(const char* dn)  {
    Dirname = dn;
}

inline void symbols_o::filename(const char* fn)  {
    Filename = fn;
}

inline const char* symbols_o::dirname() const  {
    return Dirname.string();
}

inline const char* symbols_o::filename() const  {
    return Filename.string();
}


#endif

/******************************************************************************/
