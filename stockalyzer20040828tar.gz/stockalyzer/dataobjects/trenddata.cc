/**  trenddata.cc  *************************************************************


changes log
when      who   what
05.22.04  Dan   Creation.

*******************************************************************************/


#include "trenddata.h"

trenddata_o::trenddata_o()  {
    X         = 0;
    Y         = 0;
    M         = 0;
    B         = 0;
    Hits      = 0;
    for(int x=0;x<256;x++)  Xx[x] = 0;
    Valid     = 0;
    TomorrowY = 0;
}

trenddata_o::trenddata_o(const trenddata_o& td)  {
    X         = td.X;
    Y         = td.Y;
    M         = td.M;
    B         = td.B;
    Hits      = td.Hits;
    for(int x=0;x<256;x++)  Xx[x] = td.Xx[x];
    Valid     = td.Valid;
    TomorrowY = td.TomorrowY;
}

trenddata_o::~trenddata_o()  {}

trenddata_o& trenddata_o::operator = (const trenddata_o& td)  {
    X         = td.X;
    Y         = td.Y;
    M         = td.M;
    B         = td.B;
    Hits      = td.Hits;
    for(int x=0;x<256;x++)  Xx[x] = td.Xx[x];
    Valid     = td.Valid;
    TomorrowY = td.TomorrowY;
    return *this;
}

void trenddata_o::clear()  {
    X         = 0;
    Y         = 0;
    M         = 0;
    B         = 0;
    Hits      = 0;
    for(int x=0;x<256;x++)  Xx[x] = 0;
    Valid     = 0;
    TomorrowY = 0;
}


void trenddata_o::operator >> (string_o& s)  {
    s << " trenddata_o:";
    s << X;
    s << " " << Y;
//  s << M << " ";
//  s << B << " ";
    s << " " << Hits;
    for(int x=0;x<256;x++)  s << " " << Xx[x];
//  s << " " << Valid;
    s << " " << TomorrowY;
}

#include <stdlib.h>
void trenddata_o::operator << (const char* o)  {
    string_o s;
    string_o t;

    s = o;
    s.upcut(" trenddata_o:");
    t = s;
    t.cut(' ');
    X = atoi(t.string());
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Y = atoi(t.string());
//  s.upcut(' ');
//  t = s;
//  t.cut(' ');
//  M = atoi(t.string());
//  s.upcut(' ');
//  t = s;
//  t.cut(' ');
//  B = atoi(t.string());
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Hits = atoi(t.string());
    for(int x=0;x<256;x++)  {
        s.upcut(' ');
        t = s;
        t.cut(' ');
        Xx[x] = atoi(t.string());
    }
//  s.upcut(' ');
//  t = s;
//  t.cut(' ');
//  Valid = atoi(t.string());
    s.upcut(' ');
    t = s;
    t.cut(' ');
    TomorrowY = atoi(t.string());
}



/******************************************************************************/
