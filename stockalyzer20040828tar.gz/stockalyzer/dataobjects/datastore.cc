/**  datastore.cc  *************************************************************


when      who   what
06.01.04  Dan   Creation. Created this object as single place to load
                          data objects.  Oringinally from analysis and plotchart.
07.14.04  Dan   Added.    Function loadHistdata(const char*,histdata_o*),
                          to load the most recient hsitdata_o.
08.24.04  Dan   Changed.  When storing analdata_o in a file, the histdata_o
                          portion is no longer saved with it, so, look for 
                          and load the indepenent histdata_o file with the
                          loadAnaldata method.  (However, the histdata_o
                          file is not stored with a saveAnaldata call, because 
                          this file should already exsit.)  And changed the
                          signeture of the load and saveAnaldata method from
                          requiering a filename to requiering a symboldata_o.
                Added.    load and saveTrenddata methods.  (Used to be part of
                          load/saveAnaldata.)
08.26.04  Dan   Added.    Method loadAnaldata with one datum, used to check
                          if the analdata_o is current.



Debug Level: 4690-4699
*******************************************************************************/


#include <fstream.h>

#include "datastore.h"
#include "log/log.h"

#include "symboldata.h"



extern log_o logg;


datastore_o::datastore_o()  {
    State = DATASTOREOBJECT_STATE_CLEAR;
}

datastore_o::~datastore_o()  {}


int datastore_o::loadAnaldata(const symboldata_o& symbol,list_o<analdata_o>* anallist)  {
    int x;
    string_o message;
    string_o s;
    string_o filename;
    char buffer[8192];
    ifstream in;
    ifstream in2;
    analdata_o* ad;
    bstree_o<analdata_o> adt;
    bstreeSearch_o<analdata_o> adts(&adt);
    histdata_o hd;

    for(x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';

    if(::logg.debug(4690))  {
        (message = "datastore_o: ") << "Start loadAnaldata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    if(!anallist)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << "/" << symbol.symbol();
    filename << '.' << ANALDATAOBJECT_OBJECT;

    in.open(filename.string());
    if(!in)  {
        State = DATASTOREOBJECT_STATE_FILE_NOT_FOUND;
        (message = "datastore_o: ") << "File `" << filename << "' not found.";
        ::logg.error(message);
        return State;
    }

    x = 0;
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        s = buffer;
        if(s.contains(ANALDATAOBJECT_OBJECT))  {
            ad = new analdata_o;
            *ad << buffer;
            if(ad->date() > 18000000)  {
                anallist->put(ad);
                (s = "") << ad->date();
                adt.insert(s,ad);
                x++;
            }
            else  {
                (message = "datastore_o: ") << "Parse error? loading " << symbol.symbol();
                message << " \"" << buffer << "\"";
                ::logg.error(message);
            }

            if(::logg.debug(4699))  {
                (message = "datastore_o: ") << "Loaded analdata_o date: " << ad->date();
                ::logg << message;
            }

        }
    }
    in.close();

    if(::logg.debug(4691))  {
        (message = "datastore_o: ") << "Finished loadAnaldata() for symbol " << symbol.symbol();
        message << ' ' << x << " dataums loaded.";
        ::logg << message;
    }


    filename = Directory;
    filename << "/" << symbol.symbol();
    filename << '.' << HISTDATAOBJECT_OBJECT;

    in2.open(filename.string());
    if(!in2)  {
        State = DATASTOREOBJECT_STATE_FILE_NOT_FOUND;
        (message = "datastore_o: ") << "File `" << filename << "' not found.";
        ::logg.error(message);
        return State;
    }


    x = 0;
    while(!in2.eof())  {
        in2.getline(buffer,sizeof(buffer)-1,'\n');
        if(in2.eof())  break;

        s = buffer;
        if(s.contains(HISTDATAOBJECT_OBJECT))  {
            hd << buffer;
            if(hd.date() > 18000000)  {
                (s = "") << hd.date();
                ad = (analdata_o*)adts.find(&s);
                if(ad)  {
                    *ad << hd;
                    x++;

                    if(::logg.debug(4699))  {
                        (message = "datastore_o: ") << "Loaded histdata_o date: " << ad->date();
                        ::logg << message;
                    }
                }
            }
            else  {
                (message = "datastore_o: ") << "Parse error? loading " << symbol.symbol();
                message << " \"" << buffer << "\"";
                ::logg.error(message);
            }


        }
    }
    in2.close();


    if(::logg.debug(4691))  {
        (message = "datastore_o: ") << "Finished loadAnaldata() for symbol " << symbol.symbol();
        message << ' ' << x << " dataums loaded.";
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_LOADED_ANALDATA;
    return State;
}


int datastore_o::saveAnaldata(const symboldata_o& symbol,list_o<analdata_o>* anallist)  {
    string_o message;
    string_o s;
    string_o filename;
    ofstream out;
    analdata_o* ad;

    if(::logg.debug(4692))  {
        (message = "datastore_o: ") << "Start saveAnaldata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    if(!anallist)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << ANALDATAOBJECT_OBJECT;

    out.open(filename.string());
    if(!out)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "File `" << filename << "' unable to open.";
        ::logg.error(message);
        return State;
    }

    ad = anallist->first();
    while(ad)  {
        s = "";
        *ad >> s;
        out << s.string() << '\n';
        ad = anallist->next();
    }
    out.close();

    if(::logg.debug(4693))  {
        (message = "datastore_o: ") << "Finished saveAnaldata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_SAVED_ANALDATA;
    return State;
}


int datastore_o::loadHistdata(const symboldata_o& symbol,list_o<histdata_o>* histlist)  {
    int x;
    string_o message;
    string_o s;
    string_o filename;
    char buffer[8192];
    ifstream in;
    histdata_o* hd;

    for(x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';

    if(::logg.debug(4690))  {
        (message = "datastore_o: ") << "Start loadHistdata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    if(!histlist)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << HISTDATAOBJECT_OBJECT;

    in.open(filename.string());
    if(!in)  {
        State = DATASTOREOBJECT_STATE_FILE_NOT_FOUND;
        (message = "datastore_o: ") << "File `" << filename << "' not found.";
        ::logg.error(message);
        return State;
    }

    x = 0;
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        s = buffer;
        if(s.contains(HISTDATAOBJECT_OBJECT))  {
            hd = new histdata_o;
            *hd << buffer;
            if(hd->date() > 18000000)  {
                histlist->put(hd);
                x++;
            }
            else  {
                (message = "datastore_o: ") << "Parse error? loading " << symbol.symbol();
                message << " \"" << buffer << "\"";
                ::logg.error(message);
            }

            if(::logg.debug(4699))  {
                (message = "datastore_o: ") << "Loaded histdata_o date: " << hd->date();
                ::logg << message;
            }

        }
    }
    in.close();

    if(::logg.debug(4691))  {
        (message = "datastore_o: ") << "Finished loadHistdata() for symbol " << symbol.symbol();
        message << ' ' << x << " dataums loaded.";
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_LOADED_HISTDATA;
    return State;
}


int datastore_o::saveHistdata(const symboldata_o& symbol,list_o<histdata_o>* histlist)  {
    string_o message;
    string_o s;
    string_o filename;
    ofstream out;
    histdata_o* hd;

    if(::logg.debug(4692))  {
        (message = "datastore_o: ") << "Start saveHistdata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    if(!histlist)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << HISTDATAOBJECT_OBJECT;

    out.open(filename.string());
    if(!out)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "File `" << filename << "' unable to open.";
        ::logg.error(message);
        return State;
    }

    hd = histlist->first();
    while(hd)  {
        s = "";
        *hd >> s;
        out << s.string() << '\n';
        hd = histlist->next();
    }
    out.close();

    if(::logg.debug(4693))  {
        (message = "datastore_o: ") << "Finished saveHistdata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_SAVED_HISTDATA;
    return State;
}


int datastore_o::loadTrenddata(const symboldata_o& symbol,list_o<trenddata_o>* trendlist)  {
    int x;
    string_o message;
    string_o s;
    string_o filename;
    char buffer[8192];
    ifstream in;
    trenddata_o* td;

    for(x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';

    if(::logg.debug(4690))  {
        (message = "datastore_o: ") << "Start loadTrenddata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    if(!trendlist)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << TRENDDATAOBJECT_OBJECT;

    in.open(filename.string());
    if(!in)  {
        State = DATASTOREOBJECT_STATE_FILE_NOT_FOUND;
        (message = "datastore_o: ") << "File `" << filename << "' not found.";
        ::logg.error(message);
        return State;
    }

    x = 0;
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        s = buffer;
        if(s.contains(TRENDDATAOBJECT_OBJECT))  {
            td = new trenddata_o;
            *td << buffer;
            if(td->date() > 18000000)  {
                trendlist->put(td);
                x++;
            }
            else  {
                (message = "datastore_o: ") << "Parse error? loading " << symbol.symbol();
                message << " \"" << buffer << "\"";
                ::logg.error(message);
            }

            if(::logg.debug(4699))  {
                (message = "datastore_o: ") << "Loaded trenddata_o date: " << td->date();
                ::logg << message;
            }

        }
    }
    in.close();

    if(::logg.debug(4691))  {
        (message = "datastore_o: ") << "Finished loadTrenddata() for symbol " << symbol.symbol();
        message << ' ' << x << " dataums loaded.";
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_LOADED_TRENDDATA;
    return State;
}


int datastore_o::saveTrenddata(const symboldata_o& symbol,list_o<trenddata_o>* trendlist)  {
    string_o message;
    string_o s;
    string_o filename;
    ofstream out;
    trenddata_o* td;

    if(::logg.debug(4692))  {
        (message = "datastore_o: ") << "Start saveTrenddata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    if(!trendlist)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << TRENDDATAOBJECT_OBJECT;

    out.open(filename.string());
    if(!out)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "File `" << filename << "' unable to open.";
        ::logg.error(message);
        return State;
    }

    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << TRENDDATAOBJECT_OBJECT;

    td = trendlist->first();
    while(td)  {
        s = "";
        *td >> s;
        out << s.string() << '\n';
        td = trendlist->next();
    }
    out.close();

    if(::logg.debug(4693))  {
        (message = "datastore_o: ") << "Finished saveTrenddata() for symbol " << symbol.symbol();
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_SAVED_TRENDDATA;
    return State;
}




int datastore_o::loadHistdata(const symboldata_o& symbol,histdata_o* hd)  {
    int x;  
    string_o message;
    string_o filename;
    char buffer[4096];
    ifstream in;
    string_o s;

    for(x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';
     
    if(::logg.debug(4694))  {
        (message = "datastore_o: ") << "Start loadHistdata().";
        ::logg << message;
    }

    if(!hd)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }


    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << HISTDATAOBJECT_OBJECT;

    in.open(filename.string());
    if(!in)  {
        State = DATASTOREOBJECT_STATE_VOID;
        (message = "datastore_o: ") << "File `" << filename << "' not found.";
        ::logg.error(message);
        return State;
    }

    in.getline(buffer,sizeof(buffer)-1,'\n');
    *hd << buffer;

    if(::logg.debug(4698))  {
        (message = "datastore_o: ") << "Loaded histdata_o date: " << hd->date();
        ::logg << message;
    }
    in.close();

    if(::logg.debug(4695))  {
        (message = "datastore_o: ") << "Finished loadHistdata().";
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_LOADED_HISTDATA;
    return State;
}


int datastore_o::loadAnaldata(const symboldata_o& symbol,analdata_o* ad)  {
    int x;  
    string_o message;
    string_o filename;
    char buffer[4096];
    ifstream in;
    string_o s;

    for(x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';
     
    if(::logg.debug(4694))  {
        (message = "datastore_o: ") << "Start loadAnaldata().";
        ::logg << message;
    }

    if(!ad)  {
        State = DATASTOREOBJECT_STATE_NULL_PASSED;
        (message = "datastore_o: ") << "Null passed.";
        ::logg.error(message);
        return State;
    }


    filename = Directory;
    filename << '/' << symbol.symbol();
    filename << '.' << ANALDATAOBJECT_OBJECT;

    in.open(filename.string());
    if(!in)  {
        State = DATASTOREOBJECT_STATE_FILE_NOT_FOUND;
        (message = "datastore_o: ") << "File `" << filename << "' not found.";
        ::logg.error(message);
        return State;
    }

    in.getline(buffer,sizeof(buffer)-1,'\n');
    *ad << buffer;

    if(::logg.debug(4698))  {
        (message = "datastore_o: ") << "Loaded analdata_o date: " << ad->date();
        ::logg << message;
    }
    in.close();

    if(::logg.debug(4695))  {
        (message = "datastore_o: ") << "Finished loadAnaldata().";
        ::logg << message;
    }

    State = DATASTOREOBJECT_STATE_LOADED_ANALDATA;
    return State;
}


