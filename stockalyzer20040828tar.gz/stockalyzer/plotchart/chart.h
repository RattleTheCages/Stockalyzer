/**  chart.h  ******************************************************************


when      who   what
04.04.04  Dan   Creation.
04.08.04  Dan   Changed.  Abstrated this original into seperate object
                components including chart_o and drawchart_o.
04.12.04  Dan   Added.  New analdata_o object.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.


*******************************************************************************/


#ifndef CHARTOBJECT_H
#define CHARTOBJECT_H

#ifndef NULL
#define NULL 0
#endif


#include "../dataobjects/analdata.h"
#include "../analysis/support.h"
#include "../dataobjects/histdata.h"
#include "string/string.h"
#include "memory/list.h"



class chart_o  {
  friend class drawchart_o;
  friend class plotchart_o;
  private:
    string_o Symbol;
    list_o<histdata_o> Prices;
    list_o<analdata_o> AnalysisPrices;
public:
    support_o* Support;
    int High;
    int Low;
    int Range;

    string_o FirstMonth;
    string_o LastMonth;


  public:
    chart_o();
    chart_o(const char*,list_o<analdata_o>&);
    chart_o(const chart_o&);
   ~chart_o();
    chart_o& operator = (const chart_o&);

    void clear();


    int  high() const;
    void high(int i);
    int  low() const;
    void low(int i);
    int  range() const;

    list_o<analdata_o>* prices();

    const char* firstMonth() const;
    void firstMonth(const char*);
    const char* lastMonth() const;
    void lastMonth(const char*);

    const char* symbol() const;
};

/******************************************************************************/


inline int chart_o::high() const  {
    return High;
}

inline int chart_o::low() const  {
    return Low;
}

inline int chart_o::range() const  {
    return Range;
}

inline const char* chart_o::firstMonth() const  {
    return FirstMonth.string();
}

inline const char* chart_o::lastMonth() const  {
    return LastMonth.string();
}

inline const char* chart_o::symbol() const  {
    return Symbol.string();
}

inline list_o<analdata_o>* chart_o::prices()  {
    return &AnalysisPrices;
}


#endif

/******************************************************************************/
