/**  drawchart.h  **************************************************************


when      who    what
04.04.04  Dan    Creation.
04.09.04  Dan    Changed.  Abstrated this original into seperate object
                 components including chart_o and drawchart_o.
05.05.04  Dan    Added.  MACD.
05.30.04  Dan    Added.  Ploting the trend lines.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.


*******************************************************************************/


#ifndef DRAWCHARTOBJECT_H
#define DRAWCHARTOBJECT_H


#include "chart.h"


#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>

#include "memory/list.h"
#include "../dataobjects/analdata.h"



class drawchart_o  {
  private:
    list_o<analdata_o> DatumList;
    int WinHeight;
    int WinWidth;
    int DrawTimeLog;
    int DrawNumberOfDatums;
    int DrawHeight;
    int DrawWidth;
    int DrawHeightMargen;
    int DrawWidthMargen;

    int DrawSupportLimit;
    int LastX;

    chart_o* Chart;

    float    XSpreadHigh;
    float    XSpreadLow;
    float    XSpread;
    float    YSpreadHigh;
    float    YSpreadLow;
    float    YSpread;
    int      MACD1226EMA9High;


    int      plotSupportLines(analdata_o*,float);
    int      plotTrendLines();

public:

    int findLimits();


  public:
    drawchart_o();
    drawchart_o(chart_o*,int);
    drawchart_o(const drawchart_o&);
   ~drawchart_o();
    drawchart_o& operator = (const drawchart_o&);

    void clear();


    int  winHeight() const;
    void winHeight(int i);
    int  winWidth() const;
    void winWidth(int i);

    int  drawHeight() const;
    void drawHeight(int i);
    int  drawWidth() const;
    void drawWidth(int i);


    int drawchart();


  private:
    int ColorBackground;
    int ColorSignature;
    int ColorSupport;
    int ColorTrendLow;
    int ColorTrendHigh;
    int ColorTrendProjection;
    int ColorMA50;
    int ColorMA200;
    int ColorEMA9;
    int ColorEMA33;
    int ColorVMA50;
    int ColorVMA200;

    int ColorGrids;
    int ColorIndicies;
    int ColorSpread;
    int ColorUp;
    int ColorDown;

};

/******************************************************************************/


inline int drawchart_o::winHeight() const  {
    return WinHeight;
}

inline int drawchart_o::winWidth() const  {
    return WinWidth;
}

inline int drawchart_o::drawHeight() const  {
    return DrawHeight;
}

inline int drawchart_o::drawWidth() const  {
    return DrawWidth;
}



#endif

/******************************************************************************/
