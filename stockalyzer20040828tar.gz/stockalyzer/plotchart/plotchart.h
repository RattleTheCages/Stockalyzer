/**  plotchart.h  ***************************************************************


when      who   what
04.04.04  Dan   Creation.
04.08.04  Dan   Changed.  Abstrated this original into seperate object
                components including chart_o and drawchart_o.
04.12.04  Dan   Added.  New analdata_o object.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.



*******************************************************************************/


#ifndef PLOTCHARTOBJECT_H
#define PLOTCHARTOBJECT_H


#include "drawchart.h"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>

#include "log/log.h"

#include "../dataobjects/analdata.h"
#include "../dataobjects/trenddata.h"

//extern log_o logg;


#define DEFAULT_SIZE 256
#define FONT "-adobe-times-medium-r-normal--10-100-75-75-p-54-iso8859-1"





class plotchart_o  {
  friend class drawchart_o;
  private:
    int State;

//  list_o<analdata_o> list;
//  list_o<analdata_o> list2;
public:
    list_o<analdata_o> prices;
private:
    bstree_o<analdata_o> pricestree;
    list_o<trenddata_o> trendlist;
    bstree_o<trenddata_o> trendtree;
    bstree_o<int> date2xtree;



  public:
    plotchart_o();
    plotchart_o(const plotchart_o&);
   ~plotchart_o();
    plotchart_o& operator = (const plotchart_o&);


chart_o* Chart;
drawchart_o* Drawchart;


int screen_num,font_height;
unsigned long whitepixel,blackpixel;
Display* display;
char* display_name;
Window win;
Window win2;
XFontStruct* font_info;
GC gc;
XColor background, foreground,baseline;
char* window_name;

XEvent xevent;


int zz;
int xx;
int yy;



    int plot();
    int xeventloop();

    int main();

    int loadAnalysisPrices(const char*);
};

/******************************************************************************/




#endif

/******************************************************************************/
