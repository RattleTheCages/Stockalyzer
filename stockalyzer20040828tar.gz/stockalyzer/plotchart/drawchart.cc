/**  drawchart.cc  *************************************************************


when      who   what
04.04.04  Dan   Creation.
04.09.04  Dan   Changed.  Abstrated this original into seperate object
                components including chart_o and drawchart_o.
04.12.04  Dan   Added.  New analdata_o object.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.


*******************************************************************************/

#include "drawchart.h"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>


#include <iostream.h>
#include "other/rand.h"
#include "other/sysinfo.h"
#include "log/log.h"
#include "memory/list.h"

#include "../dataobjects/histdata.h"
#include "../dataobjects/analdata.h"

#include "plotchart.h"

extern log_o logg;
extern plotchart_o* plotchart;

extern XSizeHints size_hints;

list_o<histdata_o> prices2;
//chart_o chart;


    string_o message;
    string_o s;
    string_o t;
    string_o month;
    string_o firstMonth;
    string_o lastMonth;
    string_o symbol;
    int      x,y,z,j,i,d,d2;
    float    yy;
    histdata_o* hd;
    analdata_o* ad;
    analdata_o* adSupport;
    analdata_o* adFirst;
    analdata_o* adLast;

    //int screen_num,screen_height,screen_width;
    int screen_height,screen_width;
    //int display_height,display_width;

bstreeSearch_o<analdata_o>* analSearch;


drawchart_o::drawchart_o()  {
    clear();
}

void drawchart_o::clear()  {
    DrawTimeLog = 0;
    DrawNumberOfDatums = 0;
    DrawSupportLimit = 0;
    LastX = 0;

    XSpreadHigh = 0;
    XSpreadLow = 0;
    XSpread = 0;
    YSpreadHigh = 0;
    YSpreadLow = 0;
    YSpread = 0;
    MACD1226EMA9High = 0;

    //ColorBackground = 138;
    ColorSignature = 1376;
    ColorSupport = 250;
    ColorTrendLow = 40*4;
    ColorTrendHigh = 80*80;
    ColorMA50  = 170*4;
    ColorMA200 = 220*4;
    ColorEMA9  = 210*4;
    ColorEMA33 = 200*4;
    ColorVMA50  = 220*4;
    ColorVMA200 = 230*4;

    ColorGrids = 198;
    ColorIndicies = 198;
    //ColorIndicies = 255;

    ColorSpread = 25515;
    ColorUp = 1376;
    ColorDown = 55300;
    ColorTrendProjection = 65432-(256*126);
}

drawchart_o::drawchart_o(chart_o* chart,int drawNumberOfDatums)  {
    DrawTimeLog = 0;
    //DrawTimeLog = 1;


    clear();

    if(drawNumberOfDatums >= 0)  DrawNumberOfDatums = drawNumberOfDatums;


    WinHeight =size_hints.height-20;
    WinWidth =size_hints.width-2;

    DrawHeight = WinHeight - 160;
    DrawWidth = WinWidth - 80;

    DrawHeightMargen = 80;


    Chart = chart;


    findLimits();
}

drawchart_o::~drawchart_o()  {}


int drawchart_o::findLimits()  {
    int index;
    analdata_o* ad;

    YSpreadLow = log10(Chart->low());
    YSpreadHigh = log10(Chart->high());
    YSpread = YSpreadHigh - YSpreadLow;


    ad = Chart->AnalysisPrices.first();
    index = 0;
    while(ad)  {

        index++;
        if(index > Chart->AnalysisPrices.cardinality()-DrawNumberOfDatums)  {
            DatumList.put(ad);
            if(abs(ad->macd1226ema9()) > MACD1226EMA9High){  MACD1226EMA9High = abs(ad->macd1226ema9());
}
        }
        ad = Chart->AnalysisPrices.next();
    }
    while(MACD1226EMA9High < (DrawHeightMargen/2))  MACD1226EMA9High = MACD1226EMA9High * 1.33;
    //MACD1226EMA9High = MACD1226EMA9High * 1.33;


    XSpreadLow = 0;
    //XSpreadHigh = log(DatumList.cardinality());
    XSpreadHigh = DatumList.cardinality();
    XSpread = XSpreadHigh - XSpreadLow;

    return 0;
}


int drawchart_o::drawchart()  {
int* xp;
int tmp;
int index;
int rowmod;
float xx;
string_o message;
int macdtoggle=0;

DrawSupportLimit = 3;



//XSetWindowBackground(plotchart->display,plotchart->win,ColorBackground);


rowmod = 500;

        for(y=Chart->low();y<Chart->high();y++)  {
            if(!(y % rowmod))  {
                yy = ((log10(y)-YSpreadLow)/YSpread) * DrawHeight;

                for(x=0;x<WinWidth-30;x++)  {
                    XSetForeground(plotchart->display,plotchart->gc,ColorGrids);
                    XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,x,(DrawHeight-(int)yy)+DrawHeightMargen);

                    (s = "") << y;
                    XSetForeground(plotchart->display,plotchart->gc,ColorIndicies);
                    XDrawString(plotchart->display,plotchart->win,plotchart->gc,WinWidth-30,(DrawHeight-(int)yy)+DrawHeightMargen,s.string(),s.length());
                }
            }
        }


        XSetForeground(plotchart->display,plotchart->gc,255);
        x = 0;
        d = 11;
        d2 = 11;
        ad = DatumList.first();
        adFirst = ad;
        index = 0;
        (s = "") << ad->date();
        s.upcut(4);
        s.cut(2);
        month = s;
        while(ad)  {


if(DrawTimeLog)  {
xx = ((log(x)-XSpreadLow)/XSpread) * DrawWidth;
xx = (xx - DrawWidth/2)*2;
}
else  {
//xx = x;
xx = (((float)x - XSpreadLow)/XSpread) * DrawWidth;
//(message="")<<"xx "<<xx << "  x " << x<<"  (((float)x - XSpreadLow)/XSpread) " << (((float)x - XSpreadLow)/XSpread) << "  DrawWidth " << DrawWidth;
//::logg<<message;
}

            (s = "") << ad->date();
            s.upcut(4);
            s.cut(2);
            if(!(month == s))  {
                month = s;

                for(z=0;z<DrawHeight;z++)  {
                    XSetForeground(plotchart->display,plotchart->gc,ColorGrids);
                    XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,z+DrawHeightMargen);
                }

                (s = "") << ad->date();
                s.cut(6);
                XSetForeground(plotchart->display,plotchart->gc,ColorIndicies);
                XDrawString(plotchart->display,plotchart->win,plotchart->gc,(int)xx-16,d+DrawHeightMargen,s.string(),s.length());

                d = d + 11;
                if(d > 34)  d = 11;
                if(d > 11)  d = 11;
            }


            for(y=ad->low();y<ad->high();y++)  {
                yy = ((log10(y)-YSpreadLow)/YSpread) * DrawHeight;
                XSetForeground(plotchart->display,plotchart->gc,ColorSpread);
                XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);
            }

            if(ad->close() < ad->open())  {
                XSetForeground(plotchart->display,plotchart->gc,ColorDown);
                for(y=ad->close();y<ad->open();y++)  {
                    yy = ((log10(y)-YSpreadLow)/YSpread) * DrawHeight;
                    XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);
                }
            }
            else  {
                XSetForeground(plotchart->display,plotchart->gc,ColorUp);
                for(y=ad->open();y<ad->close();y++)  {
                    yy = ((log10(y)-YSpreadLow)/YSpread) * DrawHeight;
                    XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);
                }
            }

            XSetForeground(plotchart->display,plotchart->gc,ColorMA50);
            yy = ((log10(ad->ma50())-YSpreadLow)/YSpread) * DrawHeight;
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);
            XSetForeground(plotchart->display,plotchart->gc,ColorMA200);
            yy = ((log10(ad->ma200())-YSpreadLow)/YSpread) * DrawHeight;
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);
            XSetForeground(plotchart->display,plotchart->gc,ColorEMA9);
            yy = ((log10(ad->ema9())-YSpreadLow)/YSpread) * DrawHeight;
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);
            XSetForeground(plotchart->display,plotchart->gc,ColorEMA33);
            yy = ((log10(ad->ema33())-YSpreadLow)/YSpread) * DrawHeight;
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(DrawHeight-(int)yy)+DrawHeightMargen);

            XSetForeground(plotchart->display,plotchart->gc,ColorEMA33);
            tmp = (-1*ad->macd1226ema9()+200)/5;
            tmp = (-1*ad->macd1226()+MACD1226EMA9High)/(MACD1226EMA9High/(DrawHeightMargen/2));
            yy = tmp;
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(int)yy);
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx+1,(int)yy);
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(int)yy+1);
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx+1,(int)yy+1);
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(int)DrawHeightMargen/2);
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx+1,(int)DrawHeightMargen/2);

            tmp = (-1*ad->macd1226ema9()+200)/5;
            tmp = (-1*ad->macd1226ema9()+MACD1226EMA9High)/(MACD1226EMA9High/(DrawHeightMargen/2));
            yy = tmp;
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,(int)yy);
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx+1,(int)yy);

if(macdtoggle==0)  {
    if(ad->macd1226() < ad->macd1226ema9())  {
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,3);
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,2);
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx+1,2);
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx-1,2);

        macdtoggle = 1;
    }
}
else  {
    if(ad->macd1226() > ad->macd1226ema9())  {
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,2);
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx,3);
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx+1,3);
        XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,(int)xx-1,3);

        macdtoggle = 0;
    }
}



            plotSupportLines(ad,xx);



            xp = new int(x);
            (s = "") << ad->date();
            plotchart->date2xtree.insert(s,xp);

            x++;
            LastX = x;
            adLast = ad;
            ad = DatumList.next();
        }


        plotTrendLines();



        XSetForeground(plotchart->display,plotchart->gc,ColorMA50);
        (s = "") << "sma(50) = " << adLast->ma50();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,205,WinHeight-12,s.string(),s.length());

        XSetForeground(plotchart->display,plotchart->gc,ColorMA200);
        (s = "") << "sma(200) = " << adLast->ma200();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,205,WinHeight-2,s.string(),s.length());

        XSetForeground(plotchart->display,plotchart->gc,ColorEMA9);
        (s = "") << "ema(9) = " << adLast->ema9();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,205,WinHeight-32,s.string(),s.length());
        XSetForeground(plotchart->display,plotchart->gc,ColorEMA33);
        (s = "") << "ema(33) = " << adLast->ema33();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,205,WinHeight-22,s.string(),s.length());

        XSetForeground(plotchart->display,plotchart->gc,ColorVMA50);
        (s = "") << "vma(50) = " << adLast->vma50();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,280,WinHeight-2,s.string(),s.length());
        XSetForeground(plotchart->display,plotchart->gc,ColorVMA200);
        (s = "") << "vma(200) = " << adLast->vma200();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,280,WinHeight-12,s.string(),s.length());
        XSetForeground(plotchart->display,plotchart->gc,ColorVMA200);
        (s = "") << "macd(12,26,9) = " << adLast->macd1226();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,280,WinHeight-22,s.string(),s.length());


        XSetForeground(plotchart->display,plotchart->gc,ColorSignature);
        (s = "") << "high = " << adLast->high();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,122,WinHeight-32,s.string(),s.length());
        (s = "") << "low = " << adLast->low();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,122,WinHeight-22,s.string(),s.length());
        (s = "") << "close = " << adLast->close();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,122,WinHeight-12,s.string(),s.length());
        (s = "") << "volume = " << adLast->volume();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,122,WinHeight-2,s.string(),s.length());

        XSetForeground(plotchart->display,plotchart->gc,ColorSignature);
        s = "(c) 2004 Rattle Charts(tm)";
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,2,WinHeight-2,s.string(),s.length());

        (s = "") << Chart->symbol() << ' ' << adFirst->date() << '-' << adLast->date();
        XDrawString(plotchart->display,plotchart->win,plotchart->gc,2,WinHeight-12,s.string(),s.length());


    return 0;

}


int drawchart_o::plotTrendLines()  {
    string_o s;
    int i;
    float yy;
    float yy2;
    float yyy;
    float yyTomorrow;
    trenddata_o* td;
    analdata_o* ad1;
    analdata_o* ad2;
    analdata_o* ad3;
    int* x1;
    int* x2;
    int* x3;
    float xx1;
    float xx2;
    float xx3;
    float xxLast;
    bstreeSearch_o<trenddata_o> trendtreeSearch(&plotchart->trendtree);
    bstreeSearch_o<analdata_o> pricestreeSearch(&plotchart->pricestree);
    bstreeSearch_o<int> date2xSearch(&plotchart->date2xtree);
    analdata_o* ad;


    ad = DatumList.first();
    while(ad)  {

(s = "") << ad->date();
td = (trenddata_o*)trendtreeSearch.find(&s);

    if(td)  {

        i = 0;
        while(td->Xx[i] != 0 && i < 256)  i++;

//cout<<i<<endl;

(s = "") << td->Xx[0];
ad1 = (analdata_o*)pricestreeSearch.find(&s);
x1 = (int*)date2xSearch.find(&s);
(s = "") << td->Xx[i-2];
ad2 = (analdata_o*)pricestreeSearch.find(&s);
x2 = (int*)date2xSearch.find(&s);
(s = "") << td->Xx[i-1];
ad3 = (analdata_o*)pricestreeSearch.find(&s);
x3 = (int*)date2xSearch.find(&s);


//cout<<ad1->close()<<":"<<*x1<< " - "<<ad3->close()<<":"<<*x3<<endl;


xx1 = (((float)*x1 - XSpreadLow)/XSpread) * DrawWidth;
xx2 = (((float)*x2 - XSpreadLow)/XSpread) * DrawWidth;
xx3 = (((float)*x3 - XSpreadLow)/XSpread) * DrawWidth;
xxLast = (((float)(LastX+1) - XSpreadLow)/XSpread) * DrawWidth;

yy = ((log10( ad1->close() )-YSpreadLow)/YSpread) * DrawHeight;
yy2 =  ((log10( ad2->close() )-YSpreadLow)/YSpread) * DrawHeight;
yyy =  ((log10( ad3->close() )-YSpreadLow)/YSpread) * DrawHeight;
yyTomorrow =  ((log10( td->tomorrowY() )-YSpreadLow)/YSpread) * DrawHeight;

if(ad->trendPoint() < 0)  {
        XSetForeground(plotchart->display,plotchart->gc,ColorTrendLow);
}
else  {
        XSetForeground(plotchart->display,plotchart->gc,ColorTrendHigh);
        XSetForeground(plotchart->display,plotchart->gc,ColorTrendLow);
}


XDrawLine(plotchart->display,plotchart->win,plotchart->gc,
(int)xx1,(DrawHeight-(int)yy)+DrawHeightMargen,
(int)xx3,(DrawHeight-(int)yyy)+DrawHeightMargen
);


//cout<<(int)xx1<<","<<(DrawHeight-(int)yy)+DrawHeightMargen<<":"<<(int)xx3<<","<<(DrawHeight-(int)yyy)+DrawHeightMargen<<endl;

XDrawLine(plotchart->display,plotchart->win,plotchart->gc,
(int)xx1,(DrawHeight-(int)yy-1)+DrawHeightMargen,
(int)xx3,(DrawHeight-(int)yyy-1)+DrawHeightMargen
);



if(td->tomorrowY() > Chart->low() && td->tomorrowY() < Chart->high())  {
        XSetForeground(plotchart->display,plotchart->gc,ColorTrendProjection);

XDrawLine(plotchart->display,plotchart->win,plotchart->gc,(int)xx3,
(DrawHeight-(int)yyy)+DrawHeightMargen,
(int)xxLast,(DrawHeight-(int)yyTomorrow)+DrawHeightMargen
);
(s = "") << td->tomorrowY();
XDrawString(plotchart->display,plotchart->win,plotchart->gc,xxLast,(DrawHeight-(int)yyTomorrow)+DrawHeightMargen,s.string(),s.length());

}

    }


    ad = DatumList.next();
}

    return 0;
}


int drawchart_o::plotSupportLines(analdata_o* ad,float xx)  {
    string_o s;
    int i;
    float yy;

    if(ad->dsupport() > DrawSupportLimit)  {
        XSetForeground(plotchart->display,plotchart->gc,ColorSupport);
        yy = ((log10(ad->close())-YSpreadLow)/YSpread) * DrawHeight;
        for(i=xx;i<WinWidth-40;i++)  {
            XDrawPoint(plotchart->display,plotchart->win,plotchart->gc,i,(DrawHeight-(int)yy)+DrawHeightMargen);
            (s = "") << ad->close() << ';' << ad->dsupport();
            XDrawString(plotchart->display,plotchart->win,plotchart->gc,WinWidth-40,(DrawHeight-(int)yy)+DrawHeightMargen,s.string(),s.length());
        }
    }


            (s = "");
            Chart->Support->stringDatePrice(ad,s);
            analSearch = new bstreeSearch_o<analdata_o>(&Chart->Support->DatePriceTree);
            adSupport = (analdata_o*)analSearch->find(&s);
            if(adSupport)  {

                if(adSupport->dsupport() > DrawSupportLimit)  {

                    (s = "") << adSupport->close();
                    XSetForeground(plotchart->display,plotchart->gc,ColorSupport);
                    XDrawString(plotchart->display,plotchart->win,plotchart->gc,(int)xx,WinHeight-d2-30,s.string(),s.length());
                    d2 = d2 + 11;
                    if(d2 > 34)  d2 = 11;
                }
            }
            delete analSearch;

    return 0;
}

/******************************************************************************/

