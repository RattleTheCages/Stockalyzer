/**  chart.cc  *****************************************************************


changes log
when      who   what
04.04.04  Dan   Creation.
04.08.04  Dan   Changed.  Abstrated this original into seperate object
                components including chart_o and drawchart_o.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.


*******************************************************************************/


#include "chart.h"

#include "log/log.h"
extern log_o logg;

chart_o::chart_o()  {}

chart_o::chart_o(const char* symbol,list_o<analdata_o>& adl)  {
    analdata_o* ad;
    analdata_o* adn;
    string_o    s;
    symboldata_o symbold;

    Symbol = symbol;
    symbold.symbol(symbol);
    Support = new support_o(&symbold);

    ad         = adl.first();
    FirstMonth = ad->date(); 
    Low        = ad->low();
    High       = ad->high();
    while(ad)  {
        adn = new analdata_o(*ad);

        AnalysisPrices.put(adn);
        Support->put(adn);

        if(ad->low() < Low)  Low = ad->low();
        if(ad->high() > High)  High = ad->high();
        LastMonth = ad->date();

        ad = adl.next();
    }

    Range = High - Low;

    FirstMonth.upcut('-');
    s = FirstMonth;
    s.upcut('-');
    FirstMonth.cut('-');
    FirstMonth << s;

    LastMonth.upcut('-');
    s = LastMonth;
    s.upcut('-');
    LastMonth.cut('-');
    LastMonth << s;
}


chart_o::~chart_o()  {
    histdata_o* hd;

    hd = Prices.get();
    while(hd)  {
        delete hd;
        hd = Prices.get();
    }
    //Prices.clear();
}

void chart_o::clear()  {
    histdata_o* hd;

    Symbol = "";
    High  = 0;
    Low   = 0;

    FirstMonth = "";
    LastMonth = "";

    hd = Prices.get();
    while(hd)  {
        delete hd;
        hd = Prices.get();
    }
    //Prices.clear();
}

void chart_o::high(int dh)  {
    High = dh;
}

void chart_o::low(int dl)  {
    Low = dl;
}

void chart_o::firstMonth(const char* fm)  {
    FirstMonth = fm;
}

void chart_o::lastMonth(const char* lm)  {
    LastMonth = lm;
}


/******************************************************************************/
