/**  plotchart.cc  *************************************************************


when      who   what
04.04.04  Dan   Creation.
04.08.04  Dan   Changed.  Abstrated this orignal into seperate object
                components including chart_o and drawchart_o.
04.12.04  Dan   Added.  New analdata_o object.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.


*******************************************************************************/



#include "plotchart.h"
#include "../dataobjects/datastore.h"

#include <fstream.h>


log_o logg;
datastore_o datastore;


plotchart_o* plotchart;


XSizeHints size_hints = { PMinSize | PWinGravity,0,0,DEFAULT_SIZE,
	DEFAULT_SIZE,DEFAULT_SIZE, DEFAULT_SIZE, 0,0,0,0,{0,0},{0,0},0,0,
	NorthWestGravity};

static unsigned long defcolors[65535];




plotchart_o::plotchart_o()  {
//*(display_name) = '\0';
State = 0;

display_name = new char(4096);


//char *window_name="VERSION";


zz=20000;
xx = 0;
yy = 0;


size_hints.height = 600;
size_hints.width = 900;

}

plotchart_o::~plotchart_o()  {}


int plotchart_o::plot()  {
/*
    for(int z=0;z<65535;z++)  {
        XSetForeground(display,gc,z);
        XDrawPoint(display,win,gc,xx,yy);
        xx++;
        if(xx > 256)  {
            yy++;
            xx = 0;
        }
    }

    XSetForeground(display,gc,0);
    XDrawString(display,win,gc,100,100,"Jessica",7);
    XDrawString(display,win,gc,100,110,"   +   ",7);
    XDrawString(display,win,gc,100,120,"  Dan  ",7);
*/



    Drawchart->drawchart();


Pixmap pixmap;

pixmap = XCreatePixmap(display,win,size_hints.width,size_hints.height,DefaultDepth(display,screen_num));


XCopyArea(display,win,pixmap,gc,0,0,size_hints.width,size_hints.height,0,0);

//XMapWindow(display, win2);
//XSetWindowBackgroundPixmap(display,win2,pixmap);
//XWriteBitmapFile(display,"f.bmp",pixmap,size_hints.width,size_hints.height,-1,-1);
}

int plotchart_o::xeventloop()  {
    while(XEventsQueued(display,QueuedAfterFlush)) {
        XNextEvent(display, &xevent);
            switch(xevent.type)  {   
                case Expose:
                case ConfigureNotify:
                case KeyPress:
                case CirculateNotify:
                case GravityNotify:
                case MapNotify:
                case ReparentNotify:
                case UnmapNotify:
                case MappingNotify:

                    plot();

                    break;

                default:
                    break;
            }
        }
}

int plotchart_o::main()  {

//int main(int argc,char* argv[])  {
    XGCValues     xgcvalues;
    XWMHints      wm_hints;
    XClassHint    class_hints;
    XSetWindowAttributes window_attributes;


    display = XOpenDisplay(display_name);
    if(!display)  return 1;

    screen_num = DefaultScreen(display);
    whitepixel = WhitePixel(display, screen_num);
    blackpixel = BlackPixel(display, screen_num);

    window_attributes.background_pixel = background.pixel;
    window_attributes.backing_store = WhenMapped;
    win = XCreateWindow(display, RootWindow(display, screen_num),
        size_hints.x, size_hints.y, size_hints.width, size_hints.height,
        0, CopyFromParent, InputOutput,  CopyFromParent,
        CWBackPixel | CWBackingStore, &window_attributes);

win2 = XCreateWindow(display, RootWindow(display, screen_num),
size_hints.x, size_hints.y, size_hints.width, size_hints.height,
0, CopyFromParent, InputOutput,  CopyFromParent,
CWBackPixel | CWBackingStore, &window_attributes);

    XSelectInput(display, win, StructureNotifyMask |
                 ExposureMask | KeyPressMask);

    if((font_info = XLoadQueryFont(display, FONT))==NULL)  return 2;
    font_height=font_info->max_bounds.ascent + font_info->max_bounds.descent;

    xgcvalues.foreground = foreground.pixel;
    xgcvalues.background = background.pixel;
    xgcvalues.line_width = 0;
    xgcvalues.graphics_exposures = False;
    xgcvalues.font = font_info->fid;

    gc = XCreateGC(display, win, GCFont | GCLineWidth |
        GCForeground | GCBackground | GCGraphicsExposures, &xgcvalues);

    wm_hints.flags = InputHint;
    wm_hints.input = True;

    class_hints.res_name = window_name;
    class_hints.res_class =  "XSysStats";


XSetWindowBackground(plotchart->display,plotchart->win,65532);

    XMapWindow(display, win);
    XClearWindow(display,win);
    XFlush(display);



Drawchart = new drawchart_o(Chart,400);


    while(2)  {
        XNextEvent(display,&xevent);
        xeventloop();
    }

    return 0;
}



int main(int argc,char* argv[])  {
    int x;
    string_o message;

    ::logg.registerName(argv[0]);
    for(x=4690;x<=4699;x++)  ::logg.setDebugLevel(x);

    plotchart = new plotchart_o;

    if(argc < 2)  {
        (message = "") << "Enter a symbol.";
        ::logg.error(message);

        return - 1;
    }
    else  {
        message = argv[1];
        message << ".analdata_o";
    }
    

    plotchart->loadAnalysisPrices(message.string());

    message.cut('.');


    plotchart->Chart = new chart_o(message.string(),plotchart->prices);



    plotchart->main();

    return 0;
}

//#include <iostream.h>
int plotchart_o::loadAnalysisPrices(const char* filename)  {
    int x;
    int* xp;
    string_o message;
    string_o s;
    string_o t;
    analdata_o* ad;
    trenddata_o* td;
    list_o<analdata_o> list;
    list_o<analdata_o> list2;

    symboldata_o symbol;

    s = filename;
    s.cut('.');
    symbol.symbol(s.string());

    datastore.loadAnaldata(symbol,&list);
    datastore.loadTrenddata(symbol,&trendlist);

    ad = list.first();
    while(ad)  {
        (s = "") << ad->date();
        pricestree.insert(s,ad);
        ad = list.next();
    }

    td = trendlist.first();
    while(td)  {
        (s = "") << td->x();
        trendtree.insert(s,td);
        td = trendlist.next();
    }


    x = list.cardinality();
    while(prices.cardinality() < x)  {
        ad = list.get();
        while(list.cardinality())  {
            list2.put(ad);
            ad = list.get();
        }
        prices.put(ad);
        ad = list2.get();
        while(list2.cardinality())  {
            list.put(ad);
            ad = list2.get();
        }
        list.put(ad);
    }


    State = 1;
    return State;
}


