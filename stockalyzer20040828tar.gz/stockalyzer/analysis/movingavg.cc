/**  movingavg.cc  *************************************************************


changes log
when      who   what
04.10.04  Dan   Creation.
04.18.04  Dan   Added.  Average volume.

*******************************************************************************/


#include "movingavg.h"


movingavg_o::movingavg_o()  {
    int x;
    MA50i = 0;
    MA50v = 0;
    MA200i = 0;
    MA200v = 0;
    VMA50i = 0;
    VMA50v = 0;
    VMA200i = 0;
    VMA200v = 0;

    for(x=0;x<50;x++)  MA50[x] = 0;
    for(x=0;x<200;x++)  MA200[x] = 0;
    for(x=0;x<50;x++)  VMA50[x] = 0;
    for(x=0;x<200;x++)  VMA200[x] = 0;

    EMA9prev = 0;
    EMA9k = 2.0/(9.0+1.0);
    EMA12prev = 0;
    EMA12k = 2.0/(12.0+1.0);
    EMA26prev = 0;
    EMA26k = 2.0/(26.0+1.0);
    EMA33prev = 0;
    EMA33k = 2.0/(33.0+1.0);
    MACD1226EMA9prev = 0;
    MACD1226EMA9k = 2.0/(9.0+1.0);
}


movingavg_o::~movingavg_o()  {
}

#include <iostream.h>
int movingavg_o::ma(histdata_o* hd,analdata_o* ad)  {
    int x;
    double avgf = 0;
    long int avg = 0;

    if(!hd)  return -1;


    MA50[MA50i] = hd->close();
    MA50v++;
    MA50i++;
    if(MA50i > 49)  MA50i = 0;

    if(MA50v > 49)  {
        avgf = 0;
        for(x=0;x<50;x++) avgf += MA50[x];
        avgf = avgf/50;
        ad->ma50((int)avgf);
    }


    MA200[MA200i] = hd->close();
    MA200v++;
    MA200i++;
    if(MA200i > 199)  MA200i = 0;

    avgf = 0;
    if(MA50v > 199)  {
        for(x=0;x<200;x++) avgf += MA200[x];
        avgf = avgf/200;
        ad->ma200((int)avgf);
    }


    avgf = ((hd->close() - EMA9prev)*EMA9k)+EMA9prev;
    ad->ema9((int)avgf);
    EMA9prev = avgf;

    avgf = ((hd->close() - EMA12prev)*EMA12k)+EMA12prev;
    ad->ema12((int)avgf);
    EMA12prev = avgf;

    avgf = ((hd->close() - EMA26prev)*EMA26k)+EMA26prev;
    ad->ema26((int)avgf);
    EMA26prev = avgf;

    avgf = ((hd->close() - EMA33prev)*EMA33k)+EMA33prev;
    ad->ema33((int)avgf);
    EMA33prev = avgf;

    //ad->macd1226((int)(EMA26prev-EMA12prev));
    ad->macd1226((int)(EMA12prev-EMA26prev));

    avgf = ((ad->macd1226() - MACD1226EMA9prev)*MACD1226EMA9k)+MACD1226EMA9prev;
    ad->macd1226ema9((int)avgf);
    MACD1226EMA9prev = avgf;

    VMA50[VMA50i] = hd->volume();
    VMA50v++;
    VMA50i++;
    if(VMA50i > 49)  VMA50i = 0;

    if(VMA50v > 49)  {
        avg = 0;
        for(x=0;x<50;x++) avg += (VMA50[x]/50);
        ad->vma50(avg);
    }


    VMA200[VMA200i] = hd->volume();
    VMA200v++;
    VMA200i++;
    if(VMA200i > 199)  VMA200i = 0;

    if(VMA200v > 199)  {
        avg = 0;
        for(x=0;x<200;x++) avg += (VMA200[x]/200);
        ad->vma200(avg);
    }


    return 0;
}



/******************************************************************************/
