/**  analysisclient.h  *********************************************************


when      who    what
08.24.04  Dan    Creation  (Since the orignal on 08.04.04 was acidentlly
                           deleted before backed-up.  Acckkk.)


*******************************************************************************/


#ifndef ANALYSISCLIENTOBJECT_H
#define ANALYSISCLIENTOBJECT_H

#ifndef NULL
#define NULL 0
#endif


#include "string/string.h"
#include "log/log.h"
#include "memory/list.h"

#include "serverdata.h"
#include "datarequest.h"
#include "histdata.h"


#define ANALYSISCLIENTOBJECT_STATE_CLEAR      0
#define ANALYSISCLIENTOBJECT_STATE_VOID     255


class analysisclient_o  {
  private:
    int          State;
    serverdata_o Serverdata;


  public:
    analysisclient_o();
    analysisclient_o(const analysisclient_o&);
   ~analysisclient_o();
    analysisclient_o& operator = (const analysisclient_o&);

    int execute();
    int process(datarequest_o*);
    int decodeHistdata(const char*,list_o<histdata_o>*);
};

/******************************************************************************/



#endif

/******************************************************************************/
