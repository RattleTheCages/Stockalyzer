/**  support.h  ****************************************************************


when      who   what
04.10.04  Dan   Creation.
04.22.04  Dan   Changed.  Removed tree sorting methods because of new
                sorting method in bstree template.  Combined some
                methods into single methods.  Changed to use analdata_o's
                dsupport field instead of support field.  The original
                finding support used (maybe erroniously) the close field
                of analdata_o instead of the low field (and high field for
                resitance), but it turned out to be a good indicator, so
                it is moved to "dsupport" for Dan support, because I don't
                know if anyone else uses it.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.
08.06.04  Dan   Changed.  Type of field Symbol from string_o to symboldata_o.



*******************************************************************************/


#ifndef SUPPORTOBJECT_H
#define SUPPORTOBJECT_H


#include "string/string.h"
#include "memory/bstree.h"
#include "memory/list.h"

#include "analdata.h"
#include "symboldata.h"

#define SUPPORTOBJECT_STATE_CLEAR      0
#define SUPPORTOBJECT_STATE_LOAD       1
#define SUPPORTOBJECT_STATE_SORTED     2
#define SUPPORTOBJECT_STATE_VOID       255


class support_o  {
friend class drawchart_o;//!!##
  private:
    int           State;
    symboldata_o  Symbol;

    int  Price;
    int  DSupport;
    int  DResistance;

    bstree_o<analdata_o> PriceTree;
    bstree_o<analdata_o> DatePriceTree;
    bstree_o<analdata_o> DSupportPriceDateTree;
    bstree_o<list_o<analdata_o> > DGTree;

    list_o<analdata_o> PricesList;
    list_o<analdata_o> DatePriceList;

    void stringDate(analdata_o*,string_o&);
    void stringInt(int,string_o&);
    void stringDatePrice(analdata_o*,string_o&);
    void stringDSupportPriceDate(analdata_o*,string_o&);

  public:
    support_o();
    support_o(const support_o&);
    support_o(symboldata_o*);
   ~support_o();
    support_o& operator = (const support_o&);

    int finddsupport(histdata_o*,analdata_o*);
    int sort();
    int put(analdata_o*);

    int closestDSupport(int);

    int dsupport() const;
    int dresistance() const;
    int price() const;

    void display(string_o&);

};

/******************************************************************************/


inline int support_o::dsupport() const  {
    return DSupport;
}

inline int support_o::dresistance() const  {
    return DResistance;
}

inline int support_o::price() const  {
    return Price;
}


#endif

/******************************************************************************/
