/**  analysisclient.cc  *********************************************************


changes log
when      who    what
08.24.04  Dan    Creation  (Since the orignal on 08.04.04 was acidentlly         
                           deleted before backed-up.  Acckkk.)


Debug Level  5700-5799

*******************************************************************************/


#include "other/sysinfo.h"
#include "../sserver/telenet/client.h"

#include "analysisclient.h"
#include "analysis.h"
#include "datastore.h"


log_o logg;
sysinfo_o sysinfo;
datastore_o datastore;
analysisclient_o* analysisclient;
analysis_o* analysis;


analysisclient_o::analysisclient_o()  {
    State = ANALYSISCLIENTOBJECT_STATE_CLEAR;
}


analysisclient_o::~analysisclient_o()  {}


int analysisclient_o::decodeHistdata(const char* datain,list_o<histdata_o>* hdl)  {
    string_o    message;
    string_o    data;
    string_o    s;
    histdata_o* hd;


    if(!datain || !hdl)  {
        (message = "analysisclient_o: ") << "In decodeHistdata(): Null passed.";
        ::logg.error(message);

        State = ANALYSISCLIENTOBJECT_STATE_VOID;
    }


    data = datain;

    if(::logg.debug(5731))  {
        (message = "analysisclient_o: ") << "In decodeHistdata().  Data size: " << data.length();
        ::logg << message;
    }

    while(data.contains(HISTDATAOBJECT_OBJECT))  {
        s = data;
        s.cut('&');
        s.boxears();

        if(::logg.debug(5733))  {
            (message = "analysisclient_o: ") << "Datum `" << s << "'";
            ::logg << message;
        }

        if(s.contains(HISTDATAOBJECT_OBJECT))  {
            hd = new histdata_o;
            *hd << s.string();
            hdl->put(hd);

            if(::logg.debug(5732))  {
                (message = "analysisclient_o: ") << "Placing histdata_o with date ";
                message << hd->date() << " close " << hd->close();
                ::logg << message;
            }

            if(hd->date() < 17000000)  {
                (message = "analysisclient_o: ") << "Parse error?";
                ::logg.error(message);
            }
        }

        data.upcut('&');
    }




    return State;
}

int analysisclient_o::process(datarequest_o* datarequest)  {
    string_o message;
    string_o type;
    histdata_o* hd;
    list_o<histdata_o>* hdl;

    if(::logg.debug(5721))  {
        (message = "analysisclient_o: ") << "Starting process().";
        ::logg << message;
    }

    hdl = new list_o<histdata_o>;

    decodeHistdata(datarequest->data(),hdl);


    if(::logg.debug(5722))  {
        (message = "analysisclient_o: ") << "Decoded " << hdl->cardinality() << " histdata_os.";
        ::logg << message;
    }


    if(hdl->cardinality() > 1)  {

        ::analysis->analysisThis(hdl);

        type = datarequest->type();
        if(type.contains(ANALDATAOBJECT_OBJECT))  {
            ::analysis->execute();
            ::analysis->saveToFile();
        }
        else  if(type.contains(TRENDDATAOBJECT_OBJECT))  {
            ::analysis->executeTrend();
        }
        else  {
            (message = "analysisclient_o: ") << "Unknown request type.  No work performed.";
            ::logg.error(message);
        }
        if(type.contains(ANALDATAOBJECT_OBJECT) || type.contains(TRENDDATAOBJECT_OBJECT))  {
            ::analysis->saveToFile();
        }
    }


    return State;
}

int analysisclient_o::execute()  {
    string_o      message;
    string_o      s;
    int           loop = 0;
    datarequest_o datarequest;
    client_o      client;


    if(::logg.debug(5700))  {
        (message = "analysisclient_o: ") << "Starting " << sysinfo.currentDate() << ':';
        message << sysinfo.currentTime() << ".  In analysisclient_o::execute().";
        ::logg << message;
    }

    Serverdata.ip("2.2.2.42");
    Serverdata.port(9289);
    Serverdata.type(2);
    Serverdata.id("tasker");


    while(2)  {
        loop++;

        if(::logg.debug(5701))  {
            (message = "analysisclient_o: ") << "Top of processing loop, times looped " << loop;
            ::logg << message;
        }

        datarequest.clear();
        datarequest.request("ready");
        datarequest.type("analysisclient");
        s = "";
        Serverdata >> s;
        datarequest.data(s.string());

        if(::logg.debug(5711))  {
            (message = "analysisclient_o: ") << "Attempting to connect to ";
            message << Serverdata.id() << ':';
            message << Serverdata.ip() << ':' << Serverdata.port();
            ::logg << message;
        }


        client.connect(Serverdata.ip(),Serverdata.port());


        s = "";
        datarequest >> s;

        if(::logg.debug(5712))  {
            (message = "analysisclient_o: ") << "Sending request: ";
            message << datarequest.request() << ':' << datarequest.type();
            ::logg << message;
        }

        client.send(s.string());


        if(::logg.debug(5713))  {
            (message = "analysisclient_o: ") << "Waiting for work reply from tasker.";
            ::logg << message;
        }

        s = "";
        while(!s.contains(DATAREQUESTOBJECT_TRAILER))  client.recv(s);

        datarequest.clear();
        datarequest << s.string();

        if(::logg.debug(5714))  {
            (message = "analysisclient_o: ") << "Received for work tasker.";
            message << "request:" << datarequest.request() << "  type:" << datarequest.type();
            (s = "") << datarequest.data();
            message << "  data length:" << s.length();
            ::logg << message;
        }


        client.close(client.socket());
        client.disconnect();


        ::analysis = new analysis_o(datarequest.request());
        process(&datarequest);

    }


    return State;
}


int main(int argc,char* argv[])  {
    int        x;
    string_o   s;
    string_o   message;


    for(x=5700;x<=5799;x++)  ::logg.setDebugLevel(x); //analysisclient_o.
    for(x=4401;x<=4444;x++)  ::logg.setDebugLevel(x); //analysis_o.
//::logg.setDebugLevel(4524); //trend_o.


    s = argv[1];

    analysisclient = new analysisclient_o;

    return  analysisclient->execute();
}



/******************************************************************************/
