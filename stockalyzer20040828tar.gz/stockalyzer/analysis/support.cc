/**  support.cc  ***************************************************************


changes log
when      who   what
04.10.04  Dan   Creation.
04.22.04  Dan   Changed.  Removed tree sorting methods because of new
                sorting method in bstree template.  Combined some
                methods into single methods.  Changed to use analdata_o's
                dsupport field instead of support field.  The original
                finding support used (maybe erroniously) the close field
                of analdata_o instead of the low field (and high field for
                resitance), but it turned out to be a good indicator, so
                it is moved to "dsupport" for Dan support, because I don't
                know if anyone else uses it.
08.06.04  Dan   Changed.  Type of field Symbol from string_o to symboldata_o.



*******************************************************************************/


#include "support.h"
#include "log/log.h"

#include <fstream.h>

extern log_o logg;


support_o::support_o()  {
    State = SUPPORTOBJECT_STATE_VOID;
}

support_o::support_o(symboldata_o* symbol)  {
    State = SUPPORTOBJECT_STATE_CLEAR;
    Symbol = *symbol;
}

support_o::~support_o()  {}


int support_o::closestDSupport(int s)  {
    string_o message;
    const analdata_o* ad;
    const bstreePouch_o<analdata_o>* adpLeaf;
    const bstreePouch_o<analdata_o>* adpParent = 0;
    const bstreePouch_o<analdata_o>* adpLastLeft = 0;
    const bstreePouch_o<analdata_o>* adpLastRight = 0;

    if(::logg.debug(4505))  {
        (message = "support_o: ") << "closestDSupport(" << s << ")";
        ::logg << message;
    }

    DSupport = 0;
    DResistance = 0;
    adpLeaf = PriceTree.getroot();

    while(adpLeaf)  {
        adpParent = adpLeaf;

        ad = adpLeaf->object();
        if(ad->close() == s)  break;

        if(ad->close() < s)  {
            adpLeaf = adpLeaf->right;
            adpLastRight = adpParent;
        }
        else  {
            adpLeaf = adpLeaf->left;
            adpLastLeft = adpParent;
        }
    }

    if(ad->close() == s)  {
        if(::logg.debug(4505))  {
            (message = "findsupport_o: ") << "Given price at dsupport.";
            ::logg << message;
        }

        DSupport = DResistance = ad->close();
        return DSupport;
    }

    if(adpLastRight)  DSupport = adpLastRight->object()->close();
    if(adpLastLeft)  DResistance = adpLastLeft->object()->close();

    return DSupport;
}


int support_o::sort()  {
    string_o s;
    analdata_o* ad;

    if(State == SUPPORTOBJECT_STATE_SORTED)  {
        return State;
    }
    State = SUPPORTOBJECT_STATE_SORTED;

    ad = PricesList.first();
     while(ad)  {

        if(ad->dsupport() > 0)  {
            s = "";
            stringDatePrice(ad,s);
            DatePriceTree.insert(s,ad);

            s = "";
            stringDSupportPriceDate(ad,s);
            DSupportPriceDateTree.insert(s,ad);

            s = "";
            stringInt(ad->close(),s);
            PriceTree.insert(s,ad);
        }

        ad = PricesList.next();
    }

    PriceTree.sort();
    DatePriceTree.sort();
    DSupportPriceDateTree.sort();

    closestDSupport(Price);

    return 1;
}

void support_o::stringInt(int i,string_o& s)  {
    s << i;
    s.reverse();
    s << "0000000000000000";
    s.cut(s.length()-10);
    s.reverse();
}


void support_o::stringDate(analdata_o* ad,string_o& s)  {
    string_o t;

/*
    (t = "") << ad->year();
    t.justifyRight(2);
    t.transpose(" ","0");
    s << t;
    (t = "") << ad->month();
    t.justifyRight(2);
    t.transpose(" ","0");
    s << t;
    (t = "") << ad->day();
    t.justifyRight(2);
    t.transpose(" ","0");
    s << t;
*/

    s << ad->date();
}

void support_o::stringDSupportPriceDate(analdata_o* ad,string_o& s)  {
    s << ad->dsupport();
    s  << ';' << ad->close() << ';';

    stringDate(ad,s);
}

void support_o::stringDatePrice(analdata_o* ad,string_o& s)  {
    stringDate(ad,s);
    s  << ';' << ad->close() << ';';
}


int support_o::put(analdata_o* ad)  {
    string_o message;

    if(ad && ad->dsupport() > 1)  {
        if(::logg.debug(4501))  {
            (message = "findsupport_o: ") << "Placing " << ad->close() << " in list.";
            ::logg << message;
        }

        PricesList.put(ad);
    }

    if(ad)  Price = ad->close();

    return State;
}


int support_o::finddsupport(histdata_o* hd,analdata_o* ad)  {
    string_o message;
    string_o s;
    int      supp;
    analdata_o* adsearched;
    list_o<analdata_o>* dglist;
    bstreeSearch_o<list_o<analdata_o> >* dgSearch;

    if(!hd || !ad)  return -1;


    dgSearch = new bstreeSearch_o<list_o<analdata_o> >(&DGTree);

    (s = "") << hd->close();


    dglist = (list_o<analdata_o>*)dgSearch->find(&s);
    if(dglist)  {


        adsearched = dglist->first();

        supp = adsearched->dsupport();
        supp++;
        ad->dsupport(supp);

        if(::logg.debug(4501))  {
            (message = "findsupport_o: ") << "Matched DG " << s;
            message << ", " << supp << " times.";
            ::logg << message;
        }

        while(adsearched)  {
            adsearched->dsupport(supp);

            adsearched = dglist->next();
        }

        dglist->put(ad);

    }
    else  {
        dglist = new list_o<analdata_o>;
        dglist->put(ad);

        DGTree.insert(s,dglist);
    }
    delete dgSearch;


    PricesList.put(ad);

    State = SUPPORTOBJECT_STATE_LOAD;
    return State;
}


void support_o::display(string_o& message)  {
    analdata_o* ad;
bstreePouch_o<analdata_o>* adp;

    (message = "findsupport_o: ") << "Symbol " << Symbol.symbol();
    ::logg << message;

    sort();


    (message = "findsupport_o: ") << "DSupport-Price-Date for Symbol " << Symbol.symbol();
    ::logg << message;

    adp = (bstreePouch_o<analdata_o>*)DSupportPriceDateTree.list();
    ad = (analdata_o*)adp->object();
    while(ad)  {
        if(ad->dsupport() > 4)  {
            (message = "findsupport_o: ") << ad->close() << ';' << ad->dsupport() << ';' << ad->date();
            ::logg << message;
        }

        adp = adp->next;
        if(adp)ad = (analdata_o*)adp->object();
        else  ad = NULL;
    }


    (message = "findsupport_o: ") << "Date-Price for Symbol " << Symbol.symbol();
    ::logg << message;

    ad = DatePriceList.first();
    while(ad)  {
        if(ad->dsupport() > 4)  {
            (message = "findsupport_o: ") << ad->close() << ';' << ad->dsupport() << ';' << ad->date();
            ::logg << message;
        }

        ad = DatePriceList.next();
    }
}


/******************************************************************************/
