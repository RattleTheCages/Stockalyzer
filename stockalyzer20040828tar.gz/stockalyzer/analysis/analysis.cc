/**  analysis.cc  **************************************************************


changes log
when      who    what
04.10.04  Dan    Creation.
05.22.04  Dan    Added.  New trend object to analysis.
05.30.04  Dan    Added.  DateTree.  Still working on trend.
06.01.04  Dan    Converted to using new datastore_o object and dataobject
                 directory.
08.06.04  Dan    Changed.  Type of field Symbol from string_o to symboldata_o.
08.24.04  Dan    Changed.  The datastore_o saves histdata_o, analdata_o,
                           and trenddata_o as seperate files now with
                           seperate function calls.
08.25.04  Dan    Added.    Method analysisThis.



*******************************************************************************/

#include <fstream.h>

#include "analysis.h"
#include "dataconvert.h"
#include "datastore.h"


extern log_o logg;
dataconvert_o dataconvert;
extern datastore_o datastore;
//analysis_o* analysis;


analysis_o::analysis_o()  {
    State = ANALYSISOBJECT_STATE_VOID;
}


analysis_o::analysis_o(const char* symbol)  {
    Symbol.symbol(symbol);

    movingavg = new movingavg_o();
    support = new support_o(&Symbol);
    trend = new trend_o(&Symbol);

    State = ANALYSISOBJECT_STATE_CLEAR;


//support = NULL; //!!!!**!!!!**!!!!**!!!
}


analysis_o::~analysis_o()  {}


int analysis_o::loadClosingPrices()  {
    int x;
    string_o message;
    string_o s;
//  string_o filename;
    histdata_o* hd;
    list_o<histdata_o> listtmp;
    list_o<histdata_o> list;
    list_o<histdata_o> list2;

/*
    filename = Symbol.symbol();
    filename << ".histdata_o";
*/


    datastore.loadHistdata(Symbol,&listtmp);

    hd = listtmp.first();
    while(hd)  {
        if(hd->date() > 20020000)  {
            list.put(hd);
            (s = "") << hd->date();
            DateTree.insert(s,hd);
        }
        hd = listtmp.next();
    }

    if(::logg.debug(4401))  {
      (message = "analysis_o: ") << "Loaded histdata_o for " << Symbol.symbol();
      ::logg << message;
    }

    x = list.cardinality();
    while(Prices.cardinality() < x)  {
        hd = list.get();
        while(list.cardinality())  {
            list2.put(hd);
            hd = list.get();
        }
        Prices.put(hd);
        hd = list2.get();
        while(list2.cardinality())  {
            list.put(hd);
            hd = list2.get();
        }
        list.put(hd);
    }

    State = ANALYSISOBJECT_STATE_LOADED;
    return State;
}


int analysis_o::analysisThis(list_o<histdata_o>* hdl)  {
    int         x;
    string_o    message;
    histdata_o* hd;
    list_o<histdata_o> listtmp;
    list_o<histdata_o> list2;

    if(!hdl)  {
        (message = "analysis_o: ") << "analysisThis(): Null passed.";
        ::logg.error(message);
        State = ANALYSISOBJECT_STATE_NULL_PASSED;
        return State;
    }

    if(::logg.debug(4401))  {
      (message = "analysis_o: ") << "analysisThis() called with a list of ";
      message << hdl->cardinality() << " histdata_o datums.";
      ::logg << message;
    }


    hd = Prices.get();
    while(hd)  hd = Prices.get();


    x = hdl->cardinality();
    while(Prices.cardinality() < x)  {
        hd = hdl->get();
        while(hdl->cardinality())  { 
            list2.put(hd);
            hd = hdl->get();
        }
        Prices.put(hd);
        hd = list2.get();
        while(list2.cardinality())  {
            hdl->put(hd);
            hd = list2.get();
        }
        hdl->put(hd);
    }


    return State;
}


int analysis_o::saveToFile()  {
    int x;
    analdata_o* ad;
    list_o<analdata_o> list;
    list_o<analdata_o> list2;
    list_o<trenddata_o>* trendlist;
    list_o<trenddata_o> trendlisttmp;
    trenddata_o* td;

    if(PricesAnalysis.cardinality() < 1)  return -1;

    if(trend)  trendlist = trend->trendlist();
    else  trendlist = NULL;

    if(trendlist)  {
        td = trendlist->first();
        while(td)  {
            if(td->valid() > -1)  {
                trendlisttmp.put(td);
            }
            td = trendlist->next();
        }
    }

    x = PricesAnalysis.cardinality();
    while(list.cardinality() < x)  {
        ad = PricesAnalysis.get();
        while(PricesAnalysis.cardinality())  {
            list2.put(ad);
            ad = PricesAnalysis.get();
        }
        list.put(ad);
        ad = list2.get();
        while(list2.cardinality())  {
            PricesAnalysis.put(ad);
            ad = list2.get();
        }
        PricesAnalysis.put(ad);
    }


    if(list.cardinality() > 0)  datastore.saveAnaldata(Symbol,&list);
    if(trendlisttmp.cardinality() > 0)  datastore.saveTrenddata(Symbol,&trendlisttmp);

    return 0;
}


int analysis_o::execute()  {
    string_o   message;
    histdata_o* hd;
    analdata_o* ad;

    if(::logg.debug(4404))  {
        (message = "analysis_o: ") << "Executing histdata_o for: " << Symbol.symbol();
        ::logg << message;
    }

    hd = Prices.first();
    while(hd)  {
        if(::logg.debug(4405))  {
            (message = "analysis_o: ") << Symbol.symbol() << ':' << hd->date() << ':';
            message << hd->close() << ':' << hd->open();
            ::logg << message;
        }

        ad = new analdata_o(*hd);
        PricesAnalysis.put(ad);


        if(movingavg)  movingavg->ma(hd,ad);
        if(support)  support->finddsupport(hd,ad);

        if(::logg.debug(4406))  {
            (message = "analysis_o: ") << "MA(50):" << ad->ma50();
            ::logg << message;
        }

        hd = Prices.next();
    }


    State = ANALYSISOBJECT_STATE_EXECUTED;
    return State;
}

int analysis_o::executeTrend()  {
    histdata_o* hd;
    analdata_o* ad;

    if(trend)  {

        hd = Prices.first();
        while(hd)  {
            ad = new analdata_o(*hd);
            trend->dataumtrend(hd,ad);

            hd = Prices.next();
        }

        trend->findtrend();

        State = ANALYSISOBJECT_STATE_EXECUTED;
    }
    else  {
        State = ANALYSISOBJECT_STATE_VOID;
    }

    return State;
}


int analysis_o::display()  {
    string_o   message;
    analdata_o* ad;

    (message = "analysis_o: ") << "Displaying analdata_o for: " << Symbol.symbol();
    ::logg << message;

    ad = PricesAnalysis.first();
    while(ad)  {
//      (message = "analysis_o: ") << ad->date() << ';' << ad->support();
//      message << ';' << ad->ma50() << ';' << ad->ma200();
//      ::logg << message;

        (message = "analysis_o: ");
        *ad >> message;
        ::logg << message;

        ad = PricesAnalysis.next();
    }

    //support->display();

    return State;
}


/*
int main(int argc,char* argv[])  {
    int        x;
    string_o   s;
    string_o   message;
    histdata_o* hd;

//  ::logg.setDebugLevel(4401); //loading histdata_o.
    ::logg.setDebugLevel(4404); //start of histdata_o execution.
    //::logg.setDebugLevel(4405); //each date during execution.
    //::logg.setDebugLevel(4501); //support_o.
//    ::logg.setDebugLevel(4525); //trend_o.
//    for(x=4520;x<=4529;x++)  ::logg.setDebugLevel(x); //trend_o.
// for(x=4523;x<=4529;x++)  ::logg.setDebugLevel(x); //trend_o.
 for(x=4690;x<=4699;x++)  ::logg.setDebugLevel(x); //datastore_o.
//::logg.setDebugLevel(4524); //trend_o.

    s = argv[1];

    analysis = new analysis_o(s.string());

    analysis->loadClosingPrices();
    analysis->execute();

//    analysis->display();

    analysis->saveToFile();

    return 0;
}
*/



/******************************************************************************/
