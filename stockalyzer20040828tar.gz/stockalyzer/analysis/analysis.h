/**  analysis.h  ***************************************************************


when      who    what
04.11.04  Dan    Creation.
05.22.04  Dan    Added.  New trend object to analysis.
05.30.04  Dan    Added.  DateTree.  Still working on trend.
06.01.04  Dan    Converted to using new datastore_o object and dataobject
                 directory.
08.06.04  Dan    Changed.  Type of field Symbol from string_o to symboldata_o.
08.25.04  Dan    Added.    Method analysisThis.
08.26.04  Dan    Added.    Method executeTrend.


*******************************************************************************/


#ifndef ANALYSISOBJECT_H
#define ANALYSISOBJECT_H

#ifndef NULL
#define NULL 0
#endif


#include "string/string.h"
#include "memory/list.h"
#include "memory/bstree.h"
#include "log/log.h"

#include "histdata.h"
#include "analdata.h"
#include "movingavg.h"
#include "support.h"
#include "trend.h"

#define ANALYSISOBJECT_STATE_CLEAR      0
#define ANALYSISOBJECT_STATE_LOADED     1
#define ANALYSISOBJECT_STATE_EXECUTED   2
#define ANALYSISOBJECT_STATE_NULL_PASSED 254
#define ANALYSISOBJECT_STATE_VOID     255


class analysis_o  {
  private:
    int          State;
    symboldata_o Symbol;

public:
    movingavg_o* movingavg;
    support_o* support;
    trend_o* trend;

    bstree_o<histdata_o> DateTree;
    list_o<histdata_o> Prices;
    list_o<analdata_o> PricesAnalysis;


  public:
    analysis_o();
    analysis_o(const analysis_o&);
    analysis_o(const char*);
   ~analysis_o();
    analysis_o& operator = (const analysis_o&);


    int loadClosingPrices();
    int saveToFile();

    int analysisThis(list_o<histdata_o>*);

    int execute();
    int executeTrend();
    int display();

    const char* symbol() const;
};

/******************************************************************************/


inline const char* analysis_o::symbol()  const  {
    return Symbol.symbol();
}


#endif

/******************************************************************************/
