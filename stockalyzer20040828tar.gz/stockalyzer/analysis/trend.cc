/**  trend.cc  *****************************************************************


changes log
when      who   what
05.22.04  Dan   Creation.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.
08.06.04  Dan   Changed.  Type of field Symbol from string_o to symboldata_o.



*******************************************************************************/


#include "trend.h"
#include "dataconvert.h"
#include "analysis.h"
#include "log/log.h"

#include <fstream.h>

extern log_o logg;
extern dataconvert_o dataconvert;
extern analysis_o* analysis;


trend_o::trend_o(symboldata_o* sd)  {
    State = TRENDOBJECT_STATE_CLEAR;
    Symbol = *sd;

    LastAnaldata[0] = NULL;
    LastAnaldata[1] = NULL;

    XCord = 0;

    Granularity = 2;
}

trend_o::~trend_o()  {}


int round(float in)  {
    float f;
    int neg = 0;
    int i;
    int j;

    f = in;
    f = f * 10;
    i = (int)f;
    if(in > 0)  while(i>10)  i = i % 10;
    else  while(i>10)  i = i % 10;
    j = (int)in;
    if(i>4)  j = j + 1;
    return j;
}


int trend_o::dataumtrend(histdata_o* hd,analdata_o* ad)  {
    string_o message;
    string_o s;
    analdata_o* adp;


    if(::logg.debug(4521))  {
        (message = "trend_o: ") << "dataumtrend(" << ad->date() << ':' << ad->close() << ") Start.";
        ::logg << message;
    }

    if(!hd || !ad)  return -1;

    ad->trendXCord(XCord);

    if(!LastAnaldata[0])  {
        LastAnaldata[0] = ad;

        XCord++;
        return 0;
    }
    if(!LastAnaldata[1])  {
        LastAnaldata[1] = ad;

        XCord++;
        return 0;
    }


    if(LastAnaldata[1]->close() < LastAnaldata[0]->close() &&
       LastAnaldata[1]->close() < ad->close())  {

        LastAnaldata[1]->trendPoint(-1);

        s = "";
        dataconvert.stringInt(LastAnaldata[1]->close()/Granularity,s);
        s << ':' << XCord;
        tree.insert(s,LastAnaldata[1]);
        list.put(LastAnaldata[1]);

        if(::logg.debug(4522))  {
            (message = "trend_o: ") << "Low point " << LastAnaldata[1]->date();
            message << ':' << LastAnaldata[1]->close();
            ::logg << message;
        }

    }


    if(LastAnaldata[1]->close() > LastAnaldata[0]->close() &&
       LastAnaldata[1]->close() > ad->close())  {

        LastAnaldata[1]->trendPoint(1);

        s = "";
        dataconvert.stringInt(LastAnaldata[1]->close()/Granularity,s);
        s << ':' << XCord;
        tree.insert(s,LastAnaldata[1]);
        list.put(LastAnaldata[1]);

        if(::logg.debug(4522))  {
            (message = "trend_o: ") << "High point " << LastAnaldata[1]->date();
            message << ':' << LastAnaldata[1]->close();
            ::logg << message;
        }

    }

    (s = "") << XCord;
    x2AnaldataTree.insert(s,ad);

    LastAnaldata[0] = LastAnaldata[1];
    LastAnaldata[1] = ad;
    XCord++;


    return State;
}


int trend_o::findtrend()  {
    string_o    message;
    string_o    s;
    const analdata_o* cad;
    analdata_o* ad1;
    analdata_o* ad2;
    analdata_o* adf;
    trenddata_o* td;
    trenddata_o tdf;
    int         i;
    int         trend;
    int         x;
    int         y;
    float       b;
    float       m;
    list_o<analdata_o> l1;
    list_o<analdata_o> l2;
    bstreeSearch_o<trenddata_o> trendsearch(&trendTree);
    bstreeSearch_o<analdata_o> treesearch(&tree);
    bstreeSearch_o<analdata_o> x2AnaldataTreeSearch(&x2AnaldataTree);

    if(::logg.debug(4523))  {
        (message = "trend_o: ") << "findtrend() Start.";
        ::logg << message;
    }

    ad1 = list.first();
    while(ad1)  {
        l1.put(ad1);
        l2.put(ad1);
        ad1 = list.next();
    }

    ad1 = l1.get();
    ad2 = l2.get();
    while(ad1)  {
        if(::logg.debug(4524))  {
            (message = "trend_o: ") << "Begining " << ad1->date();
            ::logg << message;
        }
      ad2 = l2.first();
      while(ad2)  {
        if(::logg.debug(4524))  {
            (message = "trend_o: ") << "Checking " << ad1->date() << ':' << ad2->date();
            ::logg << message;
        }

        m = (float)(ad2->close() - ad1->close()) /
            (float)(ad2->trendXCord() - ad1->trendXCord());

        b = (float)ad1->close() - (m * (float)ad1->trendXCord());

        if(::logg.debug(4524))  {
            (message = "trend_o: ") << "Checking " << ad2->date() << ':' << ad2->close();
            message << " Slope " << m << "  b " << b;
            ::logg << message;
        }


        tdf.x(ad1->date());
        tdf.y(ad1->close());
        tdf.m(round(m*1000000));
        tdf.b(round(b*1000000));
        (s = "") << tdf.y() << '=' << tdf.m() << '*' << tdf.x() << '+' << tdf.b();
        (s = "") << "y" << '=' << tdf.m() << '*' << "x" << '+' << tdf.b();
        if(trendsearch.contains(&s))  {
            if(::logg.debug(4528))  {
                (message = "trend_o: ") << "Found trend that was already found! " << s;
                ::logg << message;
            }
        }

        if(m != 0 && !trendsearch.contains(&s))  {
            trend = 0;
            for(x=ad1->trendXCord();x<XCord;x++)  {
                y = round(m*(float)(x) + b);

                if(::logg.debug(4525))  {
                    (message = "trend_o: ") << "Checking on line at (" << x << ',' << y << ")";
                    ::logg << message;
                }

                s = "";
                dataconvert.stringInt(y/Granularity,s);
                s << ':' << x+1;
                if(::logg.debug(4525))  {
                    (message = "trend_o: ") << "(" << s << ")";
                    ::logg << message;
                }
                adf = (analdata_o*)treesearch.find(&s);
                if(adf && ad1->trendPoint() == adf->trendPoint())  {
                    if(::logg.debug(4526))  {
                        (message = "trend_o: ") << "Found point on line (" << x << ',' << y << ") ";
                        message << adf->date();
                        ::logg << message;
                    }

                    if(adf->trendXCord() == x)  {
                        TrendAnaldata[trend] = adf;
                        trend++;
                    }
                }


            }

        }



            if(trend > 2)  {
                td = new trenddata_o;
                td->x(TrendAnaldata[0]->date());
                //td->y(y);
                td->y(TrendAnaldata[0]->close());
                td->m(round(m*1000000));
                td->b(round(b*1000000));
                td->hits(trend);
        m = (float)(TrendAnaldata[trend-1]->close() - TrendAnaldata[0]->close()) /
            (float)(TrendAnaldata[trend-1]->trendXCord() - TrendAnaldata[0]->trendXCord());

        b = (float)TrendAnaldata[0]->close() - (m * (float)TrendAnaldata[0]->trendXCord());
                y = round(m*(float)(XCord-1) + b);
                td->tomorrowY(y);

                (s = "") << td->y() << '=' << td->m() << '*' << td->x() << '+' << td->b();
                (s = "") << "y" << '=' << td->m() << '*' << "x" << '+' << td->b();
                if(!trendsearch.contains(&s))  {
                    trendList.put(td);
                    trendTree.insert(s,td);

                    if(::logg.debug(4527))  {
                        (message = "trend_o: ") << "Found trend! " << s;
                        ::logg << message;
                    }
                }
                else  {
                    if(::logg.debug(4528))  {
                        (message = "trend_o: ") << "Found trend that was already found! " << s;
                        ::logg << message;
                    }
                }


                for(x=ad1->trendXCord()+1;x<TrendAnaldata[trend-1]->trendXCord();x++)  {
                    y = round(m*(float)x + b);

                    (s = "") << x;
                    cad = x2AnaldataTreeSearch.find(&s);
                    if(::logg.debug(4529))  {
                        (message = "trend_o: ") << "Looking at date: " << cad->date();
                        message << "  Close:" << cad->close() << "  y=" << y;
                        ::logg << message;
                    }

                    if(ad1->trendPoint() > 0 &&
                       cad->close()/Granularity > y/Granularity)  {

                        td->valid(-1);
                        if(::logg.debug(4529))  {
                            (message = "trend_o: ");
                            message << "Close above this upper trend line; marking invalid.";
                            ::logg << message;
                        }

                        break;
                    }

                    if(ad1->trendPoint() < 0 &&
                       cad->close()/Granularity < y/Granularity)  {

                        td->valid(-1);
                        if(::logg.debug(4529))  {
                            (message = "trend_o: ");
                            message << "Close below this lower trend line; marking invalid.";
                            ::logg << message;
                        }

                        break;
                    }
                }


                for(i=0;i<trend;i++)  {
                    if(::logg.debug(4529))  {
                        (message = "trend_o: ") << TrendAnaldata[i]->close() << ":";
                        message << TrendAnaldata[i]->date();
                        ::logg << message;
                    }

                    if(i<256)  {
                        td->Xx[i] = TrendAnaldata[i]->date();
                    }
                }
            }
        ad2 = l2.next();
}

      ad2 = l2.get();
      ad1 = l1.get();
}



    return State;
}


list_o<trenddata_o>* trend_o::trendlist()  {
    return &trendList;
}


void trend_o::display(string_o& message)  {
    trenddata_o* td;

    (message = "trend_o:\n");

    td = trendList.first();
    while(td)  {


        if(td->valid() > -1)  {
            message << "Hits " << td->hits();
            message << "  (" << td->x() << ',' << td->y() << ")  m:" << td->m();
            message << "  b:" << td->b();
            message << "  valid:" << td->valid();
            message << '\n';
        }

        td = trendList.next();
    }

}


/******************************************************************************/
