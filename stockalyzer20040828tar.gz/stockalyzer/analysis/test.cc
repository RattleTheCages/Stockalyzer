

#include <iostream.h>
int main()  {

    float f;
    int i;
    int x;

    f = 184.494;

    cout<<f<<":"<<(int)f<<endl;

    cout<<f*10<<":"<<(int)f*10<<endl;

    f = f * 10;

    i = f;

    cout<<i<<endl;

    while(i>10)  i = i % 10;

    cout<<i<<endl;

    x = (int)f;
    if(i>4)  x = x + 1;

    cout<<x<<endl;
}
