/**  extracttrend.cc  **********************************************************


changes log
when      who    what
06.15.04  Dan    Creation.



*******************************************************************************/

#include <fstream.h>

#include "../dataobjects/dataconvert.h"
#include "../dataobjects/datastore.h"

#include "memory/list.h"
#include "log/log.h"
#include "other/sysinfo.h"

log_o logg;
sysinfo_o sysinfo;
dataconvert_o dataconvert;
datastore_o datastore;


int main(int argc,char* argv[])  {
    int        x;
    string_o   s;
    string_o   message;
    analdata_o* ad;
    trenddata_o* td;
    list_o<analdata_o> anallist;
    list_o<analdata_o> anallist2;
    list_o<trenddata_o> trendlist;
    list_o<trenddata_o> trendlist2;



/**/
    s = argv[1];
    s << ".analdata_o";
    datastore.loadAnaldata(s.string(),&anallist,&trendlist);

    s = argv[1];
    s.cut(".");
    s << ".trenddata_o";

    if(trendlist.cardinality() > 0)  {
        datastore.saveAnaldata(s.string(),&anallist2,&trendlist);
    }
/**/


/*
    s = argv[1];
    s << ".trenddata_o";
    datastore.loadAnaldata(s.string(),&anallist2,&trendlist);

    s = argv[1];
    s.cut(".");
    s << ".analdata_o";
    datastore.loadAnaldata(s.string(),&anallist,&trendlist2);

    datastore.saveAnaldata(s.string(),&anallist,&trendlist);
*/



    return 0;
}



/******************************************************************************/
