/**  movingavg.h  **************************************************************


when      who    what
04.10.04  Dan    Creation.
04.18.04  Dan    Added.  Average volume.
06.01.04  Dan    Converted to using new datastore_o object and dataobject
                 directory.



*******************************************************************************/


#ifndef MOVINGAVGOBJECT_H
#define MOVINGAVGOBJECT_H

#include "../dataobjects/histdata.h"
#include "string/string.h"
#include "memory/bstree.h"

#include "../dataobjects/analdata.h"

class movingavg_o  {
  private:
    int      State;
    string_o Symbol;

    int      MA50[50];
    int      MA50i;
    int      MA50v;
    int      MA200[200];
    int      MA200i;
    int      MA200v;

    float    EMA33k;
    float    EMA33prev;
    float    EMA9k;
    float    EMA9prev;
    float    EMA12k;
    float    EMA12prev;
    float    EMA26k;
    float    EMA26prev;
    float    MACD1226EMA9k;
    float    MACD1226EMA9prev;

    int      VMA50[50];
    int      VMA50i;
    int      VMA50v;
    int      VMA200[200];
    int      VMA200i;
    int      VMA200v;



  public:
    movingavg_o();
    movingavg_o(const movingavg_o&);
   ~movingavg_o();
    movingavg_o& operator = (const movingavg_o&);

    int ma(histdata_o*,analdata_o*);
};

/******************************************************************************/



#endif

/******************************************************************************/
