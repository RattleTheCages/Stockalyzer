/**  trend.h  ******************************************************************


when      who   what
05.22.04  Dan   Creation.
06.01.04  Dan   Converted to using new datastore_o object and dataobject
                directory.
08.06.04  Dan   Changed.  Type of field Symbol from string_o to symboldata_o.


*******************************************************************************/


#ifndef TRENDOBJECT_H
#define TRENDOBJECT_H


#include "string/string.h"
#include "memory/bstree.h"
#include "memory/dlist.h"
#include "memory/list.h"

#include "symboldata.h"
#include "analdata.h"
#include "trenddata.h"

#define TRENDOBJECT_STATE_CLEAR      0
#define TRENDOBJECT_STATE_LOAD       1
#define TRENDOBJECT_STATE_SORTED     2
#define TRENDOBJECT_STATE_VOID       255


class trend_o  {
friend class drawchart_o;//!!##
  private:
    int           State;
    symboldata_o  Symbol;

    int      XCord;
    float    Granularity;

    analdata_o* LastAnaldata[2];
    analdata_o* TrendAnaldata[256];


    dlist_o<analdata_o> list;
    bstree_o<analdata_o> tree;
    bstree_o<analdata_o> x2AnaldataTree;

    list_o<trenddata_o> trendList;
    bstree_o<trenddata_o> trendTree;


  public:
    trend_o();
    trend_o(const trend_o&);
    trend_o(symboldata_o*);
   ~trend_o();
    trend_o& operator = (const trend_o&);

    int dataumtrend(histdata_o*,analdata_o*);
    int findtrend();

    list_o<trenddata_o>* trendlist();

    void display(string_o&);

};

/******************************************************************************/




#endif

/******************************************************************************/
