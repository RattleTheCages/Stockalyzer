/**  datagatheror.h  ***********************************************************


when      who   what
04.16.04  Dan   Creation.


*******************************************************************************/


#ifndef DATAGATHEROROBJECT_H
#define DATAGATHEROROBJECT_H

#include "string/string.h"
#include "memory/list.h"


class datagatheror_o  {
  private:
    int      State;
    string_o Flags;

    string_o Server;
    int      Port;


  public:
    datagatheror_o();
    datagatheror_o(const datagatheror_o&);
   ~datagatheror_o();
    datagatheror_o& operator = (const datagatheror_o&);


    int execute();

    int state() const;
    int port() const;

    void flags(const char*);
    void port(int);
};

/******************************************************************************/

inline int datagatheror_o::state() const  {
    return State;
}

inline int datagatheror_o::port() const  {
    return Port;
}

inline void datagatheror_o::flags(const char* f)  {
    Flags = f;
}

inline void datagatheror_o::port(int p)  {
    Port = p;
}


#endif

/******************************************************************************/
