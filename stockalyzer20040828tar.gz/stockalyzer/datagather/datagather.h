/**  datagather.h  *************************************************************


when      who    what
11.21.03  Dan    Creation.
04.03.04  Dan    Changed.  Reworked the quick prototype into a module that
                 accepts requests for differing stock symbols and allows
                 for test input from a file.
04.04.04  Dan    Seperated parser to its own object.
04.06.04  Dan    Added.  Seperate History and Daily quieries.
06.08.04  Dan    Added.  Load Symbol From Host function.


*******************************************************************************/


#ifndef DATAGATHEROBJECT_H
#define DATAGATHEROBJECT_H

#include "string/string.h"
#include "memory/list.h"
#include "histdata.h"

class datagather_o  {
  private:
    string_o  Symbol;                       // Symbol of data to be gathered.
    string_o  LastHost;                     // Last host an attempted connetion.
    string_o  RecvString;                   // Recv'ed from the host on request.

    int loadFromHost(const char* host,const char* query);

  public:
    datagather_o();
    datagather_o(const datagather_o&);
   ~datagather_o();
    datagather_o& operator = (const datagather_o&);

    const char* recvstring() const;

    int loadHistFromHost(const char* host);
    int loadDailyFromHost(const char* host);
    int loadSymbolFromHost(const char* host);

    int saveRawData();
    int checkVaildSymbol();

    const char* symbol() const;
    void        symbol(const char*);

};

/******************************************************************************/

inline const char* datagather_o::recvstring() const  {
    return RecvString.string();
}

inline const char* datagather_o::symbol() const  {
    return Symbol.string();
}


#endif

/******************************************************************************/
