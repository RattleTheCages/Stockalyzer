

#include <errno.h>
#include <iostream.h>

#include <stdio.h>
#include <string.h>
#include <fstream.h>

#include "string/string.h"
#include "memory/list.h"
#include "log/log.h"
#include "histdata.h"
#include "dataparser.h"


log_o logg;

int main(int argc, char* argv[])  {
    int x;
    int ret;
    string_o s,t;
    dataparser_o dataparser;
    histdata_o* hd;
    string_o symbol;
    list_o<histdata_o> list;
    list_o<histdata_o> list2;
    list_o<histdata_o> list3;
    char buff[4096];

    ifstream in;
    ofstream out;

    symbol = "./livedata/";
    symbol << argv[1];
    symbol << ".histdata_o";

    in.open(symbol.string());
    if(!in)  return -1;

    for(x=0;x<sizeof(buff);x++)  *(buff+x) = '\0';
    while(!in.eof())  {
        in.getline(buff,sizeof(buff)-1,'\n');
        if(in.eof())  break;

        s = "";
        s << buff;
cout<<s.string()<<endl;

        t = s;
        t.cut(' ');

        x = dataparser.date(t.string());

        t = "";
        t << x << " ";
        s.upcut(' ');
        t << s;
cout<<t.string()<<endl;
        hd = new histdata_o;
        *hd << t.string();

        list.put(hd);

    }
    in.close();

    x = list.cardinality();
    while(list3.cardinality() != x)  {
        hd = list.get();
        while(hd)  {
            if(!list.cardinality())  {
                list3.put(hd);
            }
            else  {
                list2.put(hd);
            }
            hd = list.get();
        }

        hd = list2.get();
        while(hd)  {
            list.put(hd);
            hd = list2.get();
        }
    }

    out.open(symbol.string());
    if(!out)  return -1;

    hd = list3.get();
    while(hd)  {
        s = "";
        *hd >> s;

        out << s.string() << '\n';

        hd = list3.get();
    }
    out.close();



    return ret;
}

/******************************************************************************/
