/**  dgtasker.h  ***************************************************************


when      who   what
04.14.04  Dan   Creation.
04.16.04  Dan   Improved.  Takes commandline arguments, and compairs
                the two inputs, livedata directory and symbol file.
                And now uses new symboldata_o object.


*******************************************************************************/


#ifndef DGTASKEROBJECT_H
#define DGTASKEROBJECT_H

#include "string/string.h"
#include "memory/list.h"

#include "../dataobjects/symboldata.h"
#include "datarequest.h"

class dgtasker_o  {
  private:
    int       State;
    int       Date;
    int       Port;
    string_o  Flags;
    string_o  Filename;
    string_o  Dirname;
    symbols_o Symbols;
    list_o<symboldata_o> RandomOrderSymbolList;

    int       getDate();
    int       checkDate(const symboldata_o*);
    int       kill(int);
    int       rnd(int);

  public:
    dgtasker_o();
    dgtasker_o(const dgtasker_o&);
   ~dgtasker_o();
    dgtasker_o& operator = (const dgtasker_o&);

    int state() const;

    int loadSymbols();
    int findSymbols();
    int mergeSymbols();
    int randSymbols();
    int doSymbols();

    int execute();
    int server();
    int client();

    void flags(const char*);
    void port(int);
};

/******************************************************************************/

inline int dgtasker_o::state() const  {
    return State;
}

inline void dgtasker_o::flags(const char* f)  {
    Flags = f;
}

inline void dgtasker_o::port(int p)  {
    Port = p;
}


#endif

/******************************************************************************/
