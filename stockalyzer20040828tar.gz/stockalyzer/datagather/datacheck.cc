/**  datacheck.cc  *************************************************************


changes log
when      who   what
04.02.04  Dan   Creation.


*******************************************************************************/


#include <fstream.h>


#include "other/sysinfo.h"
#include "log/log.h"

#include "datacheck.h"
#include "histdata.h"


sysinfo_o sysinfo;
log_o logg;
datacheck_o datacheck;


datacheck_o::datacheck_o()  {
    State = DATACHECKOBJECT_STATE_CLEAR;
}

datacheck_o::~datacheck_o()  {}


int datacheck_o::loadHistdata(symboldata_o* symb)  {
    int x;
    string_o s;
    string_o* sp;
    string_o message;
    string_o filename;
    histdata_o* hd;
    char buffer[2048];
    ifstream in;
    bstreeSearch_o<string_o>* ts;
    bstree_o<histdata_o> ltree;
    bstreeSearch_o<histdata_o> lts(&ltree);

    list_o<histdata_o> list;

    if(!symb)  {
        State = DATACHECKOBJECT_STATE_VOID;
        return State;
    }

    filename = Symbols.dirname();
    filename << '/' << symb->symbol();
    filename << ".histdata_o";
    in.open(filename.string());
    if(!in)  {
        State = DATACHECKOBJECT_STATE_VOID;

        (message = "datacheck_o: ")  << "Histdata file \"" << filename << "\" missing.";
        ::logg.error(message);

        return State;
    }


    ts = new bstreeSearch_o<string_o>(&Tree);
    for(int x=0;x<sizeof(buffer);x++)  *(buffer+x) = '\0';
    while(!in.eof())  {
        in.getline(buffer,sizeof(buffer)-1,'\n');
        if(in.eof())  break;

        hd = new histdata_o;
        *hd << buffer;
        list.put(hd);

        (s = "") << hd->date();
        if(!ts->contains(&s))  {
            (message = "datacheck_o: ")  << "Date " << hd->date() << " not duplicate.";
            ::logg << message;
        }
        sp = new string_o(s);
        Tree.insert(s.string(),sp);
        ltree.insert(s.string(),hd);
    }
    in.close();


    if(::logg.debug(4404))  {
        (message = "datacheck_o: ")  << "Histdata file \"" << filename << "\" loaded ";
        message << list.cardinality() << " dates.";
        ::logg << message;
    }


    Tree.sort();
    ts = new bstreeSearch_o<string_o>(&Tree);


    x = 0;
    sp = (string_o*)ts->first();
    while(sp)  {
        if(::logg.debug(4406))  {
            (message = "datacheck_o: ") << "Checking " << sp;
            ::logg << message;
        }

        if(!lts.contains(sp))  {
            (message = "datacheck_o: ")  << "Date " << sp << " not found.";
            ::logg << message;

            x++;
            if(x > 4)  {
                FlaggedSymbols.put(symb);
                break;
            }
        }

        sp = (string_o*)ts->next();
    }


    return State;
}


int datacheck_o::execute()  {
    int ret;
    string_o s;
    string_o message;
    string_o date;
    symboldata_o* symbol;
    histdata_o* hd;
    marketdate_o* md;

    date << sysinfo.currentYear();  
    if(sysinfo.currentMonth()+1 < 10)  date << '0';  
    date << sysinfo.currentMonth()+1;
    if(sysinfo.currentDay() < 10)  date << '0'; 
    date << sysinfo.currentDay();
    (message = "datacheck_o: ")  << "Good Afternoon " << date.string() << '.';
    ::logg << message;


    ret = Symbols.directory();
    ret = Symbols.merge();
    if(::logg.debug(4402))  {
        (message = "datacheck_o: ") << ret << " symbols loaded.";
        ::logg << message;
    }

    symbol = Symbols.first();
    while(symbol)  {

        if(::logg.debug(4602))  {
            (message = "datacheck_o: ") << "Loading histdata_o for " << symbol->symbol();
            ::logg << message;
        }

        ret = loadHistdata(symbol);
        if(ret == DATACHECKOBJECT_STATE_VOID)  {
            return State;
        }
        else  {
        }

        symbol = Symbols.next();
    }


    FlaggedSymbols.save("./liveconfig/datacheck.symboldata_o");


    Tree.sort();
    bstreeSearch_o<string_o> ts(&Tree);
    const string_o* sp;
    sp = ts.first();
    while(sp)  {
        md = new marketdate_o;
        md->date(sp->stoi());
        Marketdates.put(md);

        ::logg << *sp;

        sp = ts.next();
    }


    Marketdates.save();

    return 0;
}


int main(int argc,char* argv[])  {
    int       ret;


    ::logg.setDebugLevel(4402);
    ::logg.setDebugLevel(4404);
//  ::logg.setDebugLevel(4406);

    ret = datacheck.execute();


    return ret;
}



/******************************************************************************/
