/**  dataparser.h  *************************************************************


when      who    what
04.04.04  Dan    Creation.
04.04.04  Dan    Changed.  Sperated from data gathering from internet.
06.08.04  Dan    Added.  Parse Symbol function.
06.09.04  Dan    Added.  Save Symbol, mergeWithSymboldata functions.
07.14.04  Dan    Added.  Function copyHistdataList.


*******************************************************************************/


#ifndef DATAPARSEROBJECT_H
#define DATAPARSEROBJECT_H

#include "string/string.h"
#include "memory/list.h"
#include "../dataobjects/histdata.h"
#include "../dataobjects/symboldata.h"

class dataparser_o  {
  private:
    string_o  Symbol;               // Symbol of data to be gathered.
    string_o  ParseString;          // The string to be parsed.
    int       ParseStringTest;
    list_o<histdata_o> listparse;   // List of histdata_os parsed.
    list_o<histdata_o> listload;    // List of histdata_os loaded from archive.
    list_o<histdata_o> list;        // Complete list of histdata_os.

  public:
    dataparser_o();
    dataparser_o(const dataparser_o&);
   ~dataparser_o();
    dataparser_o& operator = (const dataparser_o&);

    int parseStringTest();
    int parse();
    int parseSymbol(symboldata_o*);
    int loadFromFile();
    int merge();
    int saveToFile();
    int saveSymbolToFile(symboldata_o*);
    int mergeWithSymboldata(symboldata_o*);
    int copyHistdataList(list_o<histdata_o>*);

    int loadRawData();

    const char* parsestring() const;
    void parsestring(const char*);

    const char* symbol() const;
    void        symbol(const char*);

    int         date(const char*);
};

/******************************************************************************/

inline const char* dataparser_o::parsestring() const  {
    return ParseString.string();
}

inline const char* dataparser_o::symbol() const  {
    return Symbol.string();
}


#endif

/******************************************************************************/
