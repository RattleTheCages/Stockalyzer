/**  datagather.cc  ************************************************************


when      who    what
11.21.03  Dan    Creation.
04.03.04  Dan    Changed.  Reworked the quick prototype into a module that
                 accepts requests for differing stock symbols and allows
                 for test input from a file.
04.04.04  Dan    Seperated parser to its own object.
04.06.04  Dan    Added.  Seperate History and Daily quieries.
06.08.04  Dan    Added.  Load Symbol From Host function.


*******************************************************************************/

#include <stdlib.h>
#include <fstream.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

#include <iostream.h>


#include "datagather.h"
#include "string/string.h"
#include "log/log.h"
#include "other/sysinfo.h"


extern log_o logg;
extern sysinfo_o sysinfo;

datagather_o::datagather_o()  {}
datagather_o::~datagather_o()  {}

void datagather_o::symbol(const char* sym)  {
    if(sym)  Symbol = sym;
}

int datagather_o::saveRawData()  {
    ofstream out;
    string_o filename;

    (filename = Symbol) << ".raw";

    out.open(filename.string());
    if(out)  {
        out << RecvString.string();
        out.close();
        return 0;
    }
    return -1;
}

int datagather_o::loadHistFromHost(const char* hostname)  {
    string_o query;
/*
GET /q/hp?s=XMSR&a=10&b=5&c=1997&d=10&e=23&f=2003&g=d&z=1666&y=0 HTTP/1.1\n\
*/
query = "\
GET /q/hp?s=";
query << symbol();
query << "&a=10&b=5&c=2000&d=";
query << sysinfo.currentMonth();
query << "&e=";
query << sysinfo.currentDay();
query << "&f=";
query << sysinfo.currentYear();
query << "&g=d&z=1666&y=0 HTTP/1.1\n\
User-Agent: Mozilla/4.0 (compatible; UNIX) DanielHuffman 2.22  [en]\n\
Host: Daniel N Huffman\n\
Accept: text/html, */*\n\
Accept-Charset: utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1\n\
Accept-Encoding: deflate, identity, *;q=0\n\
Connection: Keep-Alive, TE\n\
TE: deflate, identity, trailers\n\
\n\
\n\
";
    return loadFromHost(hostname,query.string());
}


int datagather_o::loadDailyFromHost(const char* hostname)  {
    string_o query;
query = "\
GET /q/hp?s=";
query << symbol();
query << "&a=1&b=1&c=2004&d=";
query << sysinfo.currentMonth();
query << "&e=";
query << sysinfo.currentDay();
query << "&f=";
query << sysinfo.currentYear();
query << "&g=d&z=14&y=0 HTTP/1.1\n\
User-Agent: Mozilla/4.0 (compatible; UNIX) DanielHuffman 2.22  [en]\n\
Host: Daniel N Huffman\n\
Accept: text/html, */*\n\
Accept-Charset: utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1\n\
Accept-Encoding: deflate, identity, *;q=0\n\
Connection: Keep-Alive, TE\n\
TE: deflate, identity, trailers\n\
\n\
\n\
";

    return loadFromHost(hostname,query.string());
}


int datagather_o::loadSymbolFromHost(const char* hostname)  {
    string_o query;
query = "\
GET /q?s=";
query << symbol();
query << " HTTP/1.1\n\
User-Agent: Mozilla/4.0 (compatible; UNIX) DanielHuffman 2.22  [en]\n\
Host: Daniel N Huffman\n\
Accept: text/html, */*\n\
Accept-Charset: utf-8;q=1.0, utf-16;q=1.0, iso-8859-1;q=0.6, *;q=0.1\n\
Accept-Encoding: deflate, identity, *;q=0\n\
Connection: Keep-Alive, TE\n\
TE: deflate, identity, trailers\n\
\n\
\n\
";

    return loadFromHost(hostname,query.string());
}


int datagather_o::checkVaildSymbol()  {
    int ret;

    //ret = RecvString.contains("Invaild Symbol");
    ret = 0;

    return ret;
}


int datagather_o::loadFromHost(const char* hostname,const char* query)  {
    string_o message;
    int plug,err,recvq,recvw,sendq;
    struct sockaddr_in cserver;
    struct hostent* chost;
    char buffer[262144];
    string_o host;
    string_o sends;
    string_o s;
    string_o t;
    char crtlM[3];


    if(hostname)  {
        host = hostname;
    }
    else  {
        host = "finance.yahoo.com";
    }

    sends = query;


    (message = "") << "Starting data collection for: " << symbol();
    message << " from host: " << host << '.';
    ::logg << message;
    plug = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
    if(plug < 0)  {
        (message = "") << "\"socket\" call did not provide a socket.  Returning.";
        ::logg.error(message);
        return -1;
    }

    cserver.sin_family = PF_INET;
    chost = ::gethostbyname(host.string());
    if(chost == NULL)  {
        (message = "") << "\"gethostbyname\" call did not return a vaild address.";
        ::logg.error(message);
        (message = "") << "Attempted with hostname:" << host << ".  Returning.";
        ::logg.error(message);
        return -2;
    }


    ::memcpy(&cserver.sin_addr,chost->h_addr,chost->h_length);
    cserver.sin_port = htons(80);

    if(err = ::connect(plug,(sockaddr*)&cserver,sizeof(cserver)) < 0)  {
        (message = "") << "\"connect\" call to host: " << host << " failed.  Returning.";
        ::logg.error(message);
        return -3;
    }
    else  {
        (message = "") << "Successful connection made to host: " << host << ".";
        ::logg << message;
    }

    sendq = ::send(plug,sends.string(),sends.length(),0);
    if(sendq < sends.length())  {
        (message = "") << "\"send\" return indicates it sent wrong number of bytes.";
        ::logg.error(message);
        (message = "") << "Send String length: " << sends.length();
        message << "\"send\" command length : " << sendq << '.';
        ::logg.error(message);
    }


    (message = "") << "Starting receive loop.";
    ::logg << message;

    recvw = 0;
    while(!t.contains("</html>"))  {
        recvq = 1;
        recvw++;
        while(recvq)  {
            memset(buffer,'\0',sizeof(buffer));
            if(recvq = ::recv(plug,buffer,sizeof(buffer)-1,0)<0)
                perror("ERROR 04  Reading from the socket>  ");
            s << buffer;
            t = buffer;
            if(t.contains("</html>") | recvw > 32766)  break;
        }
        if(recvw > 32766)  break;
    }
    ::close(plug);
    ::shutdown(plug,SHUT_RDWR);

    (message = "") << "Connection and socket closed.  Receive string length: ";
    message << s.length();
    ::logg << message;


    (message = "") << "Removing crtlM-gaps in receive string.";
    ::logg << message;

    crtlM[0] = (char)13;
    crtlM[1] = (char)10;
    crtlM[2] = '\0';

    t = s;
    while(s.length())  {
        t.cut(crtlM);
        t.cut(t.length()-2);
        s.upcut(crtlM);
        s.upcut(crtlM);
        t << s;
    }

    RecvString = t;

    return 0;
}


/******************************************************************************/
