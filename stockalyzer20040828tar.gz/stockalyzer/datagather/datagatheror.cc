/**  datagatheror.cc  **********************************************************


when      who    what
11.21.03  Dan    Creation.
04.03.04  Dan    Changed.  Reworked the quick prototype into a module that
                 accepts requests for differing stock symbols and allows
                 for test input from a file.
04.08.04  Dan    Changed datagatheror into a server to place parsing
                 processing onto a different process.
04.16.04  Dan    Added.  Header file.


*******************************************************************************/


#include <iostream.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

#include "string/string.h"
#include "memory/list.h"
#include "other/sysinfo.h"
#include "log/log.h"
#include "../sserver/telenet/server.h"
#include "datagather.h"
#include "histdata.h"
#include "datarequest.h"
#include "datagatheror.h"


log_o logg;
sysinfo_o sysinfo;

datagatheror_o datagatheror;

datagatheror_o::datagatheror_o()  {
    State = 0;

    Port = 2222;
    Server = "2.2.2.66";
}

datagatheror_o::~datagatheror_o()  {}




int      acceptz;
string_o message;
string_o date;
string_o string;
datarequest_o datarequest;
datagather_o datagather;
server_o* server;


int datagatheror_o::execute()  {
    string_o s;

    server = new server_o(Port);

    (message = "") << "Listening for symbol request on port " << server->port() << '.';
    ::logg << message;


    while(2)  {
        acceptz = server->accept();

usleep(222222);

        string = "";
        server->recv(string);
        datarequest << string.string();

        
        //Flags << datarequest.type();
        s = datarequest.type();
        Flags = "";
        if(s.contains("hist"))  Flags << " h ";
        if(s.contains("symb"))  Flags << " s ";
        datagather.symbol(datarequest.request());

        (message = "") << "Request received for symbol " << datagather.symbol() << '.';
        ::logg << message;


        if(Flags.contains("h"))  {
            (message = "") << "Loading hist data for symbol " << datagather.symbol() << '.';
            ::logg << message;

            datagather.loadHistFromHost("finance.yahoo.com");
        }

        else  if(Flags.contains("s"))  {
            (message = "") << "Loading symbol data for symbol " << datagather.symbol() << '.';
            ::logg << message;

            datagather.loadSymbolFromHost("finance.yahoo.com");
        }

        else  {
            (message = "") << "Loading daily data for symbol " << datagather.symbol() << '.';
            ::logg << message;

            datagather.loadDailyFromHost("finance.yahoo.com");
        }


        datagather.saveRawData();

        if(!datagather.checkVaildSymbol())  {
            (message = "") << "Invaild symbol " << datagather.symbol();
            ::logg << message;
        }

        datarequest.reply(datagather.recvstring());
        string = "";
        datarequest >> string;
        server->send(string.string());

usleep(222222);
        server->close(acceptz);
usleep(222222);

    }

    return 0;
}


int main(int argc, char* argv[])  {
    string_o arg;


    date << sysinfo.currentYear();
    if(sysinfo.currentMonth()+1 < 10)  date << '0';
    date << sysinfo.currentMonth()+1;
    if(sysinfo.currentDay() < 10)  date << '0';
    date << sysinfo.currentDay();
    (message = "") << "Good Morning " << date.string() << '.';
    ::logg << message;

    arg = argv[1];

    if(arg.length() > 0 && arg.isdigit())  {
        datagatheror.port(arg.stoi());
    }

    arg = argv[0];
    arg << '.' << datagatheror.port();
    ::logg.registerName(arg.string());

    return  datagatheror.execute();
}

/******************************************************************************/
