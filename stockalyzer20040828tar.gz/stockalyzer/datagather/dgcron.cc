/**  dgcron.cc  ****************************************************************


when      who    what
04.04.04  Dan    Creation.


*******************************************************************************/


#include <stdlib.h>
#include <unistd.h>

#include "string/string.h"
#include "memory/list.h"
#include "other/sysinfo.h"
#include "log/log.h"
#include "datagather.h"
#include "dataparser.h"
#include "histdata.h"


log_o logg;
sysinfo_o sysinfo;

string_o date;

void setDate()  {
    (date = "") << sysinfo.currentYear();
    if(sysinfo.currentMonth()+1 < 10)  date << '0';
    date << sysinfo.currentMonth()+1;
    if(sysinfo.currentDay() < 10)  date << '0';
    date << sysinfo.currentDay();
}

int main(int argc, char* argv[])  {
    string_o message;
    string_o syscall;
    string_o s;
    int day;
    int day2;

    ::logg.registerName(argv[0]);

    setDate();
    (message = "") << "Datagathering Cron. " << date.string() << ".";
    ::logg << message;


    (s = "") << ::sysinfo.currentDay();
    day = s.stoi();
    (message = "") << "The day is " << day << " waiting until change, then triggering ./dgtasker.";
    ::logg << message;
    while(2)  {
        (s = "") << ::sysinfo.currentDay();
        day = s.stoi();

        sleep(3600 * 2); // 2 hours.
        s = ::sysinfo.currentDay();
        day2 = s.stoi();
        if(day != day2)  {
            (message = "") << "Triggered.  Day " << day2 << '.';
            ::logg << message;


            system("./dgtasker >> dgtasker.log");


            (message = "") << "The day is " << day << " waiting until change, the triggering.";
            ::logg << message;
        }

    }



    return 0;
}

/******************************************************************************/
