/**  dataparser.cc  ************************************************************


when      who    what
04.04.04  Dan    Creation.
04.04.04  Dan    Changed.  Sperated from data gathering from internet.
06.08.04  Dan    Added.  Parse Symbol function.
06.09.04  Dan    Added.  Save Symbol function.
07.14.04  Dan    Added.  Function copyHistdataList.
08.04.04  Dan    Fixed.  Bug in merge method.


*******************************************************************************/

//#include <stdlib.h>
#include <fstream.h>


#include "dataparser.h"
#include "string/string.h"
#include "log/log.h"
#include "other/sysinfo.h"


extern log_o logg;
extern sysinfo_o sysinfo;

int getDate()  {
    string_o s;
    int Date;
    s << sysinfo.currentYear();
    if(sysinfo.currentMonth()+1 < 10)  s << '0';
    s << sysinfo.currentMonth()+1;
    if(sysinfo.currentDay() < 10)  s << '0';
//    s << sysinfo.currentDay();
//    s << sysinfo.currentDay()-1;
    s << sysinfo.currentDay()-3;
    Date = s.stoi();
    return Date;
}


dataparser_o::dataparser_o()  {
    ParseStringTest = 0;
}

dataparser_o::~dataparser_o()  {}

void dataparser_o::symbol(const char* sym)  {
    if(sym)  Symbol = sym;
}

void dataparser_o::parsestring(const char* parses)  {
    if(parses)  ParseString = parses;
    ParseStringTest = 0;
}

int dataparser_o::loadFromFile()  {
    string_o filename;
    ifstream in;
    char buf[32767];
    histdata_o* histdata;

    filename = Symbol;
    filename << ".histdata_o";

    in.open(filename.string());
    if(in)  {
        while(!in.eof())  {
            in.getline(buf,sizeof(buf),'\n');
            if(in.eof())  break;
            histdata = new histdata_o;
            *histdata << buf;
            listload.put(histdata);

        }
        in.close();
        return 1;
    }

    return 0;
}

int dataparser_o::saveToFile()  {
    ofstream out;
    string_o s;
    string_o filename;
    histdata_o* hd;

    if(list.cardinality() < 1)  return -1;

    filename = Symbol;
    filename << ".histdata_o";

    out.open(filename.string());
    if(out)  {
        hd = list.first();
        while(hd)  {
            s = "";
            *hd >> s;
            out << s.string() << '\n';
            hd = list.next();
        }
    }
    out.close();

    return 0;
}

int dataparser_o::saveSymbolToFile(symboldata_o* symboldata)  {
    string_o message;
    ofstream out;
    string_o s;
    string_o filename;

    if(!symboldata)  return -1;

    filename = symboldata->symbol();
    filename << ".symboldata_o";

    if(1)  {
        (message = "dataparser_o: ") << "Saving symbol to filename: " << filename;
        ::logg << message;
    }

    out.open(filename.string());
    if(!out)  {
        (message = "dataparser_o: ") << "Unable to open filename: " << filename;
        ::logg.error(message);
    }
    if(out)  {
        s = "";
        *symboldata >> s;
        out << s.string() << '\n';
    }
    out.close();

    return 0;
}


int dataparser_o::merge()  {
    int      x;
    string_o message;
    string_o s;
    histdata_o* hd;
    bstree_o<histdata_o> hdt;
    bstreeSearch_o<histdata_o> hdts(&hdt);

    if(::logg.debug(5707))  {
        (message = "dataparser_o: ") << "merge(): loaded\n";
        hd = listload.first();
        x = 0;
        while(hd && x++ < 12)  {
            *hd >> message;
            message << '\n';
            hd = listload.next();
        }
        ::logg << message;
    }

    (message = "dataparser_o: ") << "merge(): parsed\n";
    hd = listparse.first();
    while(hd)  {
        if(::logg.debug(5707))  {
            *hd >> message;
            message << '\n';
        }
        hd = listparse.next();
    }
    if(::logg.debug(5707))  ::logg << message;


    hd = listload.first();
    while(hd)  {
        (s = "") << hd->date();
        hdt.insert(&s,hd);
        hd = listload.next();
    }

    hd = listparse.first();
    while(hd)  {
        (s = "") << hd->date();
        hdt.insert(&s,hd);
        hd = listparse.next();
    }

    hdt.sort();


    hd = (histdata_o*)hdts.first();
    while(hd)  {
        list.put(hd);

        if(::logg.debug(5708))  {
            (message = "dataparser_o: ") << "Putting " << hd->date() << " into list.";
            ::logg << message;
        }

        hd = (histdata_o*)hdts.next();
    }


    return 0;
}

int dataparser_o::mergeWithSymboldata(symboldata_o* sd)  {
    string_o message;
    string_o    s;
    string_o    u;
    int         x;
    histdata_o* hd;
    histdata_o* hd2;
    string_o date1;
    string_o date2;
    list_o<histdata_o> listtmp;


    if(!sd)  return -1;

    (message = "dataparser_o: ") << "mergeWithSymboldata(): parsed";
    ::logg<<message;

    hd = new histdata_o;
    hd->date(getDate());

    (s = "") << sd->lastTrade();
    x = s.stoi();
    hd->close(x);

    (s = "") << sd->open();
    x = s.stoi();
    hd->open(x);

    (s = "") << sd->range();
    s.cut("-");
    s.cut(s.length()-1);
    u = s;
    u.reverse();
    u.cut(".");
    s.cut(s.length()-(u.length()-3));
    s.transpose(".","");
    x = s.stoi();
    hd->low(x);

    (s = "") << sd->range();
    s.upcut("-");
    u = s;
    u.reverse();
    u.cut(".");
    s.cut(s.length()-(u.length()-3));
    s.transpose(".","");
    x = s.stoi();
    hd->high(x);

    (s = "") << sd->volume();
    x = s.stoi();
    hd->volume(x);

    (message = "dataparser_o: ");
    *hd >> message;
    ::logg << message;


    list.put(hd);
    hd2 = hd;


    (message = "dataparser_o: ") << "mergeWithSymboldata(): loaded";
    ::logg<<message;

    x = 0;
    hd = listload.get();
    while(hd)  {
        if(x++ < 20)  {
            (message = "dataparser_o: ");
            *hd >> message;
            ::logg << message;
        }

        date1 = hd->date();
        date2 = hd2->date();

        if(!(date1 == date2))  list.put(hd);

        hd = listload.get();
    }

    return 0;
}

int dataparser_o::copyHistdataList(list_o<histdata_o>* hdl)  {
    histdata_o* hd;

    hd = list.first();
    while(hd)  {
        hdl->put(new histdata_o(*hd));
        hd = list.next();
    }

    return 0;
}


int dataparser_o::parseStringTest()  {
    string_o message;


    if(ParseStringTest)  return ParseStringTest;

    if(ParseString.contains("</html>"))  {
        (message = "dataparser_o: ") << "Parse string tested good for \"</html>\".";
        ::logg << message;

        ParseStringTest = 1;
    }
    else  {
        (message = "dataparser_o: ") << "Parse string tested bad for \"</html>\".";
        ::logg << message;
    }

    return ParseStringTest;
}


int dataparser_o::parse()  {
    string_o message;
    int      ret = 0;
    int      c;
    string_o s;
    string_o t;
    string_o u;
    string_o v;
    histdata_o* hd;
    list_o<histdata_o> list2;
    list_o<histdata_o> list3;
    

    if(!ParseStringTest)  return -1;


    (message = "dataparser_o: ") << "Begining parsing of receive string.";
    ::logg << message;

    t = ParseString;
    s = t;
    s.upcut("yfnc_tabledata1");
    while(s.contains("yfnc_tabledata1"))  {

        hd = new histdata_o;
        s.upcut('>');
        t = s;
        t.cut(200);
        if(t.contains("center"))  {
            // A "cash dividend" adds unwanted rows to the table.
            s.upcut("yfnc_tabledata1");
            s.upcut("yfnc_tabledata1");
            continue;
        }
        t.cut('<');
        t.boxears();
        hd->date(date(t.string()));

/*
        if(!ret && !t.contains("Jan") && !t.contains("Feb") &&
           !t.contains("Mar") && !t.contains("Apr") && !t.contains("May") &&
           !t.contains("Jun") && !t.contains("Jul") && !t.contains("Aug") &&
           !t.contains("Sep") && !t.contains("Oct") && !t.contains("Nov") &&
           !t.contains("Dec"))*/

        if(hd->date() < 18880101)  {

            (message="") << "Parse error possable; no date? " << t;
            ::logg << message;

            ParseStringTest = 1;
            ret = 1;
        }

        s.upcut("yfnc_tabledata1");
        s.upcut('>');
        t = s;
        t.cut('<');
        hd->open((int)(atof(t.string())*100));

        s.upcut("yfnc_tabledata1");
        s.upcut('>');
        t = s;
        t.cut('<');
        hd->high((int)(atof(t.string())*100));

        s.upcut("yfnc_tabledata1");
        s.upcut('>');
        t = s;
        t.cut('<');
        hd->low((int)(atof(t.string())*100));

        s.upcut("yfnc_tabledata1");
        s.upcut('>');
        t = s;
        t.cut('<');
        hd->close((int)(atof(t.string())*100));

        s.upcut("yfnc_tabledata1");
        s.upcut('>');
        t = s;
        t.cut('<');

        v = t;
        v.cut(',');
        u = t;
        while(u.contains(","))  {
            u.upcut(',');
            v << u;
            v.cut(',');
        }
        hd->volume(atoi(v.string()));

        s.upcut("yfnc_tabledata1");
        s.upcut('>');
        t = s;
        t.cut('<');
        hd->adjusted((int)atof(t.string())*100);


        listparse.put(hd);


        s.upcut("yfnc_tabledata1");
    }


/*
    c = listparse.cardinality();
    while(list3.cardinality() != c)  {
        while(listparse.cardinality())  {
            hd = listparse.get();
            list2.put(hd);
        }

        while(list2.cardinality())  {
            hd = list2.get();
            if(!list2.cardinality())  {
                list3.put(hd);
            }
            else  listparse.put(hd);
        }
    }
    hd = list3.get();
    while(hd)  {
        listparse.put(hd);
        hd = list3.get();
    }

    (message = "dataparser_o: ") << "Reversed closing prices list order, " << listparse.cardinality() << '.';
    ::logg << message;
*/


    return ret;
}

int dataparser_o::parseSymbol(symboldata_o* symboldata)  {
    int ret = 0;
    string_o message;
    string_o s;
    string_o t;
    string_o u;

    if(!symboldata)  return -1;


    s = ParseString;


    s.upcut("TABLE");
    s.upcut("yfnc_modtitlew1");
    s.upcut("yfnc_modtitle1");
    s.upcut(">");
    s.upcut(">");
    s.upcut(">");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    t.transpose(" ","_");
    symboldata->companyName(t.string());
(message = "dataparser_o: name:") << t.string();
//::logg << message;


    s.upcut("Last");
    s.upcut("Trade");
    s.upcut("yfnc_tabledata1");
    s.upcut(">");
    s.upcut(">");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    u = t;
    u.reverse();
    u.cut(".");
    t.cut(t.length()-(u.length()-3));
    t.transpose(".","");
    symboldata->lastTrade(t.string());
(message = "dataparser_o: last:") << t.string();
//::logg << message;


    s.upcut("Open");
    s.upcut("yfnc_tabledata1");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    u = t;
    u.reverse();
    u.cut(".");
    t.cut(t.length()-(u.length()-3));
    t.transpose(".","");
    symboldata->open(t.string());
(message = "dataparser_o open:") << t.string();
//::logg << message;



    s.upcut("Day");
    s.upcut("Range");
    s.upcut("yfnc_tabledata1");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    t.transpose(" ","");
    symboldata->range(t.string());
(message = "dataparser_o: range:") << t.string();
//::logg << message;


    s.upcut("Volume");
    s.upcut("yfnc_tabledata1");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    t.transpose(",","");
    symboldata->volume(t.string());
(message = "dataparser_o: volume:") << t.string();
//::logg << message;


    s.upcut("Market");
    s.upcut("Cap");
    s.upcut("yfnc_tabledata1");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    symboldata->marketCap(t.string());
(message = "dataparser_o: cap:") << t.string();
//::logg << message;


    s.upcut("P/E");
    s.upcut("yfnc_tabledata1");
    s.upcut(">");
    t = s;
    t.cut("<");
    t.cut(t.length()-1);
    symboldata->pe(t.string());
(message = "dataparser_o: pe:") << t.string();
//::logg << message;


    return ret;
}

int dataparser_o::loadRawData()  {
    string_o filename;
    ifstream in;
    char buf[65535];

    (filename = Symbol) << ".raw";
    ParseString = "";

    in.open(filename.string());
    if(in)  {
        while(!in.eof())  {
            ::memset(buf,'\0',65535);
            in >> buf;
            ParseString << buf;
        }
    }
    return ParseString.length();
}


int dataparser_o::date(const char* d)  {
    string_o s;
    int day;
    int month;
    int year;

    s = d;
    day = s.stoi();

    s.upcut('-');

    if(s.contains("Jan"))  month = 1;
    if(s.contains("Feb"))  month = 2;
    if(s.contains("Mar"))  month = 3;
    if(s.contains("Apr"))  month = 4;
    if(s.contains("May"))  month = 5;
    if(s.contains("Jun"))  month = 6;
    if(s.contains("Jul"))  month = 7;
    if(s.contains("Aug"))  month = 8;
    if(s.contains("Sep"))  month = 9;
    if(s.contains("Oct"))  month = 10;
    if(s.contains("Nov"))  month = 11;
    if(s.contains("Dec"))  month = 12;

    s.upcut('-');
    year = s.stoi();

    s = "";
    s << "20";
    if(year < 10)  s << '0';
    s << year;
    if(month < 10)  s << '0';
    s << month;
    if(day < 10)  s << '0';
    s << day;
    return  s.stoi();
}


/******************************************************************************/
