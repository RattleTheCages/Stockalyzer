/**  datacheck.h  **************************************************************


when      who   what
05.02.04  Dan   Creation.
07.14.04  Dan   Added.  Using new object marketdates_o and saving valid
                        marketdate file.


*******************************************************************************/


#ifndef DATACHECKOBJECT_H
#define DATACHECKOBJECT_H

#ifndef NULL
#define NULL 0
#endif


#include "string/string.h"
#include "memory/list.h"
#include "memory/bstree.h"
#include "other/sysinfo.h"
#include "log/log.h"

#include "../dataobjects/symboldata.h"
#include "../dataobjects/marketdates.h"


#define DATACHECKOBJECT_STATE_CLEAR   0
#define DATACHECKOBJECT_STATE_VOID  255


class datacheck_o  {
  private:
    int      State;
    symbols_o Symbols;
    symbols_o FlaggedSymbols;
    bstree_o<string_o> Tree;
    marketdates_o Marketdates;

    int loadHistdata(symboldata_o*);

  public:
    datacheck_o();
    datacheck_o(const datacheck_o&);
   ~datacheck_o();
    datacheck_o& operator = (const datacheck_o&);


    int execute();
};

/******************************************************************************/



#endif

/******************************************************************************/
