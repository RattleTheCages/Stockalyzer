/**  datarequestor.cc  *********************************************************


when      who   what
04.08.04  Dan   Creation.
04.16.04  Dan   Added header file.


*******************************************************************************/


#include <errno.h>
#include <iostream.h>

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fstream.h>

#include "string/string.h"
#include "memory/list.h"
#include "other/sysinfo.h"
#include "log/log.h"
#include "../sserver/telenet/client.h"
#include "dataparser.h"
#include "histdata.h"

#include "datarequest.h"
#include "datarequestor.h"


log_o logg;
sysinfo_o sysinfo;

datarequestor_o datarequestor;


datarequestor_o::datarequestor_o()  {
    State = 0;

    Port = 2222;
    Server = "2.2.2.66";
}

datarequestor_o::~datarequestor_o()  {}


dataparser_o dataparser;
int datarequestor_o::execute()  {
    string_o message;
    string_o string;
    string_o string2;
    string_o date;
    symboldata_o symboldata;
    client_o client;

    datarequest_o datarequest;


    date << sysinfo.currentYear();
    if(sysinfo.currentMonth()+1 < 10)  date << '0';
    date << sysinfo.currentMonth()+1;
    if(sysinfo.currentDay() < 10)  date << '0';
    date << sysinfo.currentDay();
    (message = "datarequestor_o: ") << "Good Morning " << date.string() << " Flags: " << Flags;
    ::logg << message;

    if(Flags.contains("r"))  {
        (message = "datarequestor_o: ") << dataparser.loadRawData();
        dataparser.parseStringTest();
        message << "Loading raw data for symbol " << dataparser.symbol();
        ::logg << message;
    }
    else  {

        client.connect(Server.string(),Port);

        datarequest.request(dataparser.symbol());
        datarequest.type(Flags.string());
        datarequest >> string;
        client.send(string);

//if(Flags.contains("hist")) sleep(97);
//else sleep(24);

        string = "";
        while(!string.contains("</html>"))  {
            string2 = "";
            client.recv(string2);
            string << string2;
        }
        datarequest << string.string();

        dataparser.parsestring(string.string());
        dataparser.parseStringTest();
    }

    if(Flags.contains("symb"))  {
        symboldata.symbol(dataparser.symbol());
        (message = "datarequestor_o: ") << dataparser.parseSymbol(&symboldata);
        message << "\nName:" << symboldata.companyName();
        message << "\nLast:" << symboldata.lastTrade();
        message << "\nRange:" << symboldata.range();
        message << "\nOpen:" << symboldata.open();
        message << "\nVolume:" << symboldata.volume();
        message << "\nMarket Cap:" << symboldata.marketCap();
        message << "\nP/E:" << symboldata.pe();
        ::logg << message;
        (message = "datarequestor_o: ");
        symboldata>>message;
        ::logg << message;

        dataparser.saveSymbolToFile(&symboldata);

        (message = "datarequestor_o: ") << dataparser.loadFromFile();
        ::logg << message;
        (message = "datarequestor_o: ") << dataparser.mergeWithSymboldata(&symboldata);
        ::logg << message;
        (message = "datarequestor_o: ") << dataparser.saveToFile();
        ::logg << message;
    }
    else  {
        (message = "datarequestor_o: ") << dataparser.parse();
        ::logg << message;
        (message = "datarequestor_o: ") << dataparser.loadFromFile();
        ::logg << message;
        (message = "datarequestor_o: ") << dataparser.merge();
        ::logg << message;

        (message = "datarequestor_o: ") << dataparser.saveToFile();
        ::logg << message;
    }


    if(!Flags.contains("r") && (Flags.contains("s") || !dataparser.parseStringTest()))  {
        ofstream out;
        string_o filename;

        (filename = dataparser.symbol()) << ".raw";
        if(!dataparser.parseStringTest())  filename << ".perr";

        out.open(filename.string());
        if(out)  {
            out << dataparser.parsestring();
            out.close();
        }
    }


    return 0;
}


int main(int argc, char* argv[])  {
    int ret;
    string_o flags;
    string_o port;

    ::logg.registerName(argv[0]);

    if(argc < 2)  {
        dataparser.symbol("XMSR");
    }
    else  {
        dataparser.symbol(argv[1]);

        if(argc > 1)  {
            flags = argv[2];
        }
        if(argc > 2)  {
            port = argv[3];
        }
    }


    if(port.isdigit())  datarequestor.port(port.stoi());
    datarequestor.flags(flags.string());
    ret = datarequestor.execute();

    return ret;
}

/******************************************************************************/
