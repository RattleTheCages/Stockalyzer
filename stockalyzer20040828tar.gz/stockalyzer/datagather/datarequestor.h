/**  datarequestor.h  **********************************************************


when      who   what
04.16.04  Dan   Creation.


*******************************************************************************/


#ifndef DATAREQUESTOROBJECT_H
#define DATAREQUESTOROBJECT_H

#include "string/string.h"
#include "memory/list.h"

#include "datarequestor.h"

class datarequestor_o  {
  private:
    int      State;
    string_o Flags;

    string_o Server;
    int      Port;


  public:
    datarequestor_o();
    datarequestor_o(const datarequestor_o&);
   ~datarequestor_o();
    datarequestor_o& operator = (const datarequestor_o&);

    int state() const;

    int execute();

    void flags(const char*);
    void port(int);
};

/******************************************************************************/

inline int datarequestor_o::state() const  {
    return State;
}

inline void datarequestor_o::flags(const char* f)  {
    Flags = f;
}

inline void datarequestor_o::port(int p)  {
    Port = p;
}


#endif

/******************************************************************************/
