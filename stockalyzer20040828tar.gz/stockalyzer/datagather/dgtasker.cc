/**  dgtasker.cc  **************************************************************


when      who    what
04.04.04  Dan    Creation.
04.16.04  Dan    Improved.  Takes commandline arguments, and compairs
                 the two inputs, livedata directory and symbol file.
06.09.04  Dan    Added:  Option y for gaithering sysmbol data.


*******************************************************************************/


#include <stdlib.h>
#include <fstream.h>

#include "other/sysinfo.h"
#include "log/log.h"
#include "../sserver/telenet/server.h"
#include "../sserver/telenet/client.h"
#include "datagather.h"
#include "dataparser.h"
#include "histdata.h"

#include "dgtasker.h"


log_o logg;
sysinfo_o sysinfo;
dgtasker_o dgtasker;


dgtasker_o::dgtasker_o()  {
    State = 0;
    Port  = 0;
}

dgtasker_o::~dgtasker_o()  {}


int dgtasker_o::getDate()  {
    int cday;
    string_o s;
    s << sysinfo.currentYear();
    if(sysinfo.currentMonth()+1 < 10)  s << '0';
    s << sysinfo.currentMonth()+1;

    cday = sysinfo.currentDay();  //!!!!!!$$$$*** what day is this? 
    cday -= 1; //!!!!!!$$$$*** what day is this? 
//  cday -= 2; //!!!!!!$$$$*** what day is this? 
//  cday -= 3; //!!!!!!$$$$*** what day is this? 
    
    if(cday <  10)  s << '0';
    s << cday;

    Date = s.stoi();

    return Date;
}


int dgtasker_o::kill(int type)  {
    int ret = 0;
    string_o  message;
    string_o  string;
    string_o  syscall;
    ifstream  in;
    char      buff[4096];

    (syscall = "") << "ps | grep " << type << " > /tmp/dgtasker.tmp2";
    system(syscall.string());
    string = "";
    in.open("/tmp/dgtasker.tmp2");
    while(in)  {
        memset(buff,'\0',sizeof(buff));
        in.getline(buff,sizeof(buff),'\n');
        if(in.eof())  break;

        (string = "") << buff;
::logg<<string;
        if(string.contains("datagatheror") ||
           string.contains("datarequestor")  ||
           string.contains("dgtasker"))  {
            string.boxears();
            string.cut(' ');

            (syscall = "") << "kill -9 " << string;
            (message = "dgtasker_o: ") << "Syscall: " << syscall;
            ::logg << message;
            system(syscall.string());
            ret++;
        }
    }
    in.close();
    system("rm -f /tmp/dgtasker.tmp2");

    return ret;
}


int dgtasker_o::server()  {
    string_o  message;
    string_o  string;
    string_o  syscall;
    server_o* server;
    int       socket;
    datarequest_o datarequest;

    if(Port < 1024)  return -1;

    (message = "dgtasker_o: ") << "Server start.";
    ::logg << message;


    server = new server_o(Port);
    while(2)  {
        socket = server->accept();

        string = "";
        while(!string.contains(DATAREQUESTOBJECT_TRAILER))
            server->recv(string);

        datarequest << string.string();



        (message = "dgtasker_o: ") << "Request: " << datarequest.request();
        message << "  Type: " << datarequest.type();
        ::logg << message;

        string = datarequest.request();
        if(string.contains("datagatheror"))  {
            syscall = "";
            syscall << "./datagatheror " << datarequest.type() << " &";

            (message = "dgtasker_o: ") << "Syscall: " << syscall;
            ::logg << message;

            system(syscall.string());

            (string = "") << "Okay.";
            datarequest.reply(string.string());
            string = "";
            datarequest >> string;
            server->send(string);

            server->close(socket);
        }

        if(string.contains("kill"))  {

            (string = "") << datarequest.type();
            if(kill(string.stoi()))  {
                (string = "") << "Okay.";
                datarequest.reply(string.string());
                string = "";
                datarequest >> string;
                server->send(string);
            }
            else  {
                (string = "") << "Not found.";
                datarequest.reply(string.string());
                string = "";
                datarequest >> string;
                server->send(string);
           }
        }
    }

    return 0;
}


int dgtasker_o::client()  {
    string_o  message;
    string_o  string;
    client_o* client;
    datarequest_o datarequest;

    (message = "dgtasker_o: ") << "Client request.";
    ::logg << message;

    datarequest.request("datagatheror");
    if(Flags.contains("k"))  datarequest.request("kill");
    (string = "") << Port;
    datarequest.type(string.string());

    client = new client_o;
    client->connect("2.2.2.66",8822);

    string = "";
    datarequest >> string;
    client->send(string.string());

    string = "";
    while(!string.contains(DATAREQUESTOBJECT_TRAILER))
        client->recv(string);
    datarequest << string.string();

    (message = "dgtasker_o: ") << "Reply " << datarequest.reply();
    ::logg << message;

    delete client;


    if(Flags.contains("k"))  kill(Port);

    return 0;
}


int dgtasker_o::checkDate(const symboldata_o* symbol)  {
    int x;
    string_o message;
    string_o s;
    string_o filename;
    char buff[4096];
    histdata_o hd;
    ifstream in;


    getDate();


    filename = "./livedata/";
    filename << symbol->symbol();
    filename << ".histdata_o";

    in.open(filename.string());
    if(!in)  {
        (message = "dgtasker_o: ") << filename << " missing.";
        ::logg.error(message);

        return -1;
    }

    for(x=0;x<sizeof(buff);x++)  *(buff+x) = '\0';

    in.getline(buff,sizeof(buff)-1,'\n');
    in.close();

    s << buff;
    hd << s.string();

    (message = "dgtasker_o: ") << "checkDate() " << hd.date() << ":" << Date;
    message << ":" << (hd.date() == Date);
    ::logg << message;

    return  (hd.date() == Date);
}

int dgtasker_o::rnd(int l)  {
    return  (((float)rand())/RAND_MAX)*l;
}

#include<iostream.h>
int dgtasker_o::randSymbols()  {
    int x;
    symboldata_o* symbol;
    list_o<symboldata_o> llist;
    list_o<symboldata_o> zlist;

    symbol = Symbols.first();
    while(symbol)  {
        llist.put(symbol);
        symbol = Symbols.next();
    }

    while(llist.cardinality() != RandomOrderSymbolList.cardinality())  {
        symbol = llist.first();
        while(symbol)  {
            zlist.put(symbol);
            symbol = llist.next();
        }
        x = rnd(zlist.cardinality());
        while(x--)  symbol = zlist.get();
        RandomOrderSymbolList.put(symbol);
        while(symbol)  {
            symbol = zlist.get();
        }
    }

    return 0;
}

int dgtasker_o::execute()  {
    int      x;
    string_o s,t;
    string_o message;
    string_o syscall;
    string_o filename;
    string_o dirname;
    char     buff[32767];
    ifstream in;
    symboldata_o* symbol;
    symboldata_o* symbol2;


    Filename = "symbols.symboldata_o";
    Dirname = "livedata";

    getDate();


    (message = "dgtasker_o: ") << "Datagathering Tasker " << Date << ": ";
    if(Flags.length() < 1)  {
        message << "\n";
        message << "s - Server,  Listen for syscall requests.\n";
        message << "c - Client,  Request for syscall requests.\n";
        message << "ck - Client kill,  Request to kill the client on the given port.\n";
        message << "x - Execute, otherwise the syscall is just displayed.\n";
        message << "\n";
        message << "l - Load symbols from file `" << Filename << "'\n";
        message << "d - Look in directory `" << Dirname << "' for symbols.\n";
        message << "\n";
        message << "m - Merge symbols from file and directory.\n";
        message << "n - Do symbols from file that are not already in the directory.\n";
        message << "f - Filter using current date.\n";
        message << "\n";
        message << "r - Task dataraquestor for daily.\n";
        message << "rh - Task dataraquestor for history.\n";
        message << "y - Task dataraquestor for symbol.\n";
        message << "a - Task analysis.\n";
        message << "For example:\n";
        message << "./dgtasker x l d n r 2250\n";
        message << "./dgtasker x d m a\n";
        message << "./dgtasker s 8822\n";
        message << "./dgtasker c 2250\n";
        message << "./dgtasker ck 2250\n";
        ::logg << message;

        return -1;
    }



    message = "dgtasker_o: ";
    if(Flags.contains("s"))  {
        message << "Server ";
    }
    if(Flags.contains("l"))  {
        message << "Load ";
    }
    if(Flags.contains("d"))  {
        message << "Directory ";
    }
    if(Flags.contains("x"))  {
        message << "Execute ";
    }
    if(Flags.contains("m"))  {
        message << "Merge ";
    }
    if(Flags.contains("n"))  {
        message << "Do ";
    }
    if(Flags.contains("w"))  {
        message << "Write ";
    }
    ::logg << message;



    if(Flags.contains("s"))  {
        server();
    }
    if(Flags.contains("c"))  {
        client();
    }
    if(Flags.contains("l"))  {
        Symbols.load();
    }
    if(Flags.contains("d"))  {
        Symbols.directory();
    }


    if(Flags.contains("m"))  x = Symbols.merge();
    if(Flags.contains("n"))  x = Symbols.filter();
    if(Flags.contains("i"))  {
        x = Symbols.invalid();
        Symbols.save("valid.symboldata_o");
        return 0;
    }
    if(Flags.contains("w"))  Symbols.save("write.symboldata_o");

    (message = "dgtasker_o: ") << "Number of symbols: " << x << '.';
    ::logg << message;

//  randSymbols();

    if(Flags.contains(" r") || Flags.contains(" a") || Flags.contains(" y"))  {
        symbol = Symbols.first();
//      symbol = RandomOrderSymbolList.first();
        while(symbol)  {
            syscall = "";
            if(Flags.contains("r"))  {
                if(!Flags.contains("f") || !checkDate(symbol))  {
                    (syscall = "cd livedata;");
                    syscall << "../datarequestor " << symbol->symbol() << " daily " << Port;
                }
                else  {
                    (message = "dgtasker_o: ") << "Symbol " << symbol->symbol();
                    message << " has current date.  Skipping.";
                    ::logg << message;
                }
            }
            if(Flags.contains("rh"))  {
                (syscall = "cd livedata;");
                syscall << "../datarequestor " << symbol->symbol() << " hist " << Port;
            }
            if(Flags.contains("y"))  {
                if(!Flags.contains("f") || !checkDate(symbol))  {
                (syscall = "cd livedata;");
                syscall << "../datarequestor " << symbol->symbol() << " symbol " << Port;
}
            }
            if(Flags.contains("a"))  {
                if(!Flags.contains("f") || checkDate(symbol))  {
                    (syscall = "cd livedata;");
                    syscall << "../analysis " << symbol->symbol();
                }
            }

            if(syscall.length() > 2)  {
                (message = "dgtasker_o: ") << "syscall: " << syscall;
                ::logg << message;
            }

            if(Flags.contains("x") && syscall.length() > 2)  {
                system(syscall.string());
            }

            symbol = Symbols.next();
//          symbol = RandomOrderSymbolList.next();
        }
    }

    return 0;
}


int main(int argc, char* argv[])  {
    int      x;
    string_o s;
    string_o flags;
    string_o port;
sranddev();
    ::logg.registerName(argv[0]);
    ::logg.setDebugLevel(4600);
    ::logg.setDebugLevel(4601);

    for(x=1;x<argc;x++)  flags << ' ' << argv[x];

    s = flags;
    s.reverse();
    s.cut(' ');
    s.reverse();
    if(s.isdigit())  port << s;

    dgtasker.flags(flags.string());
    dgtasker.port(port.stoi());

    return  dgtasker.execute();
}

/******************************************************************************/
