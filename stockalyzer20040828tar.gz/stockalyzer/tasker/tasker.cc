/**  tasker.cc  ****************************************************************


    From given sectors trace each symbol of the list of symbol through the
        following processes, allowing each symbol to procied through
        individually to take advantage of distribuitive processing and
        to move along other symbols when problems arise with individual
        symbols.

        Use a datarequestor server to request daily or history of symbol
            to get its histdata_o's.
        Use an analysis server to process daily analysis.
        Use an analysis server to process trend line (and other processes
            that may take longer cpu times.)

    This tasker object is a server that takes individual symboldata_o
        object requests and sectordata_o object requests.


when      who   what
04.14.04  Dan   Creation.
07.14.04  Dan   Changed to tasker from orignal dgtasker in the datagather
                directory.
07.26.04  Dan   Added.    Anlysis thread.  Abstracted update into its
                          own object: taskerupdate.


Debug Level: 5500-5699

*******************************************************************************/


#include <unistd.h>

#include "other/sysinfo.h"
#include "log/log.h"
#include "thread/thread.h"
#include "../sserver/telenet/server.h"
#include "../sserver/telenet/client.h"
#include "../datagather/dataparser.h"
#include "histdata.h"
#include "datastore.h"

#include "tasker.h"


log_o logg;
sysinfo_o sysinfo;
server_o* serverObj;
tasker_o* tasker;
thread_o* serverthread;
thread_o* updatethread;
thread_o* analysisthread;


void* serverthreadstart(void* v)  {
    ((tasker_o*)v)->server();
    return v;
}

void* updatethreadstart(void* v)  {
    ((tasker_o*)v)->updatethread(updatethread);
    return v;
}

void* analysisthreadstart(void* v)  {
    ((tasker_o*)v)->analysisthread(analysisthread);
    return v;
}


tasker_o::tasker_o()  {
    State = TASKEROBJECT_STATE_CLEAR;
    Port  = TASKEROBJECT_DEFAULT_SERVER_PORT;

    Filename = "tasker_o.tasker_o";
    Dirname = "../config/";

    MaxSteps = 18;
}

tasker_o::~tasker_o()  {}



int tasker_o::server()  {
    string_o  message;
    string_o  string;
    string_o  syscall;
    int       socket;
    task_o*   task;
    int       taskno = 0;
    datarequest_o datarequest;
    symboldata_o* symboldata;
    clientdata_o* clientdata;

    if(::logg.debug(5501))  {
        (message = "tasker_o: ") << "server().  Server starting on port ";
        message << Port << '.';
        ::logg << message;
    }

    if(Port < 1024)  {
        State = TASKEROBJECT_STATE_SOCKET_PROBLEM;
        return State;
    }

    ::serverObj = new server_o(Port);
    while(2)  {
        socket = ::serverObj->accept();


/*      if(::serverObj->error() != ERROR_OK)  {
            (message = "tasker_o: ") << "server().  Server error occured. ";
            message << ::serverObj->error() << "  Aborting.";
            ::logg.error(message);

            State = TASKEROBJECT_STATE_SOCKET_PROBLEM;
            return State;
        }*/


        string = "";
        while(!string.contains(DATAREQUESTOBJECT_TRAILER))  ::serverObj->recv(string);

        datarequest << string.string();



        if(::logg.debug(5503))  {
            (message = "tasker_o: ") << "server().  Request: " << datarequest.request();
            message << "  Type: " << datarequest.type();
            ::logg << message;
        }

        string = datarequest.type();
        if(string.contains("symboldata_o"))  {
            (string = "") << "Okay, symboldata_o request.";
            datarequest.reply(string.string());
            string = "";
            datarequest >> string;
            ::serverObj->send(socket,string);
            ::serverObj->close(socket);

            symboldata = new symboldata_o;
            symboldata->symbol(datarequest.request());

            task = new task_o;
            task->Id = taskno++;
            task->Symboldata = symboldata;
            string = "";
            string << task->id() << ':' << symboldata->symbol();
            TaskTree.insert(string,task);

            ExecuteQueue.put(task);
        }
        else  if(string.contains("analysisclient"))  {

            clientdata = new clientdata_o;
            clientdata->socket(socket);
            AnalysisClientQueue.put(clientdata);

        }

    }

    return State;
}


int tasker_o::client()  {
    string_o  message;
    string_o  string;
    client_o* client;
    datarequest_o datarequest;


    State = TASKEROBJECT_STATE_CLIENT;

    (string = "") << Flags;
    string.boxears();

    if(::logg.debug(5501))  {
        (message = "tasker_o: ") << "Sending client request: ";
        message << string;
        ::logg << message;
    }

    datarequest.type("symboldata_o");
    datarequest.request(string.string());

    client = new client_o;
    client->connect(TASKEROBJECT_DEFAULT_SERVER_IP,TASKEROBJECT_DEFAULT_SERVER_PORT);

    string = "";
    datarequest >> string;
    client->send(string.string());

    string = "";
    while(!string.contains(DATAREQUESTOBJECT_TRAILER))  client->recv(string);
    datarequest << string.string();

    if(::logg.debug(5503))  {
        (message = "tasker_o: ") << "Tasker server reply: ";
        message << datarequest.reply();
        ::logg << message;
    }

    delete client;

    return State;
}



int tasker_o::updatethread(thread_o* thread)  {
    string_o      message;
    int           marketday;
    task_o*       task;
    symboldata_o* sd;

    if(::logg.debug(5501))  {
        (message = "tasker_o: ") << thread->name() << ": ";
        message << "updatethread() start.";
        ::logg << message;
    }

    while(task = UpdateQueue.get())  {
        task->incrementStep();

        sd = task->Symboldata;

        if(::logg.debug(5511))  {
            (message = "tasker_o: ") << thread->name() << ": Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "Update thread off UpdateQueue with task " << sd->symbol() << '.';
            task->message(message.string());
            ::logg << message;
        }

        marketday = Marketdates.marketDay();


        if(!task->HistdataLast  ||
           marketday == MARKETDATESOBJECT_MARKETDAY_CLOSED  ||
           marketday == MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN  ||
           marketday == MARKETDATESOBJECT_NON_MARKETDAY)  {

            task->State = TASKOBJECT_ACTION_UPDATE_HISTORY;

            (message = "tasker_o: ") << thread->name() << ": Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Updating history " << sd->symbol();
            task->message(message.string());
            if(::logg.debug(5512))  ::logg << message;


            thread->yeild();
            Taskerupdate.updateHistory(task);
        }


        if(marketday == MARKETDATESOBJECT_MARKETDAY_PREHOURS  ||
           marketday == MARKETDATESOBJECT_MARKETDAY_OPEN  ||
           marketday == MARKETDATESOBJECT_MARKETDAY_AFTERHOURS)  {

            task->State = TASKOBJECT_ACTION_UPDATE_DAILY;

            (message = "tasker_o: ") << thread->name() << ": Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Updating daily.";
            message << " XXXX Currently No Action.";
            task->message(message.string());
            if(::logg.debug(5512))  ::logg << message;

Taskerupdate.updateHistory(task);//No action?????!?!?!?!?!?!?
        }



        if(::logg.debug(5512))  {
            (message = "tasker_o: ") << thread->name() << ": Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Update thread placing task " << sd->symbol() << " back on execute queue.";
            task->message(message.string());
            ::logg << message;
        }


        ExecuteQueue.put(task);
    }

    return State;
}


int tasker_o::analysisthread(thread_o* thread)  {
    string_o      message;
    string_o      s;
    task_o*       task;
    symboldata_o* sd;
    histdata_o*   hd;
    datarequest_o datarequest;
    clientdata_o* clientdata;

    if(::logg.debug(5501))  {
        (message = "tasker_o: ") << thread->name() << ": ";
        message << "analysisthread() start.";
        ::logg << message;
    }

    while(task = AnalysisQueue.get())  {
        task->incrementStep();

        sd = task->Symboldata;

        (message = "tasker_o: ") << thread->name() << ": Task:" << task->symbol();
        message << " id:" << task->id() << " Step:" << task->step();
        task->message(message.string());
        if(::logg.debug(5511))  ::logg << message;


        thread->yeild();

        datarequest.clear();
        datarequest.type("analdata_o");
        datarequest.request(task->symbol());
        s = "";
        hd = task->Histdata.first();
        while(hd)  {
            s << "    ";
            *hd >> s;
            s << '&';
            hd = task->Histdata.next();
        }
        datarequest.data(s.string());


        if(::logg.debug(5512))  {
            (message = "tasker_o: ") << thread->name() << ": ";
            message << "Prepering to get an AnalysisClient off the AnalysisClientQueue.  ";
            message << "If no Analysis Clients are available, this may block.";
            ::logg << message;
        }

        clientdata = AnalysisClientQueue.get();

        if(::logg.debug(5513))  {
            (message = "tasker_o: ") << thread->name() << ": ";
            message << "AnalysisClientQueue gave AnalysisClient ";
            message << clientdata->id() << " on local socket " << clientdata->socket();
            ::logg << message;
        }

        s = "";
        datarequest >> s;

::serverObj->send(clientdata->socket(),s.string());
::serverObj->close(clientdata->socket());

        if(::logg.debug(5513))  {
            (message = "tasker_o: ") << thread->name() << ": ";
            message << "Analysis task sent.";
            (s = "") << datarequest.data();
            message << "  Datasize:" << s.length();
            ::logg << message;
        }

        thread->yeild();
        

    }

    return State;
}


int tasker_o::execute()  {
    int           ret = 0;
    int           backdays = 0;
    int           marketday = 0;
    string_o      s;
    string_o      message;
    datastore_o   datastore;
    task_o*       task;
    histdata_o    hd;
    analdata_o    ad;


    Marketdates.load();


    ::serverthread = new thread_o(1,"serverthread");
    ::serverthread->start(serverthreadstart,(void*)tasker);

    ::updatethread = new thread_o(2,"updatethread");
    ::updatethread->start(updatethreadstart,(void*)tasker);

    ::analysisthread = new thread_o(3,"analysisthread");
    ::analysisthread->start(analysisthreadstart,(void*)tasker);


    while(task = ExecuteQueue.get())  {

        if(!task)  {
            (message = "tasker_o: ") << "NULL task returned from ExecuteQueue.get().";
            ::logg.error(message);
            return  State;
        }

        task->incrementStep();

        (message = "tasker_o: ") << "Task:" << task->symbol();
        message << " id:" << task->id() << " Step:" << task->step();
        message << "  ExecuteQueue cardinality:" << ExecuteQueue.cardinality();
        if(::logg.debug(5504))  ::logg << message;


        if(task->step() > MaxSteps)  {
            (message = "tasker_o: ") << "Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Reports over " << MaxSteps << " steps.  Placing in discard queue.";
            task->message(message.string());
            ::logg.error(message);

            DiscardQueue.put(task);
            continue;
        }

::serverthread->yeild();

        if(!task->Symboldata)  {
            task->State = TASKOBJECT_STATE_MISSING_SYMBOLDATA;

            (message = "tasker_o: ") << "Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Missing symboldata_o.  Placing in discard queue.";
            task->message(message.string());
            ::logg.error(message);

            DiscardQueue.put(task);
            continue;
        }


        if(!task->HistdataLast)  {

            (s = "") << task->Symboldata->symbol() << ".histdata_o";
            //ret = datastore.loadHistdata(s.string(),&hd);
            ret = datastore.loadHistdata(*task->Symboldata,&hd);

            if(hd.date() > 18880000)  task->HistdataLast = &hd;

            (message = "tasker_o: ") << "Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            if(!task->HistdataLast)  message << "  No histdata_o file found.";
            else  message << "  Loaded last histdata_o: " << task->HistdataLast->date();
            task->message(message.string());
            if(::logg.debug(5504))  ::logg << message;
        }


        marketday = Marketdates.marketDay();
        if(marketday == MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN ||
           marketday == MARKETDATESOBJECT_MARKETDAY_PREHOURS)  backdays = 1;
        if(sysinfo.currentDayOfWeek() == 0)  backdays = 2;  //Sunday.
        if(sysinfo.currentDayOfWeek() == 6)  backdays = 1;  //Saturday.
        if(marketday == MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN &&
           sysinfo.currentDayOfWeek() == 1)  backdays = 3;  // Monday before open.

        (message = "tasker_o: ") << "Task:" << task->symbol();
        message << " id:" << task->id() << " Step:" << task->step();
        message << "  Marketdates_o reports: ";
        if(marketday == MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN)  message << "Closed, before open.";
        if(marketday == MARKETDATESOBJECT_MARKETDAY_PREHOURS)  message << "Prehours.";
        if(marketday == MARKETDATESOBJECT_MARKETDAY_OPEN)  message << "Open.";
        if(marketday == MARKETDATESOBJECT_MARKETDAY_AFTERHOURS)  message << "After hours.";
        if(marketday == MARKETDATESOBJECT_MARKETDAY_CLOSED)  message << "Closed, for today.";
        if(marketday == MARKETDATESOBJECT_NON_MARKETDAY)  message << "Non-market day.";
        message << "  Backdays: " << backdays;
        if(task->HistdataLast)  {
            message << "  Histdata_o:" << task->HistdataLast->date() << "!=";
            message << Marketdates.date()-backdays << ':';
            message << (task->HistdataLast->date() != Marketdates.date()-backdays);
        }
        task->message(message.string());
        if(::logg.debug(5504))  ::logg << message;


        if(!task->HistdataLast  ||
           ((marketday == MARKETDATESOBJECT_MARKETDAY_CLOSED  ||
             marketday == MARKETDATESOBJECT_MARKETDAY_BEFOREOPEN  ||
             marketday == MARKETDATESOBJECT_MARKETDAY_PREHOURS  ||
             marketday == MARKETDATESOBJECT_MARKETDAY_AFTERHOURS ||
             marketday == MARKETDATESOBJECT_NON_MARKETDAY)  &&
            task->HistdataLast->date() != Marketdates.date()-backdays))  {

            (message = "tasker_o: ") << "Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Placing task on UpdateQueue.";
            task->message(message.string());
            if(::logg.debug(5504))  ::logg << message;

            UpdateQueue.put(task);
            continue;
        }



        if(!task->AnaldataLast)  {

            (s = "") << task->Symboldata->symbol() << '.' << ANALDATAOBJECT_OBJECT;
            ad.clear();
            datastore.loadAnaldata(*task->Symboldata,&ad);

            (message = "tasker_o: ") << "Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            if(ad.date() < 17770000)  message << "  No analdata_o file found.";
            else  message << "  Loaded last analdata_o: " << ad.date();
            task->message(message.string());
            if(::logg.debug(5504))  ::logg << message;

            if(ad.date() == Marketdates.date()-backdays)  {
                (message = "tasker_o: ") << "Task:" << task->symbol();
                message << " id:" << task->id() << " Step:" << task->step();
                message << "  Analdata current.";
                task->message(message.string());
                if(::logg.debug(5504))  ::logg << message;

                continue;
            }

            if(task->Histdata.cardinality() < 2)  {
                (s = "") << task->Symboldata->symbol() << ".histdata_o";
                datastore.loadHistdata(*task->Symboldata,&task->Histdata);
            }

            task->State = TASKOBJECT_ACTION_ANALYSIS_SHORT;


            (message = "tasker_o: ") << "Task:" << task->symbol();
            message << " id:" << task->id() << " Step:" << task->step();
            message << "  Placing on AnalysisQueue.";
            task->message(message.string());
            if(::logg.debug(5504))  ::logg << message;

            AnalysisQueue.put(task);
            continue;
        }

    }

    return State;
}


int main(int argc, char* argv[])  {
    int      x;
    string_o s;
    string_o flags;
    string_o port;

//  ::logg.registerName(argv[0]);
    ::logg.setDebugLevel(5500);
    ::logg.setDebugLevel(5501);
    ::logg.setDebugLevel(5503);
    ::logg.setDebugLevel(5504);
    ::logg.setDebugLevel(5509);
    ::logg.setDebugLevel(5707);
//  ::logg.setDebugLevel(5708);
    for(x=5511;x<5550;x++)  ::logg.setDebugLevel(x);
    for(x=4600;x<4646;x++)  ::logg.setDebugLevel(x);
//  for(x=4690;x<4700;x++)  ::logg.setDebugLevel(x); //datastore_o

    tasker = new tasker_o;

    if(argc > 1)  {

        for(x=1;x<argc;x++)  flags << ' ' << argv[x];
        s = flags;
        s.reverse();
        s.cut(' ');
        s.reverse();
        if(s.isdigit())  {
            port << s;
            tasker->port(port.stoi());
            tasker->flags(flags.string());
        }

        return  tasker->client();
    }


    return  tasker->execute();
}

/******************************************************************************/
