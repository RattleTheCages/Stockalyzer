/**  taskerupdate.h  ***********************************************************

    The taskerupdate_o object preforms the procedures to update, to the most
        current status as possable, a given task/symbol. 

when      who   what
04.14.04  Dan   Creation.    This stuff was originally in tasker_o.
07.26.04  Dan   Abstracted update into its own object.

*******************************************************************************/


#ifndef TASKERUPDATEOBJECT_H
#define TASKERUPDATEOBJECT_H

#include "task.h"

#include "string/string.h"
#include "memory/list.h"
#include "memory/bstree.h"
#include "thread/queue.h"

#include "symboldata.h"
#include "marketdates.h"
#include "datarequest.h"

#define TASKERUPDATEOBJECT_STATE_OK             0
#define TASKERUPDATEOBJECT_STATE_VOID           255
#define TASKERUPDATEOBJECT_STATE_SOCKET_PROBLEM 32765
#define TASKERUPDATEOBJECT_STATE_NULL_PASSED    32766

class taskerupdate_o  {
  private:
    int       State;
    int       Date;
    marketdates_o Marketdates;

    string_o  SymbolDataServer;
    int       SymbolDataPort;

    int   getDate(int);
    int   getTime();
    int   howManyDaysBehind(const symboldata_o*);
    int   requestSymboldataClient(symboldata_o*);
    int   requestHistdataClient(symboldata_o*);


  public:
    taskerupdate_o();
    taskerupdate_o(const taskerupdate_o&);
   ~taskerupdate_o();
    taskerupdate_o& operator = (const taskerupdate_o&);

    int   state() const;

    int   updateToday(task_o*);
    int   updateHistory(task_o*);
};

/******************************************************************************/

inline int taskerupdate_o::state() const  {
    return State;
}


#endif

/******************************************************************************/
