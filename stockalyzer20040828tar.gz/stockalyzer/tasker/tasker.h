/**  tasker.h  *****************************************************************


    From given sectors trace each symbol of the list of symbol through the
        following processes, allowing each symbol to procied through
        individually to take advantage of distribuitive processing and
        to move along other symbols when problems arise with individual
        symbols.

        Use a datarequestor server to request daily or history of symbol
            to get its histdata_o's.
        Use an analysis server to process daily analysis.
        Use an analysis server to process trend line (and other processes
            that may take longer cpu times.)

    This tasker object is a server that takes individual symboldata_o
        object requests and sectordata_o object requests.


when      who   what
04.14.04  Dan   Creation.
07.14.04  Dan   Changed to tasker from orignal dgtasker in the datagather
                directory.
07.26.04  Dan   Added.    Anlysis Queue and thread.
08.24.04  Dan   Added.    Analysis Client Queue and other analysis client stuff.

*******************************************************************************/


#ifndef TASKEROBJECT_H
#define TASKEROBJECT_H

#include "task.h"

#include "string/string.h"
#include "memory/list.h"
#include "memory/bstree.h"
#include "thread/queue.h"

#include "symboldata.h"
#include "marketdates.h"
#include "datarequest.h"
#include "clientdata.h"
#include "taskerupdate.h"

#define TASKEROBJECT_DEFAULT_SERVER_IP            "2.2.2.42"
#define TASKEROBJECT_DEFAULT_SERVER_PORT          9289

#define TASKEROBJECT_STATE_CLEAR          0
#define TASKEROBJECT_STATE_CLIENT         1
#define TASKEROBJECT_STATE_SOCKET_PROBLEM 17
#define TASKEROBJECT_STATE_NULL_PASSED    18
#define TASKEROBJECT_STATE_VOID           255

class tasker_o  {
  private:
    int       State;
    int       Date;
    int       MaxSteps;
    int       Port;
    string_o  Flags;
    string_o  Filename;
    string_o  Dirname;
    symbols_o Symbols;
    marketdates_o Marketdates;
    taskerupdate_o Taskerupdate;

    bstree_o<task_o> TaskTree;

    queue_o<task_o> ExecuteQueue;
    queue_o<task_o> UpdateQueue;
    queue_o<task_o> AnalysisQueue;
    queue_o<task_o> DiscardQueue;

    queue_o<clientdata_o> AnalysisClientQueue;


//    int   getDate(int);
//    int   getTime();
//    int   howManyDaysBehind(const symboldata_o*);
//    int   requestSymboldataClient(symboldata_o*);
//    int   requestHistdataClient(symboldata_o*);

//    int   updateOneDay(task_o*);
//    int   updateHistory(task_o*);

  public:
    tasker_o();
    tasker_o(const tasker_o&);
   ~tasker_o();
    tasker_o& operator = (const tasker_o&);

    int   state() const;

    int   execute();
    int   server();
    int   client();
    int   updatethread(thread_o*);
    int   analysisthread(thread_o*);

    int   updatedata(task_o*);
    int   analysisdata(task_o*);

    void  flags(const char*);
    void  port(int);
};

/******************************************************************************/

inline int tasker_o::state() const  {
    return State;
}

inline void tasker_o::flags(const char* f)  {
    Flags = f;
}

inline void tasker_o::port(int p)  {
    Port = p;
}


#endif

/******************************************************************************/
