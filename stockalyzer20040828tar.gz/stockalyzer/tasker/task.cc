/**  task.cc  ******************************************************************


    This object tracks a task as it procedes through the job
        regement of the tasker_o process.

when      who   what
07.14.04  Dan   Creation.
08.04.04  Dan   Added.  Method clearHistdata.


Debug Level:  5650-5659

*******************************************************************************/

#include "task.h"

task_o::task_o()  {
    State         = TASKOBJECT_STATE_CLEAR;
    Step          = 0;
    Id            = -1;
    Action        = TASKOBJECT_ACTION_CLEAR;
    Symboldata    = 0;
    HistdataLast  = 0;
    AnaldataLast  = 0;
}

task_o::~task_o()  {}

void task_o::clearHistdata()  {
    histdata_o* hd;
    hd = Histdata.get();
    while(hd)  {
        delete hd;
        hd = Histdata.get();
    }
}


void task_o::operator >> (string_o& s)  {
    s << " task_o:";
    s << Id;
    s << " " << Step;
    s << " " << State;
    s << " " << Action;
    s << " " << Message;
    s << " " << (Symboldata == 0);
    s << " " << (HistdataLast == 0);
    s << " " << (AnaldataLast == 0);
}



/******************************************************************************/
