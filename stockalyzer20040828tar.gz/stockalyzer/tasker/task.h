/**  task.h  *******************************************************************


    This object tracks a task as it procedes through the job
        regement of the tasker_o process.

when      who   what
07.14.04  Dan   Creation.
08.04.04  Dan   Added.  Method clearHistdata.


Debug Level:  5650-5659

*******************************************************************************/


#ifndef TASKOBJECT_H
#define TASKOBJECT_H

#include "string/string.h"
#include "symboldata.h"
#include "histdata.h"
#include "analdata.h"

#define TASKOBJECT_STATE_CLEAR              0
#define TASKOBJECT_STATE_MISSING_SYMBOLDATA 254
#define TASKOBJECT_STATE_VOID               255

#define TASKOBJECT_ACTION_CLEAR             0
#define TASKOBJECT_ACTION_UPDATE_DAILY      1
#define TASKOBJECT_ACTION_UPDATE_HISTORY    2
#define TASKOBJECT_ACTION_ANALYSIS_SHORT    17
#define TASKOBJECT_ACTION_ANALYSIS_LONG     18
#define TASKOBJECT_ACTION_VOID              255

class task_o  {
  friend class tasker_o;
  friend class taskerupdate_o;
  private:
    short int     State;
    short int     Action;
    int           Step;
    int           Id;
    string_o      Message;
    symboldata_o* Symboldata;
    histdata_o*   HistdataLast;
    analdata_o*   AnaldataLast;
    list_o<histdata_o> Histdata;
    list_o<analdata_o> Analdata;

  public:
    task_o();
    task_o(const task_o&);
   ~task_o();
    task_o& operator = (const task_o&);

    void operator >> (string_o&);

    int step() const;
    int id() const;
    const char* message() const;
    const char* symbol() const;

    void id(int);
    void message(const char*);
    void incrementStep();
    void clearHistdata();
};

/******************************************************************************/

inline int task_o::step() const  {
    return Step;
}

inline int task_o::id() const  {
    return Id;
}

inline const char* task_o::message() const  {
    return Message.string();
}

inline const char* task_o::symbol() const  {
    if(Symboldata)  return Symboldata->symbol();
    return NULL;
}


inline void task_o::incrementStep()  {
    Step = Step + 1;
}

inline void task_o::id(int id)  {
    Id = id;
}

inline void task_o::message(const char* m)  {
    Message << m;
}


#endif

/******************************************************************************/
