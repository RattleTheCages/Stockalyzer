/**  taskerupdate.h  ***********************************************************

    The taskerupdate_o object preforms the procedures to update, to the most
        current status as possable, a given task/symbol.

when      who   what
04.14.04  Dan   Creation.    This stuff was originally in tasker_o.
07.26.04  Dan   Abstracted update into its own object.


Debug Level: 5600-5649

*******************************************************************************/


#include <unistd.h>

#include "other/sysinfo.h"
#include "log/log.h"
#include "../sserver/telenet/client.h"
#include "../datagather/dataparser.h"
#include "histdata.h"
#include "datastore.h"

#include "taskerupdate.h"


extern log_o logg;
extern sysinfo_o sysinfo;
extern tasker_o* tasker;



taskerupdate_o::taskerupdate_o()  {
    Marketdates.load();

    State = TASKERUPDATEOBJECT_STATE_OK;

    SymbolDataServer = "2.2.2.66";
    SymbolDataPort = 9000;
}

taskerupdate_o::~taskerupdate_o()  {}


int taskerupdate_o::requestSymboldataClient(symboldata_o* sd)  {
    string_o  message;
    string_o  string;
    string_o  string2;
    client_o  client;
    datarequest_o datarequest;
    dataparser_o* dataparser;


    if(!sd)  {
        State = TASKERUPDATEOBJECT_STATE_NULL_PASSED;
        return State;
    }

    if(::logg.debug(5540))  {
        (message = "taskerupdate_o: ") << "requestSymboldataClient(";
        message << sd->symbol() << ").";
        ::logg << message;
    }

    client.connect(SymbolDataServer.string(),SymbolDataPort);

    datarequest.request(sd->symbol());
    datarequest.type("symbol");
    string = "";
    datarequest >> string;
    client.send(string);

    string = "";
    while(!string.contains(DATAREQUESTOBJECT_TRAILER))  {
        string2 = "";
        client.recv(string2);
        string << string2;
    }
    datarequest << string.string();

    dataparser = new dataparser_o;
    sd->voidp((void*)dataparser);

    dataparser->parsestring(string.string());

    return State;
}


int taskerupdate_o::requestHistdataClient(symboldata_o* sd)  {
    int      x;
    string_o message;
    string_o string;
    string_o string2;
    client_o client;
    datarequest_o datarequest;
    dataparser_o* dataparser;

    if(!sd)  {
        State = TASKERUPDATEOBJECT_STATE_NULL_PASSED;
        return State;
    }

    if(::logg.debug(5540))  {
        (message = "taskerupdate_o: ") << "requestHistdataClient(";
        message << sd->symbol() << ").";
        ::logg << message;
    }

    client.connect(SymbolDataServer.string(),SymbolDataPort);

    if(client.error() != ERROR_OK)  {
        State = TASKERUPDATEOBJECT_STATE_SOCKET_PROBLEM;
        return State;
    }

    datarequest.request(sd->symbol());
    datarequest.type("daily");
    string = "";
    datarequest >> string;
    client.send(string);

    string = "";
    while(!string.contains(DATAREQUESTOBJECT_TRAILER))  {
        string2 = "";
        client.recv(string2);
        string << string2;
    }
    datarequest << string.string();

    dataparser = new dataparser_o;
    sd->voidp((void*)dataparser);

    dataparser->parsestring(string.string());

    return State;
}


/*
int taskerupdate_o::updatedata(task_o* task)  {
    string_o      message;
    string_o      s;
    int           ret = 0;
    int           loadHistdata = 0;
    int           daysBehind;
    datastore_o   datastore;
    histdata_o    hd;
    marketdate_o* md;
    symboldata_o* sd;

    if(!task || !task->Symboldata)  {
        State = TASKERUPDATEOBJECT_STATE_NULL_PASSED;
        return State;
    }

    sd = task->Symboldata;


    if(::logg.debug(5511))  {
        (message = "taskerupdate_o: ") << "updatedata(";
        message << sd->symbol() << ")";
        ::logg << message;
    }

    if(::logg.debug(5512))  {
        (message = "taskerupdate_o: ") << "updatedata(";
        message << sd->symbol() << "): Check for histdata_o.";
        ::logg << message;
    }

    (s = "") << sd->symbol() << ".histdata_o";
    ret = datastore.loadHistdata(s.string(),&hd);

    if(::logg.debug(5513))  {
        (message = "taskerupdate_o: ") << "loadHistdata returned " << ret;
        ::logg << message;
    }

    if(ret != DATASTOREOBJECT_STATE_LOADED_HISTDATA)  {
        loadHistdata = 1;
    }

    if(ret == DATASTOREOBJECT_STATE_LOADED_HISTDATA &&
       hd.date() == getDate(0))  {
        (message = "taskerupdate_o: ") << "Histdata has current date.";
        ::logg << message;

        sd->voidp((void*)&hd);

        return ret;
    }

    if(ret == DATASTOREOBJECT_STATE_LOADED_HISTDATA)  {

        if(::logg.debug(5514))  {
            (message = "taskerupdate_o: ") << "Histdata last date is: " << hd.date();
            ::logg << message;
        }


        md = Marketdates.find(hd.date());
        if(!md)  {
            (message = "taskerupdate_o: ") << "Histdata has invalid marketdate.";
            ::logg << message;

            loadHistdata = 1;
        }
        else  {
            if(::logg.debug(5514))  {
                (message = "taskerupdate_o: ") << "Marketdate is: ";
                s = "";
                *md >> s;
                message << s;
                ::logg << message;
            }

            sd->voidp((void*)&hd);
            daysBehind = howManyDaysBehind(sd);

            if(::logg.debug(5514))  {
                (message = "taskerupdate_o: ");
                message << "howManyDaysBehind() reports histdata_o is:";
                message << daysBehind << '.';
                ::logg << message;
            }

            if(daysBehind == 0)  {
                return State;
            }

            if(daysBehind == 1)  {
                ret = updateOneDay(task);
            }
            else  {
                loadHistdata = 1;
            }

        }
    }

    if(loadHistdata)  {
        if(::logg.debug(5515))  {
            (message = "tasker_o: ") << "Requesting histdata_o.";
            ::logg << message;
        }
        ret = updateHistory(task);
    }

    return ret;
}
*/


int taskerupdate_o::updateToday(task_o* task)  {
    int      ret;
    string_o message;
    dataparser_o* dataparser;
    symboldata_o* sd;

    if(!task || !task->Symboldata)  {
        State = TASKERUPDATEOBJECT_STATE_NULL_PASSED;
        return State;
    }

    sd = task->Symboldata;

    if(::logg.debug(5515))  {
        (message = "tasker_o: ") << "updateOneDay(";
        message << sd->symbol() << ')';
        ::logg << message;
    }

    ret = requestSymboldataClient(sd);

    dataparser = (dataparser_o*)sd->voidp();

    if(dataparser)  {
        if(::logg.debug(5514))  {
            (message = "tasker_o: ") << "Saving updated ";
            message << sd->symbol() << " symboldata_o.";
            ::logg << message;
        }

        dataparser->parseSymbol(sd);
        dataparser->saveSymbolToFile(sd);
    }

    //if(sysinfo.currentHour() < 16 && sysinfo.currentMinute() < 30) {
    //    if(::logg.debug(5514))  {
    //        (message = "tasker_o: ");
    //        message << "Histdata is one day behind, but time of ";
    //        message << "day is during market hours. ";
    //        message << "So not updating histdata_o.";
    //        ::logg << message;
    //    }
    //}
    //else  {
        dataparser->symbol(sd->symbol());
        ret = dataparser->loadFromFile();

        if(::logg.debug(5516))  {
            (message = "tasker_o: ") << "loadFromFile " << ret;
            ::logg << message;
        }

        dataparser->mergeWithSymboldata(sd);
        dataparser->saveToFile();
        dataparser->copyHistdataList(&task->Histdata);
    //}

    return State;
}

int taskerupdate_o::updateHistory(task_o* task)  {
    int      ret;
    string_o message;
    dataparser_o* dataparser;

    if(!task || !task->Symboldata)  {
        State = TASKERUPDATEOBJECT_STATE_NULL_PASSED;
        return State;
    }

    if(::logg.debug(5515))  {
        (message = "taskerupdate_o: ") << "updateHistory(";
        message << task->Symboldata->symbol() << ')';
        ::logg << message;
    }


    ret = requestHistdataClient(task->Symboldata);
    if(ret == TASKERUPDATEOBJECT_STATE_OK)  {

        dataparser = (dataparser_o*)task->Symboldata->voidp();

        ret = dataparser->parseStringTest();
        if(ret)  {
            dataparser->parse();
            dataparser->symbol(task->Symboldata->symbol());
            ret = dataparser->loadFromFile();

            if(::logg.debug(5516))  {
                (message = "taskerupdate_o: ") << "loadFromFile " << ret;
                ::logg << message;
            }

            dataparser->merge();
            dataparser->saveToFile();
            task->clearHistdata();
            dataparser->copyHistdataList(&task->Histdata);
            task->HistdataLast = task->Histdata.first();

            if(::logg.debug(5516))  {
                (message = "taskerupdate_o: ") << "task->HistdataLast:" << task->HistdataLast->date();
                ::logg << message;
            }

        }
    }

    return State;
}


/*
int taskerupdate_o::getDate(int o)  {
    string_o message;
    int x;
    int trys = 0;
    int today;
    int day;
    int cday;
    int cmonth;
    string_o s;
    marketdate_o* md;

    cmonth = sysinfo.currentMonth()+1;
    cday = sysinfo.currentDay();

    (s = "") << sysinfo.currentYear();
    if(cmonth < 10)  s << '0';
    s << cmonth;
    if(cday <  10)  s << '0';
    s << cday;
    today = s.stoi();
    Date = s.stoi();

    trys = 0;
    for(x=0;x<o;x++)  {
        md = 0;
        while(!md && trys++ < 14)  {
            cday = cday -1; //!!!!!!$$$$*** what day is this?
            if(cday < 1)  {
                cday = 31;
                cmonth = cmonth -1;
            }

            (s = "") << sysinfo.currentYear();
            if(cmonth < 10)  s << '0';
            s << cmonth;
            if(cday <  10)  s << '0';
            s << cday;
            day = s.stoi();

            if(::logg.debug(5529))  {
                (message = "tasker_o: ") << "Checking date:";
                message << day << ".";
                ::logg << message;
            }

            md = Marketdates.find(day);
        }

        if(md)  {
            if(::logg.debug(5529))  {
                (message = "tasker_o: ") << "marketdate_o:";
                message << md->date() << ".";
                ::logg << message;
            }

            Date = day;
        }
    }

    return Date;
}

int taskerupdate_o::howManyDaysBehind(const symboldata_o* symbol)  {
    int x;
    int date;
    string_o message;
    string_o s;

    if(::logg.debug(5520))  {
        (message = "tasker_o: ") << "howManyDaysBehind(";
        message << symbol->symbol() << ").";
        ::logg << message;
    }

    x = 0;
    while(x < 12)  {
        date = getDate(x);
        if(((histdata_o*)symbol->voidp())->date() == date)  {
            if(::logg.debug(5521))  {
                (message = "tasker_o: ") << "getDate(" << x;
                message << ") " << date << " == histdata_o->date ";
                message << ((histdata_o*)symbol->voidp())->date();
                ::logg << message;
            }

            return x;
        }

        x++;
    }

    return -1;
}
*/


/******************************************************************************/
