/**  scanfilter.cc  *************************************************************


changes log
when      who   what
04.22.04  Dan   Creation.
06.11.04  Dan   Added.    Functions rule, test.

Debug Level: 4700-4719
*******************************************************************************/


#include "log/log.h"
#include "scanfilter.h"

extern log_o logg;

rule_o::rule_o()  {
    Yesterday = 0;
}

rule_o::~rule_o()  {}

rule_o::rule_o(const rule_o& r)  {
    Left = r.Left;
    Op = r.Op;
    Right = r.Right;
    Yesterday = r.Yesterday;
}

void rule_o::rule(const char* left,const char* op,const char* right,int yesterday = 0)  {
    string_o message;
    if(!left || !op || !right)  {
        (message = "rule_o: ") << "Null passed.";
        ::logg.error(message);
        return;
    }

    Left  = left;
    Op    = op;
    Right = right;
    Yesterday = yesterday;
}

void scanfilter_o::description(const char* d)  {
    string_o s;

    if(d)  {
        s = d;
        s.transpose(" ","_");
        Description = s;
    }
}

void rule_o::operator >> (string_o& s)  {
    s << " rule_o:";
    s << Left << " " << Op << " "<< Right << " " << Yesterday;
}

void rule_o::operator << (const char* o)  {
    string_o s;
    string_o t;
    s = o;

    s.upcut(" rule_o:");
    t = s;

    t.cut(' ');
    Left = t.string();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Op = t.string();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Right = t.string();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Yesterday = t.stoi();
}


scanfilter_o::scanfilter_o()  {
    Level = 0;
    Direction = 'L';
    Id = "Id";
    Description = "scanfilter";
}

scanfilter_o::~scanfilter_o()  {}
//scanfilter_o::scanfilter_o(const scanfilter_o& sf)  {}


int scanfilter_o::rule(rule_o* rule)  {
    string_o  message;
    rule_o*   r;
    if(!rule)  {
        (message = "scanfilter_o: ") << "Null passed.";
        ::logg.error(message);
        return -1;
    }

    r = new rule_o(*rule);
    Rules.put(r);


    if(::logg.debug(4711))  {
        (message = "scanfilter_o: ") << "Added rule: " << rule->Left;
        message << rule->Op << rule->Right;
        ::logg << message;
    }

    return 0;
}

/*
int scanfilter_o::test(analdata_o* ad)  {
    int       pass = 0;
    string_o  message;
    rule_o*   rule;

    if(!ad)  {
        (message = "scanfilter_o: ") << "test(): Null passed.";
        ::logg.error(message);
        return -1;
    }

    rule = Rules.first();
    while(rule)  {
        pass = test2(ad,ad,rule);
        if(!pass)  break;

        rule = Rules.next();
    }

    return pass;
}
*/

int scanfilter_o::test(analdata_o* adleft,analdata_o* adright)  {
    int       pass = 0;
    string_o  message;
    rule_o*   rule;

    if(!adleft || !adright)  {
        (message = "scanfilter_o: ") << "test(): Null passed.";
        ::logg.error(message);
        return -1;
    }

    rule = Rules.first();
    while(rule)  {
        if(rule->yesterday())  pass = test2(adleft,adright,rule);
        else  pass = test2(adleft,adleft,rule);
        if(!pass)  break;

        rule = Rules.next();
    }

    return pass;
}

int scanfilter_o::test2(analdata_o* adleft,analdata_o* adright,rule_o* rule)  {
    string_o message;
    int      left;
    int      right;

    if(!adleft || !adright || !rule)  {
        (message = "scanfilter_o: ") << "test2(): Null passed.";
        ::logg.error(message);
        return -1;
    }

    left = decode(adleft,&rule->Left);
    right = decode(adright,&rule->Right);

    if(::logg.debug(4701))  {
        (message = "scanfilter_o: ") << "Testing rule: ";
        message << rule->Left << rule->Op << rule->Right << " : ";
    }

    if(rule->Op == "<")  {
        if(::logg.debug(4701))  {
            message << left << "<" << right;
            ::logg << message;
        }

        return (left < right);
    }
    if(rule->Op == ">")  {
        if(::logg.debug(4701))  {
            message << left << ">" << right;
            ::logg << message;
        }

        return (left > right);
    }

    return 0;
}

int scanfilter_o::decode(analdata_o* ad,string_o* code)  {
    string_o message;
    string_o s;
    string_o t;
    int      value = 0;
    float    multipier = 1;

    if(!ad || !code)  {
        (message = "scanfilter_o: ") << "decode(): Null passed.";
        ::logg.error(message);
        return -1;
    }

    s = *code;

    if(s.contains("*"))  {
        t = s;
        t.upcut("*");
        multipier = t.stoi();

        if(t.contains("."))  {
            t.upcut(".");
            t.cut(3);
            if(t.length() == 1)  multipier = multipier + ((float)t.stoi()/10);
            if(t.length() == 2)  multipier = multipier + ((float)t.stoi()/100);
            if(t.length() == 3)  multipier = multipier + ((float)t.stoi()/1000);
        }
        s.cut("*");
        s.cut(s.length()-1);
    }

    if(s == "0")  value = 0;
    if(s == "1")  value = 1;
    if(s == "2")  value = 2;
    if(s == "3")  value = 3;

    if(s == "close")  value = ad->close();
    if(s == "volume")  value = ad->volume();
    if(s == "vma200")  value = ad->vma200();
    if(s == "vma50")  value = ad->vma50();
    if(s == "macd1226")  value = ad->macd1226();
    if(s == "macd1226ema9")  value = ad->macd1226ema9();
    if(s == "ma50")  value = ad->ma50();
    if(s == "ma200")  value = ad->ma200();
    if(s == "ema9")  value = ad->ema9();
    if(s == "ema12")  value = ad->ema12();
    if(s == "ema26")  value = ad->ema26();
    if(s == "ema33")  value = ad->ema33();
    if(s == "dsupport")  value = ad->dsupport();



    value = (int)((float)value * multipier);

    return value;
}


void scanfilter_o::operator >> (string_o& s)  {
    rule_o* rule;
    s << " scanfilter_o:" << Level << " " << Direction << " " << Id;
    s << " " << Description << " " << Rules.cardinality();

    rule = Rules.first();
    while(rule)  {
        *rule >> s;
        rule = Rules.next();
    }
}

void scanfilter_o::operator << (const char* o)  {
    int x;
    int y;
    int z;
    string_o s;
    string_o t;
    rule_o* rule;
    s = o;

    s.upcut(" scanfilter_o:");
    t = s;
    t.cut(' ');
    Level = t.stoi();
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Direction = t.charat(0);
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Id = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    Description = t;
    s.upcut(' ');
    t = s;
    t.cut(' ');
    x = t.stoi();

    t = s;
    z = t.upcut(' ');
    s.upcut(z-1);
    for(y=0;y<x;y++)  {
        t = s;
        rule = new rule_o;
        *rule << t.string();
        Rules.put(rule);
        s.upcut(" rule_o:");
        t = s;
        z = t.upcut(" rule_o:");

        s.upcut(z-8);
    }
}


/******************************************************************************/
