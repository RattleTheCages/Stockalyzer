/**  stockscan.cc  **************************************************************


changes log
when      who   what
04.12.04  Dan   Creation.
04.16.04  Dan   Added.  findSymbols() and using new symboldata_o object.
04.24.04  Dan   Added.  Use of new symbols_o object.
06.11.04  Dan   Changed.  To use the scanfilter_o object.  Included adding
                          functions and changing procedures.
06.12.04        Added.    Loading of scanfilters, like symboldata_o does.
08.28.04  Dan   Changed.  Using new (to this object) datastore_o object.


Debug Level: 4600-4699
*******************************************************************************/

#include <fstream.h>

#include "symboldata.h"
#include "stockscan.h"

#include "datastore.h"


sysinfo_o sysinfo;
log_o logg;
stockscan_o stockscan;
datastore_o datastore;


stockscan_o::stockscan_o()  {
    State = STOCKSCANOBJECT_STATE_CLEAR;
}

stockscan_o::~stockscan_o()  {}


int stockscan_o::loadAnaldata(symboldata_o* symb)  {
    int x;
    string_o message;
    analdata_o* ad;
    trenddata_o* td;

    list_o<analdata_o>* adl;
    list_o<trenddata_o>* adlT;

    if(!symb)  {
        State = STOCKSCANOBJECT_STATE_VOID;
        return State;
    }

    if(::logg.debug(4621))  {
        (message = "stockscan_o: ")  << "loadAnaldata(" << symb->symbol() << ") Start.";
        ::logg << message;
    }


    adl = new list_o<analdata_o>;
    ::datastore.loadAnaldata(*symb,adl);

/*
ad = adl->first();
ad = adl->next();
ad = adl->next();
ad = adl->next();
ad = adl->next();
while(ad)  {
delete ad;
ad = adl->next();
}
*/


    if(::logg.debug(4622))  {
        (message = "stockscan_o: ")  << "Analdata for symbol \"" << symb->symbol() << "\" loaded ";
        message << adl->cardinality() << " dates.";
        ::logg << message;

        ad = adl->first();
        (message = "stockscan_o: ")  << "Latest analdata_o: date:" << ad->date();
        message << " close:" << ad->close() << " MA200:" << ad->ma200();
        message << " VMA200:" << ad->vma200();
        ::logg << message;
    }


    AnaldataTree.insert(symb->symbol(),adl);
    State = STOCKSCANOBJECT_STATE_ANALDATA_LOADED;


    adlT = new list_o<trenddata_o>;
    ::datastore.loadTrenddata(*symb,adlT);


    TrenddataTree.insert(symb->symbol(),adlT);
    State = STOCKSCANOBJECT_STATE_ANALDATA_LOADED;

    return State;
}


int stockscan_o::loadScanfilters()  {
    string_o message;
    string_o s;
    string_o Dirname;
    string_o syscall;
    string_o* scanfilterId;
    char buff[32767];
    ifstream in;
    list_o<string_o> scanfilterIdList;

    if(Dirname.length() < 1)  {
        Dirname = "./filters";
    }

    if(::logg.debug(4671))  {
        (message = "stockscan_o: ")  << "loadScanfilters().  Look in directory `";
        message << Dirname << "' to find scanfilters.";
        ::logg << message;
    }

    (syscall = "") << "ls " << Dirname << " > /tmp/scanfilter_o.tmp";
    system(syscall.string());
    in.open("/tmp/scanfilter_o.tmp");
    while(in)  {
        in >> buff;
        if(in.eof())  break;

        (s = "") << buff;
        s.cut('.');

        scanfilterId = new string_o(s);
        scanfilterIdList.put(scanfilterId);
    }
    in.close();
    system("rm -f /tmp/scanfilter_o.tmp");


    if(::logg.debug(4672))  {
        (message = "stockscan_o: ") << "Number of scanfilters in directory: ";
        message << scanfilterIdList.cardinality();
        ::logg << message;
    }


    scanfilterId = scanfilterIdList.get();
    while(scanfilterId)  {
        if(::logg.debug(4673))  {
            (message = "stockscan_o: ") << "Loading scanfilter_o: " << scanfilterId;
            ::logg << message;
        }

        (s = "") << Dirname << "/" << scanfilterId << ".scanfilter_o";

        loadScanfilter(s.string());

        delete scanfilterId;
        scanfilterId = scanfilterIdList.get();
    }


scanfilter_o* scanfilter;
scanfilter = new scanfilter_o;
*scanfilter << "5 L TrendTest TrendTest 0" ;
Scanfilters.put(scanfilter);
ScanfilterTree.insert("TrendTest",scanfilter);


    return 0;
}

int stockscan_o::loadScanfilter(const char* filename)  {
    string_o message;
    string_o s;
    ifstream in;
    char buff[32767];
    scanfilter_o* scanfilter;

    in.open(filename);
    if(!in)  {
        (message = "stockscan_o: ") << "Unable to open scanfilter_o file:" << s;
        ::logg.error(message);
    }
    else  {
        (s = "");
        while(!in.eof())  {
            in.getline(buff,sizeof(buff)-1,'\n');
            if(in.eof())  break;
            s << buff;
        }
        in.close();

        scanfilter = new scanfilter_o;
        *scanfilter << s.string();

        Scanfilters.put(scanfilter);
        ScanfilterTree.insert(scanfilter->id(),scanfilter);

        return 1;
    }

    return 0;
}


int stockscan_o::scan(scanfilter_o* scanfilter)  {
    string_o      message;
    string_o      s;
    string_o*     passed;
    symboldata_o* symbol;
    symbols_o     flaggedSymbols;
    trenddata_o*  td;
    analdata_o*   ad;
    analdata_o*   adToday;
    analdata_o*   adYesterday;
    bstreeSearch_o<list_o<analdata_o> >* analSearch;
    list_o<analdata_o>* adl;
    bstreeSearch_o<list_o<trenddata_o> >* trendSearch;
    list_o<trenddata_o>* tdl;



    if(::logg.debug(4681))  {
        (message = "stockscan_o: ") << "scan() Start.";
        ::logg << message;
    }

    if(!scanfilter)  {
        (message = "stockscan_o: ") << "scan() Null passed.";
        ::logg.error(message);

        State = STOCKSCANOBJECT_STATE_VOID;
        return State;
    }


    analSearch = new bstreeSearch_o<list_o<analdata_o> >(&AnaldataTree);
    trendSearch = new bstreeSearch_o<list_o<trenddata_o> >(&TrenddataTree);


    symbol = Symbols.first();
    while(symbol)  {

        if(::logg.debug(4685))  {
            (message = "stockscan_o: ") << "Testing symbol: " << symbol->symbol();
            ::logg << message;
        }


        s = symbol->symbol();
        adl = (list_o<analdata_o>*)analSearch->find(&s);
        ad = adl->first();
        adToday = ad;
        ad = adl->next();
        adYesterday = ad;

        if(::logg.debug(4686))  {
            (message = "stockscan_o: ") << "Looking at: " << adToday->date();
            message << "  close: " << adToday->close();
            ::logg << message;
        }

        if(scanfilter->test(adToday,adYesterday))  {
            if(::logg.debug(4688))  {
                (message = "stockscan_o: ") << "Symbol: " << symbol->symbol();
                message << " passed scanfilter: " << scanfilter->id();
                ::logg << message;
            }

            passed = new string_o;

            *passed << symbol->symbol() << ':' << scanfilter->id();
            Passed.insert(passed,passed);
        }

        symbol = Symbols.next();
    }

    delete analSearch;
    delete trendSearch;


    return State;
}


int stockscan_o::trendTest(symboldata_o* symbol)  {
    string_o      message;
    string_o      s;
    string_o*     passed;
    symbols_o     flaggedSymbols;
    trenddata_o*  td;
    analdata_o*   ad;
    analdata_o*   adToday;
    bstreeSearch_o<list_o<analdata_o> >* analSearch;
    list_o<analdata_o>* adl;
    bstreeSearch_o<list_o<trenddata_o> >* trendSearch;
    list_o<trenddata_o>* tdl;



    if(::logg.debug(4687))  {
        (message = "stockscan_o: ") << "trendTest(" << symbol->symbol() << ") Start.";
        ::logg << message;
    }


    analSearch = new bstreeSearch_o<list_o<analdata_o> >(&AnaldataTree);
    trendSearch = new bstreeSearch_o<list_o<trenddata_o> >(&TrenddataTree);


    s = symbol->symbol();
    tdl = (list_o<trenddata_o>*)trendSearch->find(&s);
    adl = (list_o<analdata_o>*)analSearch->find(&s);
    ad = adl->first();
    adToday = ad;

    td = tdl->first();
    while(td)  {

        if(td->tomorrowY())  {

            if(::logg.debug(4687))  {
                (message = "stockscan_o: ") << "Looking at for trend: " << adToday->date();
                message << "  close: " << adToday->close() << "  tomorrowY:" << td->tomorrowY();
                message << "  close: " << (float)adToday->close()*0.999 << ":" << (float)adToday->close()*1.001;
                ::logg << message;
            }

            if((float)adToday->close()*0.999 < td->tomorrowY() && (float)adToday->close()*1.001 > td->tomorrowY())  {

                if(::logg.debug(4687))  {
                    (message = "stockscan_o: ") << "Passed! at for trend: " << adToday->date();
                    message << "  close: " << adToday->close() << "  tomorrowY:" << td->tomorrowY();
                    ::logg << message;
                }

                passed = new string_o;

                *passed << symbol->symbol() << ':' << "TrendTest";
                Passed.insert(passed,passed);

                break;
            }
        td = tdl->next();
        }
    }


    delete analSearch;
    delete trendSearch;

    return State;
}


int stockscan_o::loadSymbols()  {
    int           ret;
    string_o      message;
    symbols_o     flaggedSymbols;
    analdata_o*   ad;

    if(::logg.debug(4611))  {
        (message = "stockscan_o: ") << "loadSymbols() Start.";
        ::logg << message;
    }

    ret = Symbols.directory();
    ret = Symbols.merge();
    if(::logg.debug(4612))  {
        (message = "stockscan_o: ") << Symbols.cardinality() << " symbols loaded.";
        ::logg << message;
    }
    if(Symbols.cardinality() == 0)  {
        State = STOCKSCANOBJECT_STATE_VOID;
    }
    else  {
        State = STOCKSCANOBJECT_STATE_SYMBOLS_LOADED;
    }

    return State;
}


int stockscan_o::execute()  {
    string_o      message;
    string_o      s;
    string_o*     passed;
    symboldata_o* symbol;
    scanfilter_o* scanfilter;
    rule_o        rule;
    bstreeSearch_o<string_o> passedSearch(&Passed);
    bstreeSearch_o<scanfilter_o> scanfilterTreeSearch(&ScanfilterTree);

    if(::logg.debug(4601))  {
        (message = "stockscan_o: ") << "execute() Start.";
        ::logg << message;
    }

    ::datastore.directory("./livedata");

    loadScanfilters();


    loadSymbols();
    if(State != STOCKSCANOBJECT_STATE_SYMBOLS_LOADED)  {
        (message = "stockscan_o: ") << "Symbol load failed.";
        ::logg.error(message);
        return State;
    }


    symbol = Symbols.first();
    while(symbol)  {

        if(::logg.debug(4602))  {
            (message = "stockscan_o: ") << "Loading analdata for symbol: " << symbol->symbol();
            ::logg << message;
        }

        State = STOCKSCANOBJECT_STATE_CLEAR;
        stockscan.loadAnaldata(symbol);
        if(State != STOCKSCANOBJECT_STATE_ANALDATA_LOADED)  {
            (message = "stockscan_o: ") << "Analdata load failed for symbol: " << symbol->symbol();
            ::logg.error(message);
        }

        symbol = Symbols.next();
    }


    if(::logg.debug(4608))  {
        (message = "stockscan_o: ") << "Starting scanfilter_o loop.";
        ::logg << message;
    }

    scanfilter = Scanfilters.first();
    while(scanfilter)  {
        if(::logg.debug(4609))  {
            (message = "stockscan_o: ") << "Scanning filter: " << scanfilter->id();
            ::logg << message;
        }

        scan(scanfilter);

        scanfilter = Scanfilters.next();
    }


    symbol = Symbols.first();
    while(symbol)  {

        trendTest(symbol);

        symbol = Symbols.next();
    }


    Passed.sort();
    passed = (string_o*)passedSearch.first();
    while(passed)  {
        s = passed;
        s.upcut(":");

        scanfilter = (scanfilter_o*)scanfilterTreeSearch.find(&s);

        s = passed;
        s.cut(":");
        s.cut(s.length()-1);
        s.justifyRight(5);
        if(::logg.debug(4600))  {
            (message = "stockscan_o: ") << scanfilter->level() << " ";
            if(scanfilter->direction() == 'L')  message << "long  ";
            else  message << "short ";
            message << s << " " << scanfilter->description();
            ::logg << message;
        }

        passed = (string_o*)passedSearch.next();
    }

    return State;
}


int main(int argc,char* argv[])  {
    int       ret;
    int       x;


    ::logg.setDebugLevel(4600);  //stockscan_o::execute() results.
    ::logg.setDebugLevel(4601);  //stockscan_o::execute().
    ::logg.setDebugLevel(4602);
    ::logg.setDebugLevel(4608);
    ::logg.setDebugLevel(4609);

    ::logg.setDebugLevel(4611);  //stockscan_o::loadSymbols().
    ::logg.setDebugLevel(4612);

    ::logg.setDebugLevel(4621);  //stockscan_o::loadAnaldata().
    ::logg.setDebugLevel(4622);
//  for(x=4690;x<=4699;x++)  ::logg.setDebugLevel(x);  //datastore_o.

//  ::logg.setDebugLevel(4681);  //stockscan_o::scan().
    ::logg.setDebugLevel(4685);  //stockscan_o::scan() Symbol.
    ::logg.setDebugLevel(4686);
//  ::logg.setDebugLevel(4687);  //stockscan_o::scan() Testing trend.
    ::logg.setDebugLevel(4688);

    ::logg.setDebugLevel(4671);  //loading scanfilter_o.
    ::logg.setDebugLevel(4672);  //loading scanfilter_o.
    ::logg.setDebugLevel(4673);  //loading scanfilter_o.


    ::logg.setDebugLevel(4701);  //scanfilter_o::testing rule.
    ::logg.setDebugLevel(4711);  //scanfilter_o::added rule.


    ret = stockscan.execute();

    return ret;
}



/******************************************************************************/
