/**  scanfilter.h  *************************************************************


when      who   what
04.22.04  Dan   Creation.
06.11.04  Dan   Added.    Functions rule, test.  New object rule_o.

Debug Level: 4700-4749
*******************************************************************************/


#ifndef SCANFILTEROBJECT_H
#define SCANFILTEROBJECT_H

#include "string/string.h"
#include "memory/list.h"
#include "analdata.h"


class rule_o  {
  friend class scanfilter_o;
  private:
    string_o Left;
    string_o Op;
    string_o Right;
    int      Yesterday;

  public:
    rule_o();
    rule_o(const rule_o&);
   ~rule_o();
    rule_o& operator = (const rule_o&);


    int yesterday() const;

    void rule(const char*,const char*,const char*,int);

    void operator << (const char*);
    void operator >> (string_o&);
};


class scanfilter_o  {
  private:
    int      Level;
    char     Direction;
    string_o Id;
    string_o Description;

    list_o<rule_o> Rules;

    int decode(analdata_o*,string_o*);
    int test2(analdata_o*,analdata_o*,rule_o*);

  public:
    scanfilter_o();
    scanfilter_o(const scanfilter_o&);
   ~scanfilter_o();
    scanfilter_o& operator = (const scanfilter_o&);


    int rule(rule_o*);
//  int test(analdata_o*);
    int test(analdata_o*,analdata_o*);

    int         level() const;
    const char* id() const;
    const char* description() const;
    char        direction() const;
    void id(const char*);
    void description(const char*);
    void direction(char);

    void operator << (const char*);
    void operator >> (string_o&);
};

/******************************************************************************/

inline int rule_o::yesterday()  const  {
    return Yesterday;
}

inline int scanfilter_o::level() const  {
    return Level;
}

inline const char* scanfilter_o::id() const  {
    return Id.string();
}

inline const char* scanfilter_o::description() const  {
    return Description.string();
}

inline char scanfilter_o::direction() const  {
    return Direction;
}


#endif

/******************************************************************************/
