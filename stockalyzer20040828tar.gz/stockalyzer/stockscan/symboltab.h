/**  symboltab.h  **************************************************************


when      who   what
04.24.04  Dan   Creation.



symboltab_o: Debug Level 4400-4499

*******************************************************************************/


#ifndef SYMBOLTABOBJECT_H
#define SYMBOLTABOBJECT_H

#include "string/string.h"
#include "memory/bstree.h"
#include "memory/list.h"
#include "symboldata.h"

class symboltab_o  {
  friend class stockscan_o;
  private:
    symbols_o Symbols;

  public:
    symboltab_o();
    symboltab_o(const symboltab_o&);
   ~symboltab_o();
    symboltab_o& operator = (const symboltab_o&);

    void clear();

};

/******************************************************************************/



#endif

/******************************************************************************/
