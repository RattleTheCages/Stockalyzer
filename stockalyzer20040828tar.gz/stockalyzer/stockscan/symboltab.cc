/**  symboltab.cc  *************************************************************


when      who   what
04.24.04  Dan   Creation.



symboltab_o: Debug Level 4400-4499


*******************************************************************************/


#include "symboltab.h"

symboltab_o::symboltab_o()  {}

symboltab_o_o::~symboltab_o_o()  {}

void symboltab_o_o::clear()  {}




/******************************************************************************/
