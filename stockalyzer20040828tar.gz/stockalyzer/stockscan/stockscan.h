/**  stockscan.h  ***************************************************************


when      who   what
04.12.04  Dan   Creation.
04.16.04  Dan   Added.    Use of new symboldata_o object.
04.24.04  Dan   Added.    Use of new symbols_o object.
06.11.04  Dan   Changed.  To use the scanfilter_o object.  Included adding
                          functions and changing procedures.
06.12.04        Added.    Loading of scanfilters, like symboldata_o does.
08.28.04  Dan   Changed.  Abstracted the trend testing into its own method.



*******************************************************************************/


#ifndef STOCKSCANOBJECT_H
#define STOCKSCANOBJECT_H

#ifndef NULL
#define NULL 0
#endif


#include "string/string.h"
#include "memory/list.h"
#include "memory/bstree.h"
#include "other/sysinfo.h"
#include "log/log.h"

#include "analdata.h"
#include "trenddata.h"
#include "movingavg.h"
#include "support.h"
#include "symboldata.h"
#include "scanfilter.h"


#define STOCKSCANOBJECT_STATE_CLEAR             0
#define STOCKSCANOBJECT_STATE_SYMBOLS_LOADED    1
#define STOCKSCANOBJECT_STATE_ANALDATA_LOADED   2
#define STOCKSCANOBJECT_STATE_VOID              255


class stockscan_o  {
  private:
    int      State;
    symbols_o Symbols;
    bstree_o<list_o<analdata_o> >  AnaldataTree;
    bstree_o<list_o<trenddata_o> >  TrenddataTree;
    list_o<scanfilter_o> Scanfilters;
    bstree_o<scanfilter_o> ScanfilterTree;


    bstree_o<string_o> Passed;


    int loadScanfilter(const char*);
    int loadAnaldata(symboldata_o*);

    int trendTest(symboldata_o*);

  public:
    stockscan_o();
    stockscan_o(const stockscan_o&);
   ~stockscan_o();
    stockscan_o& operator = (const stockscan_o&);

    int execute();

    int scan(scanfilter_o*);

    int loadScanfilters();
    int loadSymbols();
};

/******************************************************************************/



#endif

/******************************************************************************/
