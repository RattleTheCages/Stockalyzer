/**  stockCPU.cc  *************************************************************


changes log
when      who      what
11.21.03  Dan      Creation.  Created from the original
                   lotto objects on 5.17.98

*******************************************************************************/

#include <iostream.h>
#include <fstream.h>

#include "../../lib/log/log.h"
#include "../../lib/error/error.h"
#include "../../lib/other/rand.h"
#include "../processes/stockCPU.h"

extern log_o logg;
extern rand_o rndm;

stockCPU_o::stockCPU_o()  {
    State              = STOCKCPUOBJECT_STATE_VOID;
    Score              = 0;
    PricesPerSet       = STOCKCPUOBJECT_PRICES_PER_SET;
    NumberOfRegisters  = STOCKCPUOBJECT_NUMBER_OF_REGISTERS;
    MinPriceInclusive  = STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE;
    MaxPriceInclusive  = STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE;
    MinOffsetInclusive = STOCKCPUOBJECT_DEFAULT_MIN_OFFSET_NUMBER_INCLUSIVE;
    MaxOffsetInclusive = STOCKCPUOBJECT_DEFAULT_MAX_OFFSET_NUMBER_INCLUSIVE;

    clear();

    loadClosingPrices("./stock.dat");

    State = STOCKCPUOBJECT_STATE_READY;
}

stockCPU_o::~stockCPU_o()  {}

void stockCPU_o::clear()  {
    ChromosomeIndex = 0;
    ProgramCounter = 0;
    InstCount = 0;
    InstCountSet = 0;
    PriceIndex = 0;

    rs.clear();
    rs2.clear();
    rsPrice.clear();
    rsClosingPrice = NULL;
    rsBroad = NULL;
    rsPrediction.clear();

    for(int x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH+1;x++)  inst[x] = NULL;
    State = STOCKCPUOBJECT_STATE_CLEAR;
}


int stockCPU_o::execute(entity_o& entity)  {
    string_o           message;
    histdata_o*        hd;

    State = STOCKCPUOBJECT_STATE_EXECUTING;

    if(::logg.debug(5))  {
        (message = "") << "stockCPU_o: execute: " << entity.name();
        ::logg << message;
    }

    hd = ClosingPricesUse.get();
    while(hd)  hd = ClosingPricesUse.get();
    hd = ClosingPrices.first();
    while(hd)  {
        ClosingPricesUse.put(hd);
        hd = ClosingPrices.next();
    }


    rs.clear();
    rs2.clear();
    rs3.clear();
    rsPrice.clear();
    rsPrediction.clear();

    entity.setScore(0);
    ProgramCounter = 0;
    InstCount = 0;
    InstCountSet = 0;
    ChromosomeIndex = 0;
    rsClosingPrice = ClosingPricesUse.get();
    PriceIndex = 1;
    rsBroad = rsClosingPrice;


    while(2)  {

        (void)executeInstruction(entity);

        if(::logg.debug(5))  {
            message = "";
            message << "State: " << State << " ";
            message << "Registers:\n";
            message << "pc " << ProgramCounter;
            message << ", ci " << ChromosomeIndex;
            message << ", ic " << InstCount;
            message << ".\n";
            message << "rs";
            rs >> message;
            message << "\nrs2";
            rs2 >> message;
            message << "\nrs3";
            rs3 >> message;
            message << "\nrsPrice";
            rsPrice >> message;
            if(rsClosingPrice)  {
                message << "\nrsClosingPrice";
                (*rsClosingPrice) >> message;
            }
            if(rsBroad)  {
                message << "\nrsBroad";
                (*rsBroad) >> message;
            }
            message << "\nrsPrediction";
            rsPrediction >> message;
            message << ".";
            ::logg << message;
        }

        if(State == STOCKCPUOBJECT_STATE_FINISHED)  return State;
        if(!rsClosingPrice)  {
            (message = "") << "stockCPU_o: Error.  Was the closing prices data loaded?";
            ::logg << message;
            return State;
         }



        InstCount++;
        InstCountSet++;
        if(InstCount >= STOCKCPUOBJECT_MAX_INSTRUCTIONS_PER_RUN)  {
            if(::logg.debug(6))  {
                entity.setScore(entity.score()/10);
                State = STOCKCPUOBJECT_STATE_REACHED_MAX;
                (message = "") << "stockCPU_o: Reachd. ic:" << InstCount << " Name:" << entity.name() << " Gen:" << entity.generation() << " max instruction.";
                ::logg << message;
            }
            return State;
        }
    }

    return State;
}

int stockCPU_o::score(entity_o& entity)  {
    string_o message;
    histdata_o temphist;
    int x;
    int y;
    int score = 0;

    temphist = rsPrediction;
    rsPrediction = rsPrice;

    rsClosingPrice = ClosingPricesUse.get();
    PriceIndex++;
    rsBroad = rsClosingPrice;
    if(!rsClosingPrice)  {
        score = 119;
        if(rsPrediction.close() != 0)  score = score + 500;
        if(rsPrediction.open() != 0)  score = score + 250;
        if(rsPrediction.high() != 0)  score = score + 750;
        if(rsPrediction.low() != 0)  score = score + 1000;
        if(rsPrediction.volume() != 0)  score = score + 1;
        if(score >= 121)  score = score + PriceIndex/10;
        entity.setScore(entity.score()+score);
        if(::logg.debug(7))  {
            (message = "") << "stockCPU_o: Finish. ic:" << InstCount << " Name:" << entity.name() << " Gen:" << entity.generation() << " Score:" << entity.score() << " Prediction:";
            rsPrediction >> message;
            ::logg << message;
        }

        State = STOCKCPUOBJECT_STATE_FINISHED;
        return State;
    }

    score = 1;
    if(rsPrediction.close() == rsClosingPrice->close())  score = score + 400;
    if(rsPrediction.close() == rsClosingPrice->close()-1)  score = score + 40;
    if(rsPrediction.close() == rsClosingPrice->close()+1)  score = score + 40;
    if(rsPrediction.close() == rsClosingPrice->close()-2)  score = score + 4;
    if(rsPrediction.close() == rsClosingPrice->close()+2)  score = score + 4;
    if(rsPrediction.open() == rsClosingPrice->open())  score = score + 200;
    if(rsPrediction.open() == rsClosingPrice->open()-1)  score = score + 20;
    if(rsPrediction.open() == rsClosingPrice->open()+1)  score = score + 20;
    if(rsPrediction.open() == rsClosingPrice->open()-2)  score = score + 1;
    if(rsPrediction.open() == rsClosingPrice->open()+2)  score = score + 1;
    if(rsPrediction.high() == rsClosingPrice->high())  score = score + 750;
    if(rsPrediction.high() == rsClosingPrice->high()-1)  score = score + 75;
    if(rsPrediction.high() == rsClosingPrice->high()+1)  score = score + 75;
    if(rsPrediction.high() == rsClosingPrice->high()-2)  score = score + 7;
    if(rsPrediction.high() == rsClosingPrice->high()+2)  score = score + 7;
    if(rsPrediction.low() == rsClosingPrice->low())  score = score + 1000;
    if(rsPrediction.low() == rsClosingPrice->low()-1)  score = score + 100;
    if(rsPrediction.low() == rsClosingPrice->low()+1)  score = score + 100;
    if(rsPrediction.low() == rsClosingPrice->low()-2)  score = score + 10;
    if(rsPrediction.low() == rsClosingPrice->low()+2)  score = score + 10;
    if(rsPrediction.volume() == rsClosingPrice->volume())  score = score + 100;
    if(rsPrediction.volume() == rsClosingPrice->volume()-1)  score = score + 10;
    if(rsPrediction.volume() == rsClosingPrice->volume()+1)  score = score + 10;
    if(rsPrediction.volume() == rsClosingPrice->volume()-2)  score = score + 1;
    if(rsPrediction.volume() == rsClosingPrice->volume()+2)  score = score + 1;
    if(InstCountSet > 3600)  score = score + 5;
    if(InstCountSet > 1400)  score = score + 2;
    InstCountSet = 0;
    if(rsPrediction.low() < rsClosingPrice->high())  score = score + 3;
    if(rsPrediction.close() >= rsClosingPrice->low())  score = score + 3;
    if(rsPrediction.close() <= rsClosingPrice->high())  score = score + 3;
    if(rsPrediction.high() > rsClosingPrice->low())  score = score + 3;

    if(rsPrediction.close() == temphist.close() &&
       temphist.close() != rsClosingPrice->close())  score = score - 5;
    if(rsPrediction.open() == temphist.open() &&
       temphist.open() != rsClosingPrice->open())  score = score - 5;
    if(rsPrediction.high() == temphist.high() &&
       temphist.high() != rsClosingPrice->high())  score = score - 5;
    if(rsPrediction.low() == temphist.low() &&
       temphist.low() != rsClosingPrice->low())  score = score - 5;

    if(score > 0)  {
        if(score >= 31)  score = score + PriceIndex/10;
        entity.setScore(score + entity.score());
        if(entity.object())  delete entity.object();
        entity.setObject(new histdata_o);
        *(histdata_o*)entity.object() = rsPrediction;

        if(::logg.debug(8))  {
            (message = "") << "stockCPU_o: Scored. ic:" << InstCount << " pi:" << PriceIndex << " Name:" << entity.name() << " Gen:" << entity.generation() << " Score:" << score;
            ::logg << message;
        }
        if(::logg.debug(22))  {
            (message = "") << "stockCPU_o: Scored entity " << entity.name();
            message << " score:" << entity.score();
            ::logg << message;
        }
    }
    else  {
        if(::logg.debug(9))  {
            (message = "") << "stockCPU_o: Increm. ic:" << InstCount << " Name:" << entity.name() << " Gen:" << entity.generation();
            ::logg << message;
        }
    }

    rs3.clear();
    rsPrice.clear();
/*
    ProgramCounter = 0;
    ChromosomeIndex = 0;
*/


    return State;
}


void stockCPU_o::executeInstruction(entity_o& entity)  {
    string_o message;
    long int x;
    long int y;
    histdata_o* r1;
    histdata_o* r2;
    int v;
    int e;
    int f;
    int e1;
    int e2;
    int branch = 0;
    chromosome_o* chromosome;

    chromosome = entity.Chromosomes[ChromosomeIndex];

    inst[0] = 0;
    inst[1] = 0;
/*
    while(inst[0] != 'd' && inst[1] != 'a')
    {
*/
/*
        while(inst[0] != 'd')
        {
            for(y=0;y<3;y++)  {
                inst[0] += (*chromosome)[ProgramCounter];
                if(ProgramCounter++ > chromosome->numberOfGenes())
                    incrementChromosome(entity);
            }
            inst[0] = (inst[0] % 26) + 'a';
        }
*/
/*
        for(y=0;y<3;y++)  {
            inst[1] += (*chromosome)[ProgramCounter];
            if(ProgramCounter++ > chromosome->numberOfGenes())
                incrementChromosome(entity);
        }
        inst[1] = (inst[1] % 26) + 'a';
    }
*/

    for(x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH;x++)  {
        inst[x] = 0;
        for(y=0;y<3;y++)  {
            inst[x] += (*chromosome)[ProgramCounter];
            if(ProgramCounter++ > chromosome->numberOfGenes())
                incrementChromosome(entity);
        }
        inst[x] = (inst[x] % 26) + 'a';
    }


    if(::logg.debug(18))  {
        (message = "") << "stockCPU_o: Executing instruction `";
        for(x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH;x++)  message << inst[x];
        message << "'.";
        ::logg << message;
    }


    switch(inst[0])  {


case 'a':
    if(::logg.debug(22))  {
        (message = "") << "inst: noop";
        ::logg << message;
    }
    break;



/******************************************************************************/
/******************************************************************************/

case 'k':
case 'v':
case 'u':
    if(::logg.debug(22))  {
        (message = "") << "inst : align";
        ::logg << message;
    }

    inst[0] = 0;
    inst[1] = 0;
    x = 0;
    while(inst[0] != 'd' && inst[1] != 'a')  {
        if(x++ > STOCKCPUOBJECT_MAX_INSTRUCTIONS_PER_RUN)  break;
        for(y=0;y<2;y++)  {
            inst[0] += (*chromosome)[ProgramCounter];
            if(ProgramCounter++ > chromosome->numberOfGenes())
                incrementChromosome(entity);
        }
        inst[0] = (inst[0] % 26) + 'a';
        for(y=0;y<2;y++)  {
            inst[1] += (*chromosome)[ProgramCounter];
            if(ProgramCounter++ > chromosome->numberOfGenes())
                incrementChromosome(entity);
        }
        inst[1] = (inst[1] % 26) + 'a';
    }

    break;



/******************************************************************************/
/******************************************************************************/

case 'j':
case 'm':
case 'n':
case 'x':
    if(::logg.debug(30))  {
        (message = "") << "inst : add r1[e] = r1[e] + r2[f]";
        ::logg << message;
    }



    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    *(*r1)[e] = *(*r1)[e] + *(*r2)[f];
    range((*r1)[e],e,inst[1] % 4);

    if(::logg.debug(38))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " + ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }

    if(::logg.debug(39))  {
        message = "";
        (message = "") << "State: " << State << " " << "Registers:\n";
        message << "pc " << ProgramCounter << ", ci " << ChromosomeIndex;
        message << ", ic " << InstCount << ".\n" << "rs";
        rs >> message;
        message << "\nrs2";
        rs2 >> message;
        message << "\nrsPrice";
        rsPrice >> message;
        message << "\nrsClosingPrice";
        (*rsClosingPrice) >> message;
        message << "\nrsBroad";
        (*rsBroad) >> message;
        ::logg << message;
    }

    break;



/******************************************************************************/
/******************************************************************************/

case 'c':
case 'h':
case 'o':
    if(::logg.debug(22))  {
        (message = "") << "inst : subtract r1[e] = r1[e] - r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    *(*r1)[e] = *(*r1)[e] - *(*r2)[f];
    range((*r1)[e],e,inst[1] % 4);


    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " - ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }
            
    break;


/******************************************************************************/
/******************************************************************************/
 
case 'd':
case 'i':
case 'p':
    if(::logg.debug(40))  {
        (message = "") << "inst : multiply r1[e] = r1[e] * r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    *(*r1)[e] = *(*r1)[e] * *(*r2)[f];
    range((*r1)[e],e,inst[1] % 4);

    if(::logg.debug(48))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " * ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }

    if(::logg.debug(49))  {
        message = "";
        (message = "") << "State: " << State << " " << "Registers:\n";
        message << "pc " << ProgramCounter << ", ci " << ChromosomeIndex;
        message << ", ic " << InstCount << ".\n" << "rs";
        rs >> message;
        message << "\nrs2";
        rs2 >> message;
        message << "\nrs3";
        rs3 >> message;
        message << "\nrsPrice";
        rsPrice >> message;
        message << "\nrsClosingPrice";
        (*rsClosingPrice) >> message;
        message << "\nrsBroad";
        (*rsBroad) >> message;
        ::logg << message;
    }

    break;



/******************************************************************************/
/******************************************************************************/

case 'e':
case 'q':
case 't':
    if(::logg.debug(22))  {
        (message = "") << "inst : divide r1[e] = r1[e] / r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    if(*(*r2)[f] != 0)  {
        *(*r1)[e] = *(*r1)[e] / abs(*(*r2)[f]);
        range((*r1)[e],e,inst[1] % 4);
    }


    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " / ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 'f':
case 'r':
case 'y':
    if(::logg.debug(22))  {
        (message = "") << "inst : modulus r1[e] = r1[e] mod r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    if(*(*r2)[f] != 0)  *(*r1)[e] = *(*r1)[e] % abs(*(*r2)[f]);
    range((*r1)[e],e,inst[1] % 4);

    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " % ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 'b':
    if(::logg.debug(22))  {
        (message = "") << "inst : load r1[e] = 0 or 1 or PriceIndex or ChromosomeIndex";
        ::logg << message;
    }

    if(inst[1] % 5 == 2)  {

        if(inst[2] % 2 == 0)  r1 = &rs;
        if(inst[2] % 2 == 1)  r1 = &rs2;
        e = (inst[3] % pricesPerSet());

        if(inst[4] % 7 == 0)  v = 0;
        if(inst[4] % 7 == 1)  v = 0;
        if(inst[4] % 7 == 2)  v = 0;
        if(inst[4] % 7 == 3)  v = 1;
        if(inst[4] % 7 == 4)  v = 1;
        if(inst[4] % 7 == 5)  v = PriceIndex;
        if(inst[4] % 7 == 6)  v = ChromosomeIndex;

        *(*r1)[e] = v;
        range((*r1)[e],e,inst[2] % 2);

        if(::logg.debug(22))  {
            (message = "") << "parse: ";
            if(inst[2] % 2 == 0)  message << "rs";
            if(inst[2] % 2 == 1)  message << "rs2";
            message << "[" << e << "]";
            message << " = ";
            message << " value " << v << ".";
            ::logg << message;
        }
    }

    break;



/******************************************************************************/
/******************************************************************************/

case 'g':
    if(::logg.debug(22))  {
        (message = "") << "inst : load r1[e] = gene value";
        ::logg << message;
    }

    if(inst[1] % 7 == 2)  {

        if(inst[2] % 2 == 0)  r1 = &rs;
        if(inst[2] % 2 == 1)  r1 = &rs2;
        e = (inst[3] % pricesPerSet());
        v = inst[4] + inst[5];

        *(*r1)[e] = v;
        range((*r1)[e],e,inst[1] % 2);

        if(::logg.debug(22))  {
            (message = "") << "parse: ";
            if(inst[1] % 3 == 0)  message << "rs";
            if(inst[1] % 3 == 1)  message << "rs2";
            if(inst[1] % 3 == 2)  message << "rsPrice";
            message << "[" << e << "]";
            message << " = ";
            message << " gene value " << v << ".";
            ::logg << message;
        }
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 's':
    if(::logg.debug(22))  {
        (message = "") << "inst : move r1[e] = r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e1 = inst[3] % pricesPerSet();
    e2 = inst[4] % pricesPerSet();
/*
    e1 = (inst[3] / pricesPerSet()) % pricesPerSet();
    e2 = (inst[3] % pricesPerSet()) % pricesPerSet();
*/


    if(inst[5] % 4 == 2)  e1 = e2;

    *(*r1)[e1] = *(*r2)[e2];
    range((*r1)[e1],e1,inst[1] % 4);

    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrices";
        message << "[" << e1 << "]";
        message << " = ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << e2 << "]";
        ::logg << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 'w':
    if(::logg.debug(22))  {
        (message = "") << "inst : score prediction, increment price set";
        ::logg << message;
    }

    if(inst[1] % 8 == 2)  {
        (void)score(entity);
        if(inst[2] % 2)  {
            ProgramCounter = 0;
            ChromosomeIndex = 0;
        }
    }

    if(State == STOCKCPUOBJECT_STATE_FINISHED)  return;


    break;



/******************************************************************************/
/******************************************************************************/

case 'l':
    if(::logg.debug(90))  {
        (message = "") << "inst : conditional branch chromosome";
(message = "") << "inst : conditional branch if(r1 < r2, element) branch";
        ::logg << message;
    }

    if(inst[1] % 2 == 0)  r1 = &rs2;
    if(inst[1] % 2 == 1)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 5)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    branch = 0;
    if(inst[5] % 2)  if(*(*r1)[e] == *(*r2)[f])  branch = 1;
    else if(*(*r1)[e] < *(*r2)[f])  branch = 1;

    if(::logg.debug(91) && !branch)  {
        (message = "") << "oped out, no branch.";
        ::logg << message;
    }

    if(branch)  {
        if(*rs2[inst[8] % pricesPerSet()] > 0)  {
            if(inst[6] % 2 == 0)  {
                ProgramCounter = 0;
                if(::logg.debug(92))  {
                    (message = "") << "reset program counter.";
                    ::logg << message;
                }
            }
            if(inst[7] % 2 == 0)  {
                for(x=9;x<13;x++)  ProgramCounter += (int)inst[x];
                if(::logg.debug(93))  {
                    (message = "") << "add instruction to program counter.";
                    ::logg << message;
                }
            }
            else  {
                ProgramCounter += *rs2[inst[8] % pricesPerSet()];
                if(::logg.debug(94))  {
                    (message = "") << "add register rs2[";
                    message << inst[8] % pricesPerSet();
                    message << "]:" << *rs2[inst[8] % pricesPerSet()];
                    message << " to program counter.";
                    ::logg << message;
                }
            }
        }

        if(ProgramCounter < 0 || ProgramCounter >= chromosome->numberOfGenes())  {
            ProgramCounter = abs(ProgramCounter) % chromosome->numberOfGenes();
            if(::logg.debug(95))  {
                (message = "") << "program counter modulus needed.";
                ::logg << message;
            }
        }

        if(inst[14] % 2 == 0)  {
            if(*rs2[inst[17] % pricesPerSet()] > 0)  {
                if(inst[15] % 2 == 0)  {
                    ChromosomeIndex = 0;
                    if(::logg.debug(96))  {
                        (message = "") << "reset chromosome index.";
                        ::logg << message;
                    }
                }
                if(inst[16] % 2 == 0)  {
                    for(x=18;x<22;x++)  ChromosomeIndex += (int)inst[x];
                    if(::logg.debug(97))  {
                        (message = "") << "add instruction to chromosome index.";
                        ::logg << message;
                    }
                }
                else  {
                    ChromosomeIndex += *rs2[inst[17] % pricesPerSet()];
                    if(::logg.debug(98))  {
                        (message = "") << "add register rs2[";
                        message << inst[17] % pricesPerSet();
                        message << "]:";
                        message << *rs2[inst[17] % pricesPerSet()];
                        message << " to chromosome index.";
                        ::logg << message;
                    }
                }
            }
            if(ChromosomeIndex < 0 || ChromosomeIndex >= entity.numberOfChromosomes())  {
                ChromosomeIndex = abs(ChromosomeIndex) % entity.numberOfChromosomes();
                if(::logg.debug(99))  {
                    (message = "") << "chromosome counter modulus needed.";
                    ::logg << message;
                }
            }
        }
        chromosome = entity.Chromosomes[ChromosomeIndex];
    }

    if(::logg.debug(99))  {
        (message = "") << "Registers: ";
        message << "pc " << ProgramCounter;
        message << ", ci " << ChromosomeIndex;
        message << ", ic " << InstCount;
        ::logg << message;
    }

    break;



/******************************************************************************/
/******************************************************************************/


default:
    if(::logg.debug(22))  {
        (message = "") << "inst: unknown";
        ::logg << message;
    }
    break;

/******************************************************************************/
/******************************************************************************/

    }   // Close entity program instuction switch-case statment.

/******************************************************************************/
/******************************************************************************/


    return;
}

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/



void stockCPU_o::incrementChromosome(entity_o& entity)  {
    ChromosomeIndex++;
    if(ChromosomeIndex >= entity.numberOfChromosomes())  ChromosomeIndex = 0;

    ProgramCounter = 0;
}

void stockCPU_o::range(int* r,int e,int set)  {
    string_o message;

    if(::logg.debug(110))  {
        (message = "") << "range e:" << e << " set:" << set << " value:"  << *r;
        ::logg << message;
    }

    if(set == 1)  {
        if(*r < MinOffsetInclusive || *r > MaxOffsetInclusive)
            *r = abs(*r) % (MaxOffsetInclusive - MinOffsetInclusive) + MinOffsetInclusive;
    }

    if(set == 2 || set == 3)  {
        if(e == 4)  {
            if(*r < MinOffsetInclusive || *r > MaxOffsetInclusive)
                *r = abs(*r) % (MaxOffsetInclusive - MinOffsetInclusive) + MinOffsetInclusive;
        }
        else  {
            if(*r < MinPriceInclusive || *r > MaxPriceInclusive)
                *r = abs(*r) % (MaxPriceInclusive - MinPriceInclusive) + MinPriceInclusive;
        }
    }

    if(::logg.debug(110))  {
        (message = "") << "range e:" << e << " set:" << set << " value:"  << *r;
        ::logg << message;
    }
}

void stockCPU_o::loadClosingPrices(const char* fname)  {
string_o message;
    histdata_o* hd;
    char buffer[2048];
    string_o s;
    ifstream in;

int i;

    in.open("./stock.dat");
    if(!in)  {
        State = STOCKCPUOBJECT_STATE_ABORT;
        return;
    }

    while(!in.eof())  {
        in.getline(buffer,2048,'\n');
/*
(s="A:")<<buffer;
::logg<<s;
*/
        if(in.eof())  break;

        hd = new histdata_o;
        //*hd << buffer;
        *hd << buffer;
/*
s="B:";
*hd >> s;
::logg << s;
(s="D:")<<hd->date();
::logg << s;
(s="O:")<<hd->open();
::logg << s;
(s="O:")<<*(*hd)[0];
::logg << s;



(s="H:")<<hd->high();
::logg << s;
(s="L:")<<hd->low();
::logg << s;
(s="C:")<<hd->close();
::logg << s;
(s="V:")<<hd->volume();
::logg << s;

        //hd->Date = "";
message = "Z:";
*hd >> message;
::logg << message;
*/
        ClosingPrices.put(hd);


    }
    in.close();

}



/******************************************************************************/
