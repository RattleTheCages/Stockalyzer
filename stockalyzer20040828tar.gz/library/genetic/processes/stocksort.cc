/**  stocksort.cc  *************************************************************

when        who     what
11.22.03    Dan     Creation.  Created from the orignal lotto
                    objects created on 5.17.98.

*******************************************************************************/

#include <fstream.h>
#include <iostream.h>
#include "../entity/colony.h"
#include "../entity/reproduce.h"
#include "../../lib/other/rand.h"
#include "../../lib/other/sysinfo.h"
#include "../../lib/log/log.h"
#include "../processes/stocksort.h"

#define STOCKSORT_BUFFSIZE 99999


log_o logg;
sysinfo_o sysinfo;
rand_o rndm;
reproduce_o reproduce;

stocksort_o* stocksort;


/**  Execute, score and sort!  ************************************************/
int stocksort_o::sort()  {
    long int x;
    entity_o* entp;
    entity_o* entq;

    State = STOCKSORTOBJECT_STATE_EXECUTING;


    for(x=0;x<Colony->population();x++)  {
        entities.put(Colony->Entities[x]);

        Colony->Entities[x]->setObject(NULL);
        (void)stockCPU.execute(*Colony->Entities[x]);
    }


/*
    while(entities.cardinality() > 0)  {
        entp = entities.get();
        entitiesHold.put(entp);
    }
    while(entitiesHold.cardinality() > 0)  {
        entp = entitiesHold.get();
        entp->inRunningScore(entp->score());
        entities.put(entp);
    }
*/


    while(entities.cardinality() > 0)  {
        entq = entities.get();
        while(entities.cardinality() > 0)  {
            entp = entities.get();
            if(entp->score() < entq->score())  {
                entitiesHold.put(entq);
                entq = entp;
            }
            else  { 
                entitiesHold.put(entp);
            }
        }
        entitiesSorted.put(entq);
        while(entitiesHold.cardinality() > 0)  {
            entp = entitiesHold.get();
            entities.put(entp);
        }
    }


    x = entitiesSorted.cardinality();
//    entitiesSorted.release();
    entp = entitiesSorted.get();
    while(entp)  {
        entities.put(entp);
        x--;
        Colony->Entities[x] = entp;
        entp = entitiesSorted.get();
    }

    if(::logg.debug(1))  {
        for(x=0;x<20 && x<Colony->population();x++)  {
            if(Colony->Entities[x]->object())  {
                if(x == reproduce.killLimiter())  {
                    stockprint(*Colony->Entities[x],'*');
                }
                else  {
                    stockprint(*Colony->Entities[x],':');
                }
            }
        }
    }

entp=entities.get();
while(entp)  entp=entities.get();


    State = STOCKSORTOBJECT_STATE_DONE;
    return State;
}


stocksort_o::stocksort_o()  {
    State = STOCKSORTOBJECT_STATE_CLEAR;

    Colony = new colony_o;
}

stocksort_o::~stocksort_o()  {}


int main(int argc, char* argv[])  {
    string_o message;
    colony_o* colony;
    int      x,y,z,j,t;


    ::logg.registerName(argv[0]);
    ::logg.setDebugLevel(1);     // Sorted, scored, prediction list.
//  ::logg.setDebugLevel(5);     // Regesters.
//  ::logg.setDebugLevel(6);     // Reached max instructing, no prediction.
//  ::logg.setDebugLevel(7);     // Finshed with prediction.
//  ::logg.setDebugLevel(8);     // Scoring, increment price set.
//  ::logg.setDebugLevel(9);     // No score, increment price set.
//  ::logg.setDebugLevel(18);    // Instructions.
//  ::logg.setDebugLevel(22);
//  ::logg.setDebugLevel(23);
//  ::logg.setDebugLevel(110);   // Ranging.
    ::logg.setDebugLevel(111);
//  ::logg.setDebugLevel(29);
//  for(x=120;x<=129;x++)  ::logg.setDebugLevel(x);  // Instructions.
//for(x=0;x<119;x++)  ::logg.setDebugLevel(x);
//for(x=0;x<1024;x++)  ::logg.setDebugLevel(x);
//for(x=90;x<=99;x++)  ::logg.setDebugLevel(x);  // Branching.
//for(x=30;x<=39;x++)  ::logg.setDebugLevel(x);  // Adding.
//for(x=40;x<=49;x++)  ::logg.setDebugLevel(x);  // Multiply.


    if(::logg.debug(111))  {
        message << "stocksort_o: Starting with pid:" << ::sysinfo.pid();
        ::logg << message;
    }

    if(argc < 2)  {
        (message = "") << "stocksort_o: usage: Colony ClosingPrices PredictionFile\n";
        ::logg.error(message);
        return ERROR_FAIL;
    }


    stocksort = new stocksort_o;
    if(!stocksort)  {
        (message = "") << "stocksort_o: stocksort object instantation returned null.";
        ::logg.error(message);
        return ERROR_FAIL;
    }

    stocksort->loadClosingPrices(argv[2]);


    stocksort->loadColony(argv[1]);


    for(t=0;t<26;t++)  {
        if(::logg.debug(111))  {
            (message = "stocksort_o: ") << "Starting execution.  Loop:" << t;
            message << "  pop:" << stocksort->Colony->population();
            message << "  gen:" << stocksort->Colony->generation();
            ::logg << message;
        }


        stocksort->sort();


        reproduce.setKillLimiter(18);
        reproduce.setNumberOfGenerationIterations(5);
        colony = stocksort->Colony;
        stocksort->Colony = reproduce.reproduce(*stocksort->Colony);
        delete colony;
    }


    stocksort->saveColony();


/**  Write predictions to a file.  ********************************************/


/*
    ofstream outp(argv[3],ios::app);
    if(!outp)  {
    }

    outp << endl;
    outp.close();
*/
}

void stocksort_o::stockprint(entity_o& e,char delm)  {
    histdata_o* hd;
    string_o s;

    hd = (histdata_o*)e.object();

    s << e.name() << delm << e.generation();
    s.justifyRight(15);
    cout << "Name:" << s.string();
    (s = "") << e.score();
    s.justifyLeft(8);
    cout << " Score:" << s.string();
    (s = "") << hd->open();
    s.justifyLeft(5);
    cout << " O:" << s.string();
    (s = "") << hd->high();
    s.justifyLeft(5);
    cout << " H:" << s.string();
    (s = "") << hd->low();
    s.justifyLeft(5);
    cout << " L:" << s.string();
    (s = "") << hd->close();
    s.justifyLeft(5);
    cout << " C:" << s.string();
    (s = "") << hd->volume();
    s.justifyLeft(8);
    cout << " V:" << s.string();

    cout << endl;
}


/**  Read in file of the entities' DNA.  **************************************/
int stocksort_o::loadColony(const char* filename)  {
    string_o message;
    long int x;
    ifstream in;
    char     buff[STOCKSORT_BUFFSIZE];
    string_o string;

    in.open(filename);
    if(!in)  {
        (message = "") << "stocksort_o: Colony file not found: " << filename;
        ::logg.error(message);
        return ERROR_FAIL;
    }

    while(!in.eof())  {
        for(x=0;x<STOCKSORT_BUFFSIZE;x++)  {
            in.get(buff[x]);
            if(in.eof())  break;
        }
        string.fill(x,buff);
    }
    in.close();

    if(string.length() < 22)  {
        (message = "") << "stocksort_o: loadColony(" << Colony->name();
        message << ").  Colony file may be empty.";
        ::logg.error(message);
    }

    *Colony << string.string();

    if(::logg.debug(1))  {
        (message = "") << "stocksort_o: loadColony(" << Colony->name();
        message << ") population:" << Colony->population();
        message << " generation:" << Colony->generation() << ".";
        ::logg << message.string();
    }

    State = STOCKSORTOBJECT_STATE_LOADED;
    return State;
}


/**  Write order to the colony file.  *****************************************/
int stocksort_o::saveColony()  {
    string_o message;
    string_o string;
    ofstream out(Colony->name());

    if(!out)  {
        (message = "") << "stocksort_o: Cannot open for writing, colony file: " << Colony->name();
        ::logg.error(message);
        return ERROR_FAIL;
    }

    if(::logg.debug(2))  {
        (message = "") << "stocksort_o: saveColony(), Colony name: " << Colony->name();
        message << ".\npopulation: " << Colony->population() << ".\n";
        message << "generation: " << Colony->generation() << ".";
        ::logg << message.string();
    }


    Colony->setLastOperation("stocksort");
    *Colony >> string;

    out << string.string();
    out.close();
}

int stocksort_o::loadClosingPrices(const char* filename)  {
    histdata_o* hd;
    char buffer[2048];
    ifstream in;

    if(!filename)  in.open("./stock.dat");
    else  in.open(filename);
    if(!in)  {
        State = STOCKSORTOBJECT_STATE_ERROR;
        return State;
    }

    while(!in.eof())  {
        in.getline(buffer,2048,'\n');
        if(in.eof())  break;

        hd = new histdata_o;
        *hd << buffer;
        stockCPU.ClosingPrices.put(hd);


    }
    in.close();


    State = STOCKSORTOBJECT_STATE_LOADED;
    return State;
}

/******************************************************************************/
