/**  StockCPU.h  ***************************************************************

    Stock CPU Object.


changes log
when      who      what
11.21.03  Dan      Creation.  Created from lotto objects originally
                   created 5.17.98.

*******************************************************************************/


#ifndef STOCKCPUOBJECT_H
#define STOCKCPUOBJECT_H

#include "../../lib/string.h"
#include "../../lib/other/list.h"
#include "../entity/entity.h"
#include "../../../stockdata/histdata.h"
#include "../../../stockdata/movingdata.h"


#define STOCKCPUOBJECT_OBJECT   "stockCPU_o"
#define STOCKCPUOBJECT_STATE    "state"

#define STOCKCPUOBJECT_STATE_VOID           0
#define STOCKCPUOBJECT_STATE_CLEAR          1
#define STOCKCPUOBJECT_STATE_READY          2
#define STOCKCPUOBJECT_STATE_EXECUTING      4
#define STOCKCPUOBJECT_STATE_REACHED_END    5
#define STOCKCPUOBJECT_STATE_REACHED_MAX    6
#define STOCKCPUOBJECT_STATE_SCORED         7
#define STOCKCPUOBJECT_STATE_FINISHED       8
#define STOCKCPUOBJECT_STATE_ABORT          9



#define STOCKCPUOBJECT_PRICES_PER_SET                        6
#define STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE    22 
#define STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE    9899
#define STOCKCPUOBJECT_DEFAULT_MIN_OFFSET_NUMBER_INCLUSIVE   0 
#define STOCKCPUOBJECT_DEFAULT_MAX_OFFSET_NUMBER_INCLUSIVE   999999
#define STOCKCPUOBJECT_NUMBER_OF_REGISTERS                   7
#define STOCKCPUOBJECT_INSTRUCTION_LENGTH                    8
#define STOCKCPUOBJECT_MAX_INSTRUCTIONS_PER_RUN              99999
#define STOCKCPUOBJECT_MIN_INSTRUCTIONS_TO_SCORE             59


class stockCPU_o  {
    friend class stocksort_o;

  private:
    int         State;

    long int    ProgramCounter;
    long int    InstCount;
    long int    InstCountSet;
    long int    PriceIndex;
    char        inst[STOCKCPUOBJECT_INSTRUCTION_LENGTH+1];
    char*       instbuff;
    histdata_o  rs;       //Register Set.
    histdata_o  rs2;
    histdata_o  rs3;
    histdata_o  rsPrice;
    histdata_o* rsClosingPrice;
    histdata_o* rsBroad;
    histdata_o  rsPrediction;
    int         NumberOfRegisters;

    int         Score;
    int         MinPriceInclusive;
    int         MaxPriceInclusive;
    int         MinOffsetInclusive;
    int         MaxOffsetInclusive;
    int         PricesPerSet;

  protected:
    list_o<histdata_o> ClosingPrices;
    list_o<histdata_o> ClosingPricesUse;
    movingdata_o       Movingdata;

    void executeInstruction(entity_o&);
    int  score(entity_o&);


  public:
    stockCPU_o();                                       // Default constructor.
    stockCPU_o(const stockCPU_o&);                      // Copy constructor.
   ~stockCPU_o();                                       // Default destuctor.
    stockCPU_o& operator = (const stockCPU_o&);         // Assignment operator.
    void            operator >> (string_o&) const;      // OLP representation.
    void            operator << (const char*);          // Reconstruct.
    void            clear();
    int             state()                 const;


    int execute(entity_o&);

    void range(int*,int,int);
    double whatPercentOfAisB(int,int);
    double pow(double,int);

    int pricesPerSet() const;
    int fetchInst(entity_o&);


    void loadClosingPrices(const char*);
};


/******************************************************************************/

inline int stockCPU_o::state() const  {
    return (int)State;
}

inline int stockCPU_o::pricesPerSet() const  {
    return (int)PricesPerSet;
}


#endif

/******************************************************************************/
