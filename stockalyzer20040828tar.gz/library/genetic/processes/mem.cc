/**  mem.cc  *************************************************************

when        who     what

*******************************************************************************/

#include <fstream.h>
#include <iostream.h>
#include "../entity/colony.h"
#include "../../lib/other/rand.h"
#include "../../lib/other/sysinfo.h"
#include "../../lib/log/log.h"
#include "../processes/stocksort.h"

#define STOCKSORT_BUFF_SIZE 9128


log_o logg;
sysinfo_o sysinfo;
rand_o rndm;



int main(int argc, char* argv[])  {
    string_o message;
    int      x,y,z,j;
    colony_o colony;
    ifstream in;
    char     buff[STOCKSORT_BUFF_SIZE];
    string_o string;


    ::logg.registerName(argv[0]);
for(x=0;x<1024;x++)  ::logg.setDebugLevel(x);

message << "Starting with pid:" << ::sysinfo.pid();
::logg << message;

    if(argc != 2)  {
        (message = "") << "usage: Colony PredictionFile\n";
        ::logg.error(message);
        return ERROR_FAIL;
    }




/**  Read in file of the entities' DNA.  **************************************/


    in.open(argv[1]);
    if(!in)  {
        (message = "") << "File not found: " << argv[1];
        ::logg.error(message);
        return ERROR_FAIL;
    }

    while(!in.eof())  {
        for(x=0;x<STOCKSORT_BUFF_SIZE;x++)  {
            in.get(buff[x]);
            if(in.eof())  break;
        }
        string.fill(x,buff);
    }
    in.close();

    colony << string.string();

    if(::logg.debug(1))  {
        (message = "") << "Colony name: " << colony.name() << ".\n";
        message << "population: " << colony.population() << ".\n";
        message << "generation: " << colony.generation() << ".";
        ::logg << message.string();
    }


//  stocksort->sort(colony);

for(x=0;x<1344;x++)  {
    int* dan;

    dan = new int(x);
}



/**  Write order to the colony file.  *****************************************/


    ofstream out(argv[1]);
    if(!out)  {
        (message = "") << "Cannot open file: " << argv[1];
        ::logg.error(message);
        return ERROR_FAIL;
    }

    colony.setLastOperation("stocksort");
    string = "";
    colony >> string;
    out << string.string();
    out.close();


/**  Write predictions to a file.  ********************************************/


/*
    ofstream outp(argv[2],ios::app);
    if(!outp)  {
    }

    outp << endl;
    outp.close();
*/
}


/******************************************************************************/
