/**  stockexec.cc  *************************************************************

when        who     what
12.14.03    Dan     Creation.  Created from the orignal lotto
                    objects created on 5.17.98.

*******************************************************************************/

#include <fstream.h>
#include <iostream.h>
#include "../entity/colony.h"
#include "../entity/reproduce.h"
#include "../../lib/other/rand.h"
#include "../../lib/other/sysinfo.h"
#include "../../lib/log/log.h"
#include "../processes/stocksort.h"

#define STOCKSORT_BUFFSIZE 99999


log_o logg;
sysinfo_o sysinfo;
rand_o rndm;
reproduce_o reproduce;

stocksort_o* stocksort;


stockexec_o::stockexec_o()  {
    State = STOCKEXECOBJECT_STATE_CLEAR;
}

stockexec_o::~stockexec_o()  {}


int main(int argc, char* argv[])  {
    string_o message;
    colony_o* colony;
    int      x,y,z,j,t;


    ::logg.registerName(argv[0]);
    ::logg.setDebugLevel(1);     // Sorted, scored, prediction list.
//  ::logg.setDebugLevel(5);     // Regesters.
//  ::logg.setDebugLevel(6);     // Reached max instructing, no prediction.
//  ::logg.setDebugLevel(7);     // Finshed with prediction.
//  ::logg.setDebugLevel(8);     // Scoring, increment price set.
//  ::logg.setDebugLevel(9);     // No score, increment price set.
//  ::logg.setDebugLevel(18);    // Instructions.
//  ::logg.setDebugLevel(22);
//  ::logg.setDebugLevel(23);
//  ::logg.setDebugLevel(110);   // Ranging.
    ::logg.setDebugLevel(111);
//  ::logg.setDebugLevel(29);
//  for(x=120;x<=129;x++)  ::logg.setDebugLevel(x);  // Instructions.
//for(x=0;x<119;x++)  ::logg.setDebugLevel(x);
//for(x=0;x<1024;x++)  ::logg.setDebugLevel(x);
//for(x=90;x<=99;x++)  ::logg.setDebugLevel(x);  // Branching.
//for(x=30;x<=39;x++)  ::logg.setDebugLevel(x);  // Adding.
//for(x=40;x<=49;x++)  ::logg.setDebugLevel(x);  // Multiply.


    if(::logg.debug(111))  {
        (message = "stockexec_o: ") << "Starting with pid:" << ::sysinfo.pid();
        ::logg << message;
    }

    if(argc < 2)  {
        (message = "stockexec_o: ") << "usage: Colony ClosingPrices PredictionFile\n";
        ::logg.error(message);
        return ERROR_FAIL;
    }


    loadClosingPrices(argv[2]);


    listenForEntities();


}

int stockexec_o::loadClosingPrices(const char* filename)  {
    histdata_o* hd;
    char buffer[2048];
    ifstream in;

    if(!filename)  in.open("./stock.dat");
    else  in.open(filename);
    if(!in)  {
        State = STOCKEXECOBJECT_STATE_ERROR;
        return State;
    }

    while(!in.eof())  {
        in.getline(buffer,2048,'\n');
        if(in.eof())  break;

        hd = new histdata_o;
        *hd << buffer;
        stockCPU.ClosingPrices.put(hd);


    }
    in.close();


    State = STOCKEXECOBJECT_STATE_LOADED;
    return State;
}

/******************************************************************************/
