/**  stocksort.h  **************************************************************

    DNA Artifical Intellegence Stock Sort Process Object.




when      who     what
11.22.03  Dan     Creation.

*******************************************************************************/


#ifndef STOCKSORTOBJECT_H
#define STOCKSORTOBJECT_H


#include "../entity/colony.h"
#include "../../lib/thread/queue.h"
#include "../../lib/other/list.h"
#include "../processes/stockCPU.h"

#define STOCKSORTOBJECT_STATE_CLEAR      0
#define STOCKSORTOBJECT_STATE_EXECUTING  1
#define STOCKSORTOBJECT_STATE_DONE       2
#define STOCKSORTOBJECT_STATE_LOADED     8
#define STOCKSORTOBJECT_STATE_ERROR      9


class stocksort_o  {
  private:
    int               State;
public:
    colony_o*         Colony;
    list_o<entity_o>  entities;
    list_o<entity_o>  entitiesHold;
    list_o<entity_o>  entitiesSorted;
    stockCPU_o        stockCPU;

  public:
    stocksort_o();                                      // Default constructor.
    stocksort_o(const stocksort_o&);                    // Copy constructor.
   ~stocksort_o();                                      // Default destructor.
    stocksort_o& operator = (const stocksort_o&);       // Assignment operator.

    int sort();

    void stockprint(entity_o&,char);

    int loadColony(const char*);
    int loadClosingPrices(const char*);
    int saveColony();

    int state() const;
};

/******************************************************************************/


int stocksort_o::state() const  {
    return State;
}

#endif

/******************************************************************************/
