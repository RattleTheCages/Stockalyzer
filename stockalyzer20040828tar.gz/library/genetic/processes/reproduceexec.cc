/**  reproduceexec.cc  *********************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




    DNA Artifical Intelligence Entity Reproduction Process Object.





when      who     what
9.24.96   Dan     Creation.
6.13.98   Dan     Changed:  Have all output start with `reproduce'.
6.22.98   Dan     Added:    Usage.
                  Changed:  Using a queue to hold entities now.
6.29.98   Dan     Added:    Using thread object and threads now.
7.14.98   Dan     Added:    Verbose option on the command line and in code.
8.2.98    Dan     Added:    Using the new global object.  Tracking the
                            generation through the colony object now.
12.24.99  Dan     Changed:  Using OLP, removed global object and threading.
11.29.03  Dan     Added:    Command line parameter -k.
11.30.03  Dan     Changed:  This object to reproduceexec, and placed
                            abstracted object reproduce_o in to the
                            entities directory.

*******************************************************************************/


#include <unistd.h>
#include <fstream.h>
#include <iostream.h>

#include "../../lib/thread/thread.h"
#include "../../lib/log/log.h"
#include "../../lib/thread/queue.h"
#include "../../lib/other/rand.h"
#include "../../lib/other/sysinfo.h"
#include "../entity/reproduce.h"
#include "../entity/colony.h"


#define REPRODUCE_FILE_BUFF_SIZE 98192


sysinfo_o    sysinfo;
rand_o       rndm;
log_o        logg;
reproduce_o  reproduce;

colony_o* colony;
int StartingGeneration;


void usage(const char* name)  {
    cout << '\n';
    cout << "Usage: " << name << " [-r integer] [-g integer] string\n";
    cout << "The options are:\n";
    cout << "-r integer  : Number of reproduction generation interations.\n";
    cout << "-g integer  : Starting generation number\n";
    cout << "-k integer  : Kill Limiter.  Load given limit of entities.  (Best if they are sorted with the highest scoring enetities listed first.)\n";
    cout << "-v integer  : Vebose mode\n";
    cout << "            : 1 - display new entities after generation.\n";
    cout << "The manditory parameter is:\n";
    cout << "string      : Name of the colony to execute reproduction.\n";
}

int loadColony(const char* colonyFileName)  {
    string_o message;
    string_o colonyString;
    long int buffindex = 0;
    char     buffer[REPRODUCE_FILE_BUFF_SIZE];
    ifstream in;


    if(::logg.debug(402))  {
        (message = "") << "Loading entity colony: `" << colonyFileName << "'.";
        ::logg << message;
    }
  
    in.open(colonyFileName);
    if(!in)  {
        (message = "") << "Colony object file not found: " << colonyFileName;
        ::logg.error(message);
        return -1;
    }

    while(!in.eof())  {
        for(buffindex=0;buffindex<REPRODUCE_FILE_BUFF_SIZE;buffindex++)  {
            in.get(buffer[buffindex]);
            if(in.eof())  break;
        }
        colonyString.fill(buffindex,buffer);
    }
    in.close();

    (*colony) << colonyString.string();

    if(StartingGeneration == 0)
        StartingGeneration = colony->generation() + 1;

    if(::logg.debug(403))  {
        (message = "") << "Completed the loading of the colony object.";
        ::logg << message;
    }
}


int saveColony()  {
    string_o message;
    string_o s;
    ofstream out;

    if(::logg.debug(409))  {
        (message = "") << "population: " << colony->population();
        message << " Starting the writing of the colony object.";
        ::logg << message;
    }

    if(colony)  {
        out.open(colony->name());
        if(!out)  {
            (message = "") << "Cannot open writing file: " << colony->name();
            ::logg.error(message);

            return -1;
        }
    }

    *colony >> s;
    out << s.string();
    out.close();

    return 0;
}


int main(int argc, char* argv[])  {
    string_o  message;
    long int  x,y;
    int       fileIndex;

colony = new colony_o;

    ::logg.registerName(argv[0]);
    for(x=0;x<500;x++)  ::logg.setDebugLevel(x);


/**  Check passed in arguments.  **********************************************/

    if(argc < 2)  {
        usage(argv[0]);
        return -1;
    }
    x = 1;
    while(x<argc)  {
        if(*argv[x] == '-' && *(argv[x]+1) == 'r')  {
            x++;
            y = atoi(argv[x]);
            if(y > 0 && y < 65534)  reproduce.setNumberOfGenerationIterations(y);
            else  {
                (message = "") << "Unable to use '" << argv[x];
                message << "' as the number of generation interations.";
                ::logg.error(message);
            }
        }
        else if(*argv[x] == '-' && *(argv[x]+1) == 'g')  {
            x++;
            y = atoi(argv[x]);
            if(y > 1 && y < 65534)  reproduce.setStartingGeneration(y);
            else  {
                (message = "") << "Unable to use '" << argv[x];
                message << "' as the starting generation.";
                ::logg.error(message);
            }
        }
        else if(*argv[x] == '-' && *(argv[x]+1) == 'k')  {
            x++;
            y = atoi(argv[x]);
            if(y > 1 && y < 65534)  reproduce.setKillLimiter(y);
            else  {
                (message = "") << "Unable to use '" << argv[x];
                message << "' as the number to kill.";
                ::logg.error(message);
            }
        }
        else  break;
        x++;
    }
    if(x != argc-1)  {
        usage(argv[0]);
        return -1;
    }
    fileIndex = x;

    if(::logg.debug(400))  {
        (message = "") << "colony `" << argv[fileIndex];
        message << "' iterations: "<< reproduce.numberOfGenerationIterations();
        message << " kill limiter: " << reproduce.killLimiter();
        ::logg << message;
    }


    loadColony(argv[fileIndex]);

    colony = reproduce.reproduce(*colony);

    saveColony();

    return 0;
}




/******************************************************************************/
