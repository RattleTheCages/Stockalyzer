/**  lottosort.h  **************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




    DNA Artifical Intellegence Lotto Sort Process Object.




when      who     what
5.21.00   Dan     Creation.

*******************************************************************************/


#ifndef LOTTOSORTOBJECT_API
#define LOTTOSORTOBJECT_API


#include "../entity/colony.h"
#include "../../lib/thread/queue.h"
#include "../processes/lottoEnvironment.h"



class lottosort_o  {
  private:
    queue_o<entity_o> entities;
    queue_o<entity_o> entitiesHold;
    queue_o<entity_o> entitiesSorted;

    lottoEnvironment_o lottoEnvironment;

  public:
    lottosort_o();                                      // Default constructor.
    lottosort_o(const lottosort_o&);                    // Copy constructor.
   ~lottosort_o();                                      // Default destructor.
    lottosort_o& operator = (const lottosort_o&);       // Assignment operator.

    int sort(colony_o&);

};


#endif

/******************************************************************************/
