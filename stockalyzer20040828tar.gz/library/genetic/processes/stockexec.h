/**  stockexec.h  **************************************************************

    DNA Artifical Intellegence Execution Process Object.




when      who     what
12.14.03  Dan     Creation.

*******************************************************************************/


#ifndef STOCKEXECOBJECT_API
#define STOCKEXECOBJECT_API


#include "../entity/colony.h"
#include "../../lib/thread/queue.h"
#include "../../lib/other/list.h"
#include "../processes/stockCPU.h"

#define STOCKEXECOBJECT_STATE_CLEAR      0
#define STOCKEXECOBJECT_STATE_EXECUTING  1
#define STOCKEXECOBJECT_STATE_DONE       2
#define STOCKEXECOBJECT_STATE_LOADED     8
#define STOCKEXECOBJECT_STATE_ERROR      9


class stocksort_o  {
  private:
    int         State;
    entity_o*   entity;
    stockCPU_o  stockCPU;

  public:
    stockexec_o();                                      // Default constructor.
    stockexec_o(const stocksort_o&);                    // Copy constructor.
   ~stockexec_o();                                      // Default destructor.
    stockexec_o& operator = (const stocksort_o&);       // Assignment operator.

    int exec(entity_o&);

    int listenForEntity();

    int state() const;
};

/******************************************************************************/


int stocksort_o::state() const  {
    return State;
}

#endif

/******************************************************************************/
