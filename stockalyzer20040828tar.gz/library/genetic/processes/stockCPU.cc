/**  stockCPU.cc  *************************************************************


changes log
when      who      what
11.21.03  Dan      Creation.  Created from the original
                   lotto objects on 5.17.98

*******************************************************************************/


#include "../../lib/log/log.h"
#include "../../lib/error/error.h"
#include "../../lib/other/rand.h"
#include "../processes/stockCPU.h"

extern log_o logg;
extern rand_o rndm;

stockCPU_o::stockCPU_o()  {
    State              = STOCKCPUOBJECT_STATE_VOID;
    Score              = 0;
    PricesPerSet       = STOCKCPUOBJECT_PRICES_PER_SET;
    NumberOfRegisters  = STOCKCPUOBJECT_NUMBER_OF_REGISTERS;
    MinPriceInclusive  = STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE;
    MaxPriceInclusive  = STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE;
    MinOffsetInclusive = STOCKCPUOBJECT_DEFAULT_MIN_OFFSET_NUMBER_INCLUSIVE;
    MaxOffsetInclusive = STOCKCPUOBJECT_DEFAULT_MAX_OFFSET_NUMBER_INCLUSIVE;

    instbuff = NULL;
    clear();

    State = STOCKCPUOBJECT_STATE_READY;
}

stockCPU_o::~stockCPU_o()  {
    if(instbuff)  delete instbuff;
}

void stockCPU_o::clear()  {
    ProgramCounter = 0;
    InstCount = 0;
    InstCountSet = 0;
    PriceIndex = 0;

    rs.clear();
    rs2.clear();
    rsPrice.clear();
    rsClosingPrice = NULL;
    rsBroad = NULL;
    rsPrediction.clear();

    for(int x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH+1;x++)  inst[x] = NULL;
    if(instbuff)  delete instbuff;
    instbuff = NULL;

    State = STOCKCPUOBJECT_STATE_CLEAR;
}


int stockCPU_o::execute(entity_o& entity)  {
    string_o           message;
    histdata_o*        hd;

    State = STOCKCPUOBJECT_STATE_EXECUTING;

    if(::logg.debug(5))  {
        (message = "") << "stockCPU_o: execute: " << entity.name();
        ::logg << message;
    }

    hd = ClosingPricesUse.get();
    while(hd)  hd = ClosingPricesUse.get();
    hd = ClosingPrices.first();
    while(hd)  {
        ClosingPricesUse.put(hd);
        hd = ClosingPrices.next();
    }
    Movingdata.clear();


    rs.clear();
    rs2.clear();
    rs3.clear();
    rsPrice.clear();
    rsPrediction.clear();

    entity.setScore(0);
    ProgramCounter = 0;
    InstCount = 0;
    InstCountSet = 0;
    instbuff = new char[entity.Chromosomes[0]->numberOfGenes()];
    for(int i=0;i<entity.Chromosomes[0]->numberOfGenes();i++)  instbuff[i] = '\0';
    rsClosingPrice = ClosingPricesUse.get();
    Movingdata.inma(rsClosingPrice->close());
    PriceIndex = 1;
    rsBroad = rsClosingPrice;


    while(2)  {

        (void)executeInstruction(entity);

        if(::logg.debug(5))  {
            message = "";
            message << "State: " << State << " ";
            message << "Registers:\n";
            message << "pc " << ProgramCounter;
            message << ", ic " << InstCount;
            message << ".\n";
            message << "rs";
            rs >> message;
            message << "\nrs2";
            rs2 >> message;
            message << "\nrs3";
            rs3 >> message;
            message << "\nrsPrice";
            rsPrice >> message;
            if(rsClosingPrice)  {
                message << "\nrsClosingPrice";
                (*rsClosingPrice) >> message;
            }
            if(rsBroad)  {
                message << "\nrsBroad";
                (*rsBroad) >> message;
            }
            message << "\nrsPrediction";
            rsPrediction >> message;
            message << ".";
            ::logg << message;
        }

        if(State == STOCKCPUOBJECT_STATE_FINISHED)  return State;
        if(!rsClosingPrice)  {
            (message = "") << "stockCPU_o: Error.  Was the closing prices data loaded?";
            ::logg << message;
            return State;
         }



        InstCount++;
        InstCountSet++;
        if(InstCount >= STOCKCPUOBJECT_MAX_INSTRUCTIONS_PER_RUN)
            State = STOCKCPUOBJECT_STATE_REACHED_MAX;
        if(State == STOCKCPUOBJECT_STATE_REACHED_END ||
           State == STOCKCPUOBJECT_STATE_REACHED_MAX)  {
            if(::logg.debug(6))  {
                entity.setScore(entity.score()/100);
                (message = "stockCPU_o: ") << "Reachd. ic:" << InstCount;
                message << " Name:" << entity.name() << " Gen:" << entity.generation();
                message << " max instruction.";
                if(State == STOCKCPUOBJECT_STATE_REACHED_END)  {
                    message << " Ran out of genes.";
                }
                ::logg << message;
            }
            return State;
        }
    }

    return State;
}

int stockCPU_o::score(entity_o& entity)  {
    string_o message;
    histdata_o temphist;
    int x,y;
    double p;
    long int score = 0;
    long int sum = 0;

    temphist = rsPrediction;
    rsPrediction = rsPrice;

    rsClosingPrice = ClosingPricesUse.get();
    PriceIndex++;
    rsBroad = rsClosingPrice;
    if(!rsClosingPrice)  {
        if(rsPrediction.low() != 0)  score = score + 1000;
        if(rsPrediction.high() != 0)  score = score + 650;
        if(rsPrediction.close() != 0)  score = score + 650;
        if(rsPrediction.volume() != 0)  score = score + 1;
        entity.setScore(entity.score()+score);
        if(::logg.debug(7))  {
            (message = "stockCPU_o: ") << "Finish. ic:" << InstCount << " Name:" << entity.name() << " Gen:" << entity.generation() << " Score:" << entity.score() << " Prediction:";
            rsPrediction >> message;
            ::logg << message;
        }

        State = STOCKCPUOBJECT_STATE_FINISHED;
        return State;
    }
    Movingdata.inma(rsClosingPrice->close());


    p = whatPercentOfAisB(rsPrediction.low(),rsClosingPrice->low());
    if(::logg.debug(8))  {
        (message = "stockCPU_o: ") << "whatPercentOf " << rsPrediction.low();
        message << " is " << rsClosingPrice->low() << " :";
        if(p != 0)  message << p;
    }
    if(p>100)  p = 100 - (p - 100);
    if(p < 0)  p = 0;
    p = pow(p / 100,3);
    score = (int)(p * 14);
    if(score < 0)  score = 0;
    sum += score;
    if(::logg.debug(8))  {
        message << "  score:" << score;
        ::logg << message;
    }

    p = whatPercentOfAisB(rsPrediction.high(),rsClosingPrice->high());
    if(p>100)  p = 100 - (p - 100);
    if(p < 0)  p = 0;
    p = pow(p / 100,3);
    score = (int)(p * 6);
    if(score < 0)  score = 0;
    sum += score;

    p = whatPercentOfAisB(rsPrediction.close(),rsClosingPrice->close());
    if(p>100)  p = 100 - (p - 100);
    if(p < 0)  p = 0;
    p = pow(p / 100,3);
    score = (int)(p * 5);
    if(score < 0)  score = 0;
    sum += score;

    p = whatPercentOfAisB(rsPrediction.open(),rsClosingPrice->open());
    if(p>100)  p = 100 - (p - 100);
    if(p < 0)  p = 0;
    p = pow(p / 100,3);
    score = (int)(p * 2);
    if(score < 0)  score = 0;
    sum += score;

    p = whatPercentOfAisB(rsPrediction.volume(),rsClosingPrice->volume());
    if(p>100)  p = 100 - (p - 100);
    if(p < 0)  p = 0;
    p = pow(p / 100,2);
    score = (int)(p * 1);
    if(score < 0)  score = 0;
    sum += score;




    score = 0;
    if(InstCountSet > 730)  score = score + 3;
    if(InstCountSet > 340)  score = score + 1;
    InstCountSet = 0;
    if(rsPrediction.low() < rsClosingPrice->high())  score = score + 1;
    if(rsPrediction.close() >= rsClosingPrice->low())  score = score + 1;
    if(rsPrediction.close() <= rsClosingPrice->high())  score = score + 1;
    if(rsPrediction.high() > rsClosingPrice->low())  score = score + 1;

    if(rsPrediction.close() == temphist.close() &&
       temphist.close() != rsClosingPrice->close())  score = score - 1;
    if(rsPrediction.high() == temphist.high() &&
       temphist.high() != rsClosingPrice->high())  score = score - 1;
    if(rsPrediction.low() == temphist.low() &&
       temphist.low() != rsClosingPrice->low())  score = score - 1;
    sum += score;

    if(sum > 0)  {
        if(sum >= 25)  sum = sum + (int)(((double)PriceIndex/2400)*(double)sum);
        entity.setScore(sum + entity.score());
        if(entity.object())  delete entity.object();
        entity.setObject(new histdata_o);
        *(histdata_o*)entity.object() = rsPrediction;

        if(::logg.debug(8))  {
            (message = "") << "stockCPU_o: Scored. ic:" << InstCount << " pi:" << PriceIndex << " Name:" << entity.name() << " Gen:" << entity.generation() << " Score:" << sum/100;
            ::logg << message;
        }
        if(::logg.debug(22))  {
            (message = "") << "stockCPU_o: Scored entity " << entity.name();
            message << " score:" << entity.score()/100;
            ::logg << message;
        }
    }
    else  {
        if(::logg.debug(9))  {
            (message = "") << "stockCPU_o: Increm. ic:" << InstCount << " Name:" << entity.name() << " Gen:" << entity.generation();
            ::logg << message;
        }
    }

    rs.clear();
    rs2.clear();
    rs3.clear();
    rsPrice.clear();
    ProgramCounter = 0;

    return State;
}

int stockCPU_o::fetchInst(entity_o& entity)  {
    string_o message;
    int ii,x,y;
    chromosome_o* chromosome;
    int i,j,k,l;
    int g[26];
    int h[26];

    for(x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH &&
        ProgramCounter+x<entity.Chromosomes[0]->numberOfGenes();x++)  {
        inst[x] = instbuff[x+ProgramCounter];
        if(!instbuff[x+ProgramCounter])  break;
    }
    if(x == STOCKCPUOBJECT_INSTRUCTION_LENGTH)  {
        if(::logg.debug(128))  {
            (message = "stockCPU_o: ") << "inst cashed!";
            ::logg << message;
        }

        ProgramCounter += STOCKCPUOBJECT_INSTRUCTION_LENGTH;
        if(ProgramCounter >= entity.Chromosomes[0]->numberOfGenes())  {
            State = STOCKCPUOBJECT_STATE_REACHED_END;
            return State;
        }
        return State;
    }


    for(x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH;x++)  inst[x] = 0;

    for(ii=0;ii<STOCKCPUOBJECT_INSTRUCTION_LENGTH;ii++)  {
        for(x=0;x<26;x++)  {
            g[x] = 0;
            h[x] = 0;
        }

        for(x=0;x<entity.numberOfChromosomes();x++)
            g[(*(entity.Chromosomes[x]))[ProgramCounter]-'a']++;

        if(::logg.debug(120))  {
            (message = "stockCPU_o: ") << "g[] = ";
            for(x=0;x<26;x++)  message << g[x] << " " << (char)((char)x+'a') << "  ";
            ::logg << message;
        }

        i = 0;
        j = 0;
        l = 0;
        k = 1;
//        while(l++ < 26 && k > 0)  {
            k = 1;
            while(l++ < 6 && k > 0)  {
                for(x=0;x<26;x++)  {
                    if(j == g[x])  k++;
                    if(j < g[x])  {
                        i = x;
                        j = g[x];
                        k = 0;
                    }
                }
    
                if(::logg.debug(121))  {
                    (message = "stockCPU_o: ") << "Highest count: " << (char)(i+'a');
                    message << "  i:" << i << "  j:" << j << "  k:" << k;
                    ::logg << message;
                }

                if(k == 0)  break;

    /* recessive and domonant genes: take the gene closest two the other two. */

                for(x=0;x<26;x++)  h[x] = g[x];
                for(x=0;x<26;x++)  {
                    if(x == 0)  g[x] += h[25] + h[1];
                    else  if(x == 25)  g[x] += h[0] + h[24];
                    else  g[x] += h[x-1] + h[x+1];
                }

                if(::logg.debug(122))  {
                    (message = "stockCPU_o: ") << "g[] = ";
                    for(x=0;x<26;x++)  message << g[x] << " " << (char)((char)x+'a') << "  ";
                    ::logg << message;
                }
//            }
        }
        ProgramCounter++;
        if(ProgramCounter >= entity.Chromosomes[0]->numberOfGenes())  {
            State = STOCKCPUOBJECT_STATE_REACHED_END;
            return State;
        }
//        if(l < 6)  {
            inst[ii] = (char)(i+'a');
            instbuff[ProgramCounter-STOCKCPUOBJECT_INSTRUCTION_LENGTH-1] = (char)(i+'a');
    //        break;
//        }
    }

    return State;
}

double stockCPU_o::whatPercentOfAisB(int a,int b)  {
    double p;
    p = ((double)b) / ((double)a) * 100;
    if(p < 0)  p = p * -1;
    return p;
}

double stockCPU_o::pow(double p,int e)  {
    double r;

    if(e == 0)  return 1;

    else  if(e < 0)  {
        return 0;  //!!
    }
    else  if(e == 2)  {
        return  p * p;
    }
    else  if(e == 3)  {
        return  p * p * p;
    }
    else  if(e == 4)  {
        return  p * p * p * p;
    }
    else  {
        r = 1;
        for(int x=0;x<e;x++)  r = r * r;
    }

    return r;
}

void stockCPU_o::executeInstruction(entity_o& entity)  {
    string_o message;
    long int x;
    long int y;
    histdata_o* r1;
    histdata_o* r2;
    char inst2[STOCKCPUOBJECT_INSTRUCTION_LENGTH];
    int instscore = 0;
    histdata_o rssv;
    int v,e,f,g;
    int e1;
    int e2;
    int branch = 0;


    fetchInst(entity);


    if(::logg.debug(18))  {
        (message = "") << "stockCPU_o: Executing instruction `";
        for(x=0;x<STOCKCPUOBJECT_INSTRUCTION_LENGTH;x++)  message << inst[x];
        message << "'.";
        ::logg << message;
    }


    switch(inst[0])  {


case 'a':
    if(::logg.debug(22))  {
        (message = "") << "inst: noop";
        ::logg << message;
    }
    break;



/******************************************************************************/
/******************************************************************************/

case 'k':
    if(::logg.debug(22))  {
        (message = "") << "inst : align";
        ::logg << message;
    }

/*
    inst[0] = 0;
    inst[1] = 0;
    x = 0;
    while(inst[0] != 'd' && inst[1] != 'a')  {
        if(x++ > STOCKCPUOBJECT_MAX_INSTRUCTIONS_PER_RUN)  break;
        for(y=0;y<2;y++)  {
            inst[0] += (*chromosome)[ProgramCounter];
            ProgramCounter++;
            if(ProgramCounter >= entity.Chromosomes[0]->numberOfGenes())  {
                State = STOCKCPUOBJECT_STATE_REACHED_END;
                return State;
            }
        }
        inst[0] = (abs((inst[0] - 'a')) % 26) + 'a';
        for(y=0;y<2;y++)  {
            inst[1] += (*chromosome)[ProgramCounter];
            ProgramCounter++;
            if(ProgramCounter >= entity.Chromosomes[0]->numberOfGenes())  {
                State = STOCKCPUOBJECT_STATE_REACHED_END;
                return State;
            }
        }
        inst[1] = (abs((inst[1] - 'a')) % 26) + 'a';
    }
*/

    break;



/******************************************************************************/
/******************************************************************************/

case 'j':
case 'x':
case 'o':
case 'p':
case 'q':
    if(::logg.debug(30))  {
        (message = "") << "inst : add r1[e] = r1[e] + (r2[f] * (rs[g] % 100))";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();
    g = inst[5] % pricesPerSet();

    rssv = *r1;

    *(*r1)[e] = *(*r1)[e] + (*(*r2)[f] * (*rs[g] % 100));
    range((*r1)[e],e,inst[1] % 4);

    if(*(*r1)[e] != *rssv[e])  instscore++;
    if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
        *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

    if(::logg.debug(38))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " + (";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        message << " * (rs[" << g << "] % 100))";
        ::logg << message;
    }
    if(::logg.debug(38))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "] = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "] + (" << *(*r2)[f];
        message << " * ( " << *rs[g] << " % 100))";
        ::logg << message;
    }


    break;


/******************************************************************************/
/******************************************************************************/

case 'm':
case 'n':
    if(::logg.debug(30))  {
        (message = "") << "inst : add r1[e] = r1[e] + r2[f]";
        ::logg << message;
    }


    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    rssv = *r1;

    *(*r1)[e] = *(*r1)[e] + *(*r2)[f];
    range((*r1)[e],e,inst[1] % 4);

    if(*(*r1)[e] != *rssv[e])  instscore++;
    if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
        *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

    if(::logg.debug(38))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " + ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        ::logg << message;
    }

    if(::logg.debug(39))  {
        message = "";
        (message = "") << "State: " << State << " " << "Registers:\n";
        message << "pc " << ProgramCounter;
        message << ", ic " << InstCount << ".\n" << "rs";
        rs >> message;
        message << "\nrs2";
        rs2 >> message;
        message << "\nrsPrice";
        rsPrice >> message;
        message << "\nrsClosingPrice";
        (*rsClosingPrice) >> message;
        message << "\nrsBroad";
        (*rsBroad) >> message;
        ::logg << message;
    }

    break;



/******************************************************************************/
/******************************************************************************/

case 'c':
case 'h':
    if(::logg.debug(22))  {
        (message = "") << "inst : subtract r1[e] = r1[e] - r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    rssv = *r1;

    *(*r1)[e] = *(*r1)[e] - *(*r2)[f];
    range((*r1)[e],e,inst[1] % 4);

    if(*(*r1)[e] != *rssv[e])  instscore++;
    if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
        *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " - ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }
            
    break;


/******************************************************************************/
/******************************************************************************/
 
case 'd':
case 'i':
    if(::logg.debug(40))  {
        (message = "") << "inst : multiply r1[e] = r1[e] * r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    rssv = *r1;

    *(*r1)[e] = *(*r1)[e] * *(*r2)[f];
    range((*r1)[e],e,inst[1] % 4);

    if(*(*r1)[e] != *rssv[e])  instscore++;
    if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
        *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

    if(::logg.debug(48))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " * ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }


    break;



/******************************************************************************/
/******************************************************************************/

case 'e':
case 't':
    if(::logg.debug(22))  {
        (message = "") << "inst : divide r1[e] = r1[e] / r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    rssv = *r1;

    if(*(*r2)[f] != 0)  {
        *(*r1)[e] = *(*r1)[e] / abs(*(*r2)[f]);
        range((*r1)[e],e,inst[1] % 4);
    }

    if(*(*r1)[e] != *rssv[e])  instscore++;
    if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
        *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;


    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " / ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 'f':
case 'r':
case 'y':
    if(::logg.debug(22))  {
        (message = "") << "inst : modulus r1[e] = r1[e] mod r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    rssv = *r1;

    if(*(*r2)[f] != 0)  *(*r1)[e] = *(*r1)[e] % abs(*(*r2)[f]);
    range((*r1)[e],e,inst[1] % 4);

    if(*(*r1)[e] != *rssv[e])  instscore++;
    if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
        *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " = ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrice";
        message << "[" << e << "]";
        message << " % ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << f << "]";
        ::logg << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 'b':
case 'v':
case 'u':
    if(::logg.debug(28))  {
        (message = "") << "inst : load r1[e] = 0, 1, PriceIndex, 50MA, or 9MA";
        ::logg << message;
    }

    if(inst[1] % 5 == 1)  {
        if(inst[2] % 2 == 0)  r1 = &rs;
        if(inst[2] % 2 == 1)  r1 = &rs2;
        e = (inst[3] % pricesPerSet());

        rssv = *r1;

        *(*r1)[e] = Movingdata.ma50();
        range((*r1)[e],e,inst[2] % 2);

        if(*(*r1)[e] != *rssv[e])  instscore++;
        if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
           *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

        if(::logg.debug(29))  {
            (message = "") << "parse: ";
            if(inst[2] % 2 == 0)  message << "rs";
            if(inst[2] % 2 == 1)  message << "rs2";
            message << "[" << e << "]";
            message << " = ";
            message << " 50ma " << Movingdata.ma50() << ".";
            ::logg << message;
        }
    }
    else  if(inst[1] % 5 == 2)  {
        if(inst[2] % 2 == 0)  r1 = &rs;
        if(inst[2] % 2 == 1)  r1 = &rs2;
        e = (inst[3] % pricesPerSet());

        rssv = *r1;

        *(*r1)[e] = Movingdata.ma9();
        range((*r1)[e],e,inst[2] % 2);

        if(*(*r1)[e] != *rssv[e])  instscore++;
        if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
           *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

        if(::logg.debug(29))  {
            (message = "") << "parse: ";
            if(inst[2] % 2 == 0)  message << "rs";
            if(inst[2] % 2 == 1)  message << "rs2";
            message << "[" << e << "]";
            message << " = ";
            message << " 9ma " << Movingdata.ma9() << ".";
            ::logg << message;
        }
    }
    else  {

        if(inst[2] % 2 == 0)  r1 = &rs;
        if(inst[2] % 2 == 1)  r1 = &rs2;
        e = (inst[3] % pricesPerSet());

        if(inst[4] % 6 == 0)  v = 0;
        if(inst[4] % 6 == 1)  v = 0;
        if(inst[4] % 6 == 2)  v = 0;
        if(inst[4] % 6 == 3)  v = 1;
        if(inst[4] % 6 == 4)  v = 1;
        if(inst[4] % 6 == 5)  v = PriceIndex;

        rssv = *r1;

        *(*r1)[e] = v;
        range((*r1)[e],e,inst[2] % 2);

        if(*(*r1)[e] != *rssv[e])  instscore++;
        if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
           *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

        if(::logg.debug(28))  {
            (message = "") << "parse: ";
            if(inst[2] % 2 == 0)  message << "rs";
            if(inst[2] % 2 == 1)  message << "rs2";
            message << "[" << e << "]";
            message << " = ";
            message << " value " << v << ".";
            ::logg << message;
        }
    }

    break;



/******************************************************************************/
/******************************************************************************/

case 'g':
    if(::logg.debug(22))  {
        (message = "") << "inst : load r1[e] = gene value";
        ::logg << message;
    }

    if(inst[1] % 9 == 2)  {

        if(inst[2] % 2 == 0)  r1 = &rs;
        if(inst[2] % 2 == 1)  r1 = &rs2;
        e = (inst[3] % pricesPerSet());
        v = inst[4] + inst[5];

        rssv = *r1;

        *(*r1)[e] = v;
        range((*r1)[e],e,inst[1] % 2);

        if(*(*r1)[e] != *rssv[e])  instscore++;
        if(*(*r1)[e] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
           *(*r1)[e] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

        if(::logg.debug(22))  {
            (message = "") << "parse: ";
            if(inst[1] % 3 == 0)  message << "rs";
            if(inst[1] % 3 == 1)  message << "rs2";
            if(inst[1] % 3 == 2)  message << "rsPrice";
            message << "[" << e << "]";
            message << " = ";
            message << " gene value " << v << ".";
            ::logg << message;
        }
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 's':
    if(::logg.debug(22))  {
        (message = "") << "inst : move r1[e] = r2[f]";
        ::logg << message;
    }

    if(inst[1] % 4 == 0)  r1 = &rs;
    if(inst[1] % 4 == 1)  r1 = &rs2;
    if(inst[1] % 4 == 2)  r1 = &rs3;
    if(inst[1] % 4 == 3)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rs3;
    if(inst[2] % NumberOfRegisters == 3)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 5)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 6)  r2 = &rsPrediction;
    e1 = inst[3] % pricesPerSet();
    e2 = inst[4] % pricesPerSet();
/*
    e1 = (inst[3] / pricesPerSet()) % pricesPerSet();
    e2 = (inst[3] % pricesPerSet()) % pricesPerSet();
*/

    if(inst[5] % 4 == 2)  e1 = e2;

    rssv = *r1;

    *(*r1)[e1] = *(*r2)[e2];
    range((*r1)[e1],e1,inst[1] % 4);

    if(*(*r1)[e1] != *rssv[e1])  instscore++;
    if(*(*r1)[e1] < STOCKCPUOBJECT_DEFAULT_MAX_PRICE_NUMBER_INCLUSIVE &&
       *(*r1)[e1] > STOCKCPUOBJECT_DEFAULT_MIN_PRICE_NUMBER_INCLUSIVE)  instscore++;

    if(::logg.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 4 == 0)  message << "rs";
        if(inst[1] % 4 == 1)  message << "rs2";
        if(inst[1] % 4 == 2)  message << "rs3";
        if(inst[1] % 4 == 3)  message << "rsPrices";
        message << "[" << e1 << "]";
        message << " = ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rs2";
        if(inst[2] % NumberOfRegisters == 2)  message << "rs3";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsPrice";
        if(inst[2] % NumberOfRegisters == 4)  message << "rsClosingPrice";
        if(inst[2] % NumberOfRegisters == 5)  message << "rsBroad";
        if(inst[2] % NumberOfRegisters == 6)  message << "rsPrediction";
        message << "[" << e2 << "]";
        ::logg << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/

case 'w':
    if(::logg.debug(22))  {
        (message = "") << "inst : score prediction, increment price set";
        ::logg << message;
    }

    if(InstCountSet > STOCKCPUOBJECT_MIN_INSTRUCTIONS_TO_SCORE && inst[1] % 4 == 2)  {
        (void)score(entity);
        if(inst[2] % 2)  {
            ProgramCounter = 0;
        }
    }

    if(State == STOCKCPUOBJECT_STATE_FINISHED)  return;
    if(State == STOCKCPUOBJECT_STATE_REACHED_END)  return;

    break;



/******************************************************************************/
/******************************************************************************/

case 'l':
    if(::logg.debug(90))  {
        (message = "") << "inst : conditional branch";
(message = "") << "inst : conditional branch if(r1 < r2, element) branch";
        ::logg << message;
    }


    if(inst[1] % 2 == 0)  r1 = &rs2;
    if(inst[1] % 2 == 1)  r1 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 0)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 1)  r2 = &rs2;
    if(inst[2] % NumberOfRegisters == 2)  r2 = &rsPrice;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsClosingPrice;
    if(inst[2] % NumberOfRegisters == 4)  r2 = rsBroad;
    if(inst[2] % NumberOfRegisters == 5)  r2 = &rsPrediction;
    e = inst[3] % pricesPerSet();
    f = inst[4] % pricesPerSet();

    branch = 0;
    if(1/*inst[5] % 2*/)  if(*(*r1)[e] == *(*r2)[f])  branch = 1;
    else if(*(*r1)[e] < *(*r2)[f])  branch = 1;

    if(::logg.debug(91) && !branch)  {
        (message = "") << "oped out, no branch.";
        ::logg << message;
    }

    if(branch)  {

        fetchInst(entity);

        if(*rs2[inst[2] % pricesPerSet()] > 0)  {
            if(inst[0] % 2 == 0)  {
                ProgramCounter = 0;
                if(::logg.debug(92))  {
                    (message = "") << "reset program counter.";
                    ::logg << message;
                }
            }
            if(inst[1] % 2 == 0)  {
                for(x=3;x<8;x++)  ProgramCounter += inst[x];
                if(::logg.debug(93))  {
                    (message = "") << "add instruction to program counter.";
                    ::logg << message;
                }
            }
            else  {
                ProgramCounter += *rs2[inst[2] % pricesPerSet()];
                if(::logg.debug(94))  {
                    (message = "") << "add register rs2[";
                    message << inst[2] % pricesPerSet();
                    message << "]:" << *rs2[inst[2] % pricesPerSet()];
                    message << " to program counter.";
                    ::logg << message;
                }
            }
        }

        if(ProgramCounter < 0 || ProgramCounter >= entity.Chromosomes[0]->numberOfGenes())  {
            ProgramCounter = abs(ProgramCounter) % entity.Chromosomes[0]->numberOfGenes();
            if(::logg.debug(95))  {
                (message = "") << "program counter modulus needed.";
                ::logg << message;
            }
        }

    }

    if(::logg.debug(99))  {
        (message = "") << "Registers: ";
        message << "pc " << ProgramCounter;
        message << ", ic " << InstCount;
        ::logg << message;
    }

    break;



/******************************************************************************/
/******************************************************************************/


default:
    if(::logg.debug(22))  {
        (message = "") << "inst: unknown";
        ::logg << message;
    }
    break;

/******************************************************************************/
/******************************************************************************/

    }   // Close entity program instuction switch-case statment.

    if(instscore > 0)  entity.setScore(entity.score()+instscore);
    if(::logg.debug(23))  {
        (message = "stockCPU_o: ") << "inst score: " << instscore;
        ::logg << message;
    }

/******************************************************************************/
/******************************************************************************/


    return;
}

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/




void stockCPU_o::range(int* r,int e,int set)  {
    string_o message;

    if(::logg.debug(110))  {
        (message = "") << "range e:" << e << " set:" << set << " value:"  << *r;
        ::logg << message;
    }

    if(set == 1)  {
        if(*r < MinOffsetInclusive || *r > MaxOffsetInclusive)
            *r = abs(*r) % (MaxOffsetInclusive - MinOffsetInclusive) + MinOffsetInclusive;
    }

    if(set == 2 || set == 3)  {
        if(e == 4)  {
            if(*r < MinOffsetInclusive || *r > MaxOffsetInclusive)
                *r = abs(*r) % (MaxOffsetInclusive - MinOffsetInclusive) + MinOffsetInclusive;
        }
        else  {
            if(*r < MinPriceInclusive || *r > MaxPriceInclusive)
                *r = abs(*r) % (MaxPriceInclusive - MinPriceInclusive) + MinPriceInclusive;
        }
    }

    if(::logg.debug(110))  {
        (message = "") << "range e:" << e << " set:" << set << " value:"  << *r;
        ::logg << message;
    }
}



/******************************************************************************/
