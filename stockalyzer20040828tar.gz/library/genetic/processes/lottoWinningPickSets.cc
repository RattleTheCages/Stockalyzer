/**  lottoWinningPickSets.cc  **************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman





changes log
when      who      what
5.17.98   Dan      Creation of orignal lottosort executable this object
                   replaces.
5.20.00   Dan      Creation.


*******************************************************************************/

#include <fstream.h>//!!!

#include "../processes/lottoWinningPickSets.h"

lottoWinningPickSets_o::lottoWinningPickSets_o()  {
    long int x;
    long int y;

    State = LOTTOWINNINGPICKSETSOBJECT_STATE_CLEAR;
    NumberOfPicksPerSet =LOTTOWINNINGPICKSETSOBJECT_DEFAULT_PICKS_PER_SET;
    NumberOfWinningPickSets = LOTTOWINNINGPICKSETSOBJECT_DEFAULT_PICKS_PER_SET;
    Picks = 0;



/***The Winning Number Picks should be loaded dynamically. For now, load here.*/
/***The Winning Number Picks should be loaded via network, not file.          */


    NumberOfWinningPickSets = 260;
    Picks = new int*[NumberOfWinningPickSets];
    string_o s;
    char numb[8];
    ifstream in;
    in.open("./lotto.txt");
    if(!in)  {
        State = LOTTOWINNINGPICKSETSOBJECT_STATE_VOID;
        return;
    }

    x = 0;
    y = 0;

    while(2)  {
        in >> numb;
        if(x == 0)  Picks[y] = new int[NumberOfPicksPerSet];
        s = "";
        s << numb;
        Picks[y][x]=s.stoi();
        x++;
        if(x>=NumberOfPicksPerSet)  {
            y++;
            if(y>=NumberOfWinningPickSets)  break;
            x = 0;
        }

    }

    in.close();


}


lottoWinningPickSets_o::~lottoWinningPickSets_o()  {
    if(Picks)  delete Picks;
}

int lottoWinningPickSets_o::operator[](int)  {
return -1;//!!!
}

int lottoWinningPickSets_o::set(int x, int y)  {
    if(x < 0 || y < 0)  return -1;
    if(x >= NumberOfWinningPickSets)  return -1;
    if(y >= NumberOfPicksPerSet)  return -1;
    return Picks[x][y];
}


/******************************************************************************/
