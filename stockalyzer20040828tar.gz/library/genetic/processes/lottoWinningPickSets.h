/**  lottoWinningPickSets.h  ***************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman



    Lotto Winning Pick Sets Data Object.


changes log
when      who      what
5.17.98   Dan      Creation of orignal lottosort executable this object
                   replaces.
5.20.00   Dan      Creation.


*******************************************************************************/


#ifndef LOTTOWINNINGPICKSETSOBJECT_API
#define LOTTOWINNINGPICKSETSOBJECT_API

#include "../../lib/string/string.h"


#define LOTTOWINNINGPICKSETSOBJECT_DEFAULT_PICKS_PER_SET 6
#define LOTTOWINNINGPICKSETSOBJECT_MAX_NUMBER_PICKED      42

#define LOTTOWINNINGPICKSETSOBJECT_OBJECT   "lottoWinningPicks_o"
#define LOTTOWINNINGPICKSETSOBJECT_STATE    "state"
#define LOTTOWINNINGPICKSETSOBJECT_PICK     "pick"

#define LOTTOWINNINGPICKSETSOBJECT_STATE_VOID   0
#define LOTTOWINNINGPICKSETSOBJECT_STATE_CLEAR  1
#define LOTTOWINNINGPICKSETSOBJECT_STATE_NORMAL 2


class lottoWinningPickSets_o  {

  private:
    short int   State;
    long int    NumberOfWinningPickSets;
    int         NumberOfPicksPerSet;
    int**       Picks;


  public:
    lottoWinningPickSets_o();                           // Default constructor.
    lottoWinningPickSets_o(const lottoWinningPickSets_o&);
                                                        // Copy constructor.
   ~lottoWinningPickSets_o();                           // Default destuctor.
    lottoWinningPickSets_o&  operator = (const lottoWinningPickSets_o&);
                                                        // Assignment operator.
    void            operator >> (string_o&) const;      // OLP Rep.
    void            operator << (const char*);          // Reconstruct.

    int             state() const;

    int operator[](int);
    //int operator[](lottoWinningPickSets_o::operator[](int)&);
    //operator[]& operator[](operator[]&);
    int set(int,int);


    long int numberOfWinningPickSets() const;
    int numberOfPicksPerSet() const;
};


/******************************************************************************/

inline int lottoWinningPickSets_o::state() const  {
    return (int)State;
}

inline long int lottoWinningPickSets_o::numberOfWinningPickSets() const  {
    return  NumberOfWinningPickSets;
}

inline int lottoWinningPickSets_o::numberOfPicksPerSet() const  {
    return  (int)NumberOfPicksPerSet;
}


#endif

/******************************************************************************/
