/**  lottosort.cc  *************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman





when        who     what
5.17.98     Dan     Creation.
6.13.98     Dan     Fixed:    Bug with scoring repeating numbers.
6.24.98     Dan     Changed:  Using a queue to hold entities now.
                    Added:    Lotto Object.
8.2.98      Dan     Added:    Using new Global Object now.
2.3.99      Dan     Changed:  Processing loops.
2.20.99     Dan     Added:    Using new running score now.
2.22.99     Dan     Changed:  NOG genes are moved into the function now.
                              New functions, will they work?
3.12.99     Dan     Changed:  Fixed bug in geneformula.
5.21.00     Dan     Changed:  Using new lottoEnviroment_o object.

*******************************************************************************/

#include <fstream.h>
#include <iostream.h>
#include "../entity/colony.h"
#include "../../lib/other/rand.h"
#include "../../lib/log/log.h"
#include "../processes/lottosort.h"

#define LOTTOSORT_BUFF_SIZE 9128


log_o logg;
rand_o rndm;

lottosort_o* lottosort;


/*
int lottosort_o::pow(int n,int e)  {
    int x = n;
    e = e % 16; 
    if(e == 0)  return 1;
    for(int i=1;i<e;i++)  x = x * n;
    return x;
}
*/


int lottosort_o::sort(colony_o& colony)  {
    int x;
    entity_o* entp;
    entity_o* entq;

    for(x=0;x<colony.population();x++)  {
        entities.put(colony.Entities[x]);

        (void)lottoEnvironment.execute(*colony.Entities[x]);
    }



    while(entities.cardinality() > 0)  {
        entp = entities.get();
        entitiesHold.put(entp);
    }
    while(entitiesHold.cardinality() > 0)  {
        entp = entitiesHold.get();
        entp->inRunningScore(entp->score());
        entities.put(entp);
    }


    while(entities.cardinality() > 0)  {
        entq = entities.get();
        while(entities.cardinality() > 0)  {
            entp = entities.get();
            if(entp->score() < entq->score())  {
                entitiesHold.put(entq);
                entq = entp;
            }
            else  { 
                entitiesHold.put(entp);
            }

        }
        entitiesSorted.put(entq);
        while(entitiesHold.cardinality() > 0)  {
            entp = entitiesHold.get();
            entities.put(entp);
        }
    }


    x = entitiesSorted.cardinality();
    entitiesSorted.release();
    entp = entitiesSorted.get();
    while(entp)  {
        entities.put(entp);
        x--;
        colony.Entities[x] = entp;
        entp = entitiesSorted.get();
    }



    return ERROR_OK;
}

lottosort_o::lottosort_o()  {}
lottosort_o::~lottosort_o()  {}



int main(int argc, char* argv[])  {
    string_o message;
    int      x,y,z,j;
    colony_o colony;
    ifstream in;
    char     buff[LOTTOSORT_BUFF_SIZE];
    string_o string;


    ::logg.registerName(argv[0]);
//    ::logg.setDebugLevel(7);
for(x=0;x<1024;x++)  ::logg.setDebugLevel(x);


    if(argc != 2)  {
        (message = "") << "usage: Colony PredictionFile\n";
        ::logg.error(message);
        return ERROR_FAIL;
    }



    lottosort = new lottosort_o;
    if(!lottosort)  {
        (message = "") << "lottosort object instanchation returned null.";
        ::logg.error(message);
        return ERROR_FAIL;
    }




/**  Read in file of the entities' DNA.  **************************************/


    in.open(argv[1]);
    if(!in)  {
        (message = "") << "File not found: " << argv[1];
        ::logg.error(message);
        return ERROR_FAIL;
    }

    while(!in.eof())  {
        for(x=0;x<LOTTOSORT_BUFF_SIZE;x++)  {
            in.get(buff[x]);
            if(in.eof())  break;
        }
        string.fill(x,buff);
    }
    in.close();

    colony << string.string();

    if(::logg.debug(1))  {
        (message = "") << "Colony name: " << colony.name() << ".\n";
        message << "population: " << colony.population() << ".\n";
        message << "generation: " << colony.generation() << ".";
        ::logg << message;
    }


    lottosort->sort(colony);



/**  Write order to the colony file.  *****************************************/


    ofstream out(argv[1]);
    if(!out)  {
        (message = "") << "Cannot open file: " << argv[1];
        ::logg.error(message);
        return ERROR_FAIL;
    }

    colony.setLastOperation("lottosort");
    string = "";
    colony >> string;
    out << string.string();
    out.close();


/**  Write predictions to a file.  ********************************************/


    ofstream outp(argv[2],ios::app);
    if(!outp)  {
    }

    outp << endl;
    outp.close();
}


/******************************************************************************/
