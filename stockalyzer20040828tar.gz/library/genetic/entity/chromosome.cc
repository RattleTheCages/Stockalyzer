/**  chromosome.cc  ************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman


    DNA Artifical Intellegence Chromosome Object.




when        who        what
9.24.96     Dan        Creation.
6.14.98     Dan        Changed:  Object name from chromosome_ to chromosome_o.
            Dan        Added:    Some constructors, genes method.
9.2.99      Dan        Changed:  Using global_o object now.
12.24.99    Dan        Changed:  Object serial definition to OLP.

*******************************************************************************/

#include "../../lib/other/rand.h"
#include "../entity/chromosome.h"

extern rand_o rndm;

chromosome_o::chromosome_o()  {}

chromosome_o::chromosome_o(long int nog)  {
    long int x,y;
    x = nog;
    if(x > CHROMOSOME_MAX_NUMBER_OF_GENES)  x = CHROMOSOME_MAX_NUMBER_OF_GENES;
    for(y=0;y<x;y++)  Genes << (char)(97+rndm.i(26));
}

chromosome_o::chromosome_o(const chromosome_o& c)  {
    Genes = c.Genes;
}

chromosome_o::~chromosome_o()  {}

chromosome_o& chromosome_o::operator = (const chromosome_o& h)  {
    Genes = h.Genes;
    return *this;
}

void chromosome_o::reverse()  {
    Genes.reverse();
}

long int chromosome_o::cut(long int place)  {
    return Genes.cut(place);
}

long int chromosome_o::upcut(long int place)  {
    return Genes.upcut(place);
}

long int chromosome_o::splice(long int place,long int length)  {
    Genes.upcut(place);
    Genes.cut(length);
    return numberOfGenes();
}

long int chromosome_o::append(const chromosome_o& attament)  {
    Genes << attament.Genes;
    return numberOfGenes();
}


void chromosome_o::display(string_o& s,int n) const  {
    string_o t(Genes);
    t.cut(n);
    s << numberOfGenes() << ' ' << t;
}

void chromosome_o::setGene(long int n,char v)  {
    long int x;
    if(n < 0 || n > CHROMOSOME_MAX_NUMBER_OF_GENES)  return;
    if(Genes.length() < n)  {
        for(x=0;x<n;x++)  Genes << (char)(97+rndm.i(26));
    }
    Genes << (char)(97+rndm.i(26));

    Genes.setCharat(n,v);
}

void chromosome_o::operator << (const char* cc)  {
    string_o s(cc);
    s.upcut(CHROMOSOME_OBJECT);
    s.upcut(CHROMOSOME_GENES);
    s.upcut('=');
    s.cut('\n');
    Genes = s;
}

void chromosome_o::operator >> (string_o& s) const  {
    s << '\n' << CHROMOSOME_OBJECT << ':';
    s << '\n' << CHROMOSOME_GENES << '=' << Genes;
    s << '\n';
}


/******************************************************************************/
