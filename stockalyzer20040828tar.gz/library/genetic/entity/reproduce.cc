/**  reproduce.cc  *************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




    DNA Artifical Intelligence Entity Reproduction Process Object.





when      who     what
9.24.96   Dan     Creation.
6.13.98   Dan     Changed:  Have all output start with `reproduce'.
6.22.98   Dan     Added:    Usage.
                  Changed:  Using a queue to hold entities now.
6.29.98   Dan     Added:    Using thread object and threads now.
7.14.98   Dan     Added:    Verbose option on the command line and in code.
8.2.98    Dan     Added:    Using the new global object.  Tracking the
                            generation through the colony object now.
12.24.99  Dan     Changed:  Using OLP, removed global object and threading.
11.30.03  Dan     Changed:  Made processes into member functions so that the
                            object could be used by other objects, and not just
                            a main().  This was ment to be done years ago.

*******************************************************************************/


#include <fstream.h>

#include "../../lib/thread/thread.h"
#include "../../lib/log/log.h"
#include "../../lib/thread/queue.h"
#include "../../lib/other/rand.h"
#include "../../lib/other/sysinfo.h"
#include "reproduce.h"


#define REPRODUCE_FILE_BUFF_SIZE 98192


extern sysinfo_o  sysinfo;
extern rand_o     rndm;
extern log_o      logg;

reproduce_o::reproduce_o()  {
    GuestEntity = NULL;
    Generation  = 0;
    StartingGeneration = 0;
    NumberOfGenerationIterations = 0;
    KillLimiter = 0;

    State = REPRODUCEOBJECT_STATE_CLEAR;
}

reproduce_o::reproduce_o(entity_o* e1,const entity_o& e2,int g)/*:entity_o(*e1)*/  {
    GuestEntity = &e2;
    Generation  = g;
    NumberOfGenerationIterations = 0;
    StartingGeneration = 0;
    KillLimiter = 0;

    State = REPRODUCEOBJECT_STATE_CLEAR;
}

reproduce_o::~reproduce_o()  {}

/*
void reproduce_o::threadloop()  {
    entity_o* baby;
    if(guestentity)  {
        baby = reproduce(*guestentity,generation);
        ::global.newentities.put(baby);
        if(::global.verbose == 1)  {
            baby->display(cout,18);
            cout << endl;
        }
    }
    ::global.mutex.broadcast("threadloop");
}
*/


colony_o* reproduce_o::reproduce(colony_o& colony)  {
    string_o          message;
    colony_o*         colony2;
    long int          population;
    long int          x,y;
    long int          generation;
    long int          pick,pick2;
    entity_o*         entity1;
    entity_o*         entity2;
    entity_o*         baby;
    queue_o<entity_o> entities;
    queue_o<entity_o> entitieshold;

    State = REPRODUCEOBJECT_STATE_EXECUTING;


/******************************************************************************/
/**  Place entities into a linked list.                                      **/
/******************************************************************************/

    if(killLimiter() > 2 && killLimiter() < colony.population())
        population = killLimiter();
    else  population = colony.population();

    if(::logg.debug(411))  {
        (message = "reproduce_o: ") << "Starting reproduction.";
        ::logg << message;
        (message = "reproduce_o: ") << "Population: ";
        message  << population << " kill limter: " << killLimiter();
        message << " generation: " << colony.generation();
        ::logg << message;
    }

    for(x=0;x<population;x++)  {
        entitieshold.put(colony.Entities[x]);//!!! private data.
    }


    generation = colony.generation()+1;
    setStartingGeneration(generation);
    if(numberOfGenerationIterations() < 1 ||
       numberOfGenerationIterations() > 32766)
        setNumberOfGenerationIterations(1);

    if(::logg.debug(412))  {
        (message = "reproduce_o: ") << "numberOfGenerationIterations: ";
        message << numberOfGenerationIterations() << " generation: ";
        message << generation;
        ::logg << message;
    }

/******************************************************************************/
/**  Iterate reproduction.                                                   **/
/******************************************************************************/

    for(generation=startingGeneration();
        generation<startingGeneration()+numberOfGenerationIterations();
        generation++)  {

        while(entitieshold.cardinality() > 0)  entities.put(entitieshold.get());
        if(::logg.debug(407))  {
            (message = "reproduce_o: ") << "population: " << entities.cardinality();
            message << " generation: " << generation;
            ::logg << message;
        }


/******************************************************************************/
/**  Match up entities randomly to reproduce.                                **/
/******************************************************************************/


        while(entities.cardinality() > 1)  {
            pick = rndm.i(entities.cardinality()-1);
            for(y=0;y<pick;y++)  {
                entity1 = entities.get();
                entities.put(entity1);
            }
            entity1 = entities.get();
            entitieshold.put(entity1);
            pick = rndm.i(entities.cardinality()-1);
            for(y=0;y<pick;y++)  {
                entity2 = entities.get();
                entities.put(entity2);
            }
            entity2 = entities.get();
            entitieshold.put(entity2);


/**  Start pick one reproduce thread with pick two.  **************************/

            //reproduce = new reproduce_o(entity1,*entity2,generation);


            baby = entity1->reproduce(*entity2,generation);
            entitieshold.put(baby);
        }


        while(entities.cardinality() > 0)  entitieshold.put(entities.get());

    }



/**  Create new colony including new members.  ********************************/

    if(::logg.debug(404))  {
        (message = "") << "reproduce_o: New population: ";
        message << entitieshold.cardinality();
        ::logg << message;
    }

    colony2 = new colony_o(colony.name(),
                           entitieshold.cardinality(),
                           "Colony",
                           generation-1,
                           colony.mutationRate());
    y = entitieshold.cardinality();
    for(x=0;x<y;x++)  {
        colony2->Entities[x] = entitieshold.get();
    }
    colony2->setLastOperation("reproduce");


    State = REPRODUCEOBJECT_STATE_DONE;

    return colony2;
}



/******************************************************************************/
