/**  carapace.cc  **************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




changes log
when      who       what
4.28.99   Dan       Creation

*******************************************************************************/

#include <unistd.h>

#include "../carapace/carapace.h"

carapace_o::carapace_o()  {}

carapace_o::~carapace_o()  {}




/******************************************************************************/
