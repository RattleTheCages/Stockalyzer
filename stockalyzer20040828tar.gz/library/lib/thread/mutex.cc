/**  mutex.cc  *****************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




changes log
Date      who     what
4.29.99   Dan     Creation.

*******************************************************************************/


#include <errno.h>

#include "../../lib/thread/mutex.h"


mutex_o::mutex_o()  {
    if(::pthread_mutex_init(&Mutex,NULL))  {
        ((error_o*)this)->thread(errno);
        return;
    }

    if(::pthread_cond_init(&ConditionVariable,NULL))  {
        ((error_o*)this)->thread(errno);
        return;
    }
}

mutex_o::mutex_o(const char* name)  {
    ObjectName = name;

    if(::pthread_mutex_init(&Mutex,NULL))  {
        ((error_o*)this)->thread(errno);
        return;
    }

    if(::pthread_cond_init(&ConditionVariable,NULL))  {
        ((error_o*)this)->thread(errno);
        return;
    }
}

mutex_o::~mutex_o()  {
    if(::pthread_mutex_destroy(&Mutex))  {
        ((error_o*)this)->thread(errno);
        return;
    }
    if(::pthread_cond_destroy(&ConditionVariable))  {
        ((error_o*)this)->thread(errno);
        return;
    }
}


int mutex_o::lock(const char* func)  {
    if(::pthread_mutex_lock(&Mutex))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}

int mutex_o::lock()  {
    if(::pthread_mutex_lock(&Mutex))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}

int mutex_o::unlock()  {
    if(::pthread_mutex_unlock(&Mutex))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}

int mutex_o::unlock(const char* func)  {
    if(::pthread_mutex_unlock(&Mutex))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}

int mutex_o::wait(const char* func)  {
    if(::pthread_cond_wait(&ConditionVariable,&Mutex))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}

int mutex_o::wait(mutex_o& mutex,const char* func)  {
    if(::pthread_cond_wait(&ConditionVariable,&mutex.Mutex))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}

int mutex_o::broadcast(const char* func)  {
    if(::pthread_cond_broadcast(&ConditionVariable))  {
        ((error_o*)this)->thread(errno);
    }
    return error();
}


/******************************************************************************/
