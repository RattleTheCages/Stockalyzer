/**  dlist.h  ******************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




    Double-linked List Object Template.

    This list is not thread safe.  For thread safe memory objects see the
    memory directory.



changed log
date
05.22.04  Dan    Created.

*******************************************************************************/


#ifndef DLISTTEMPLATE_API
#define DLISTTEMPLATE_API

#ifndef NULL
#define NULL 0
#endif


template<class o> class dlistPouch_o  {
  private:
public:
    o*                  object;
    dlistPouch_o<o>* next;
    dlistPouch_o<o>* prev;

  public:
    dlistPouch_o();                                       // Default constructor.
    dlistPouch_o(const dlistPouch_o<o>&);                 // Copy constructor.
    dlistPouch_o(o*);                                     // Store this object.
   ~dlistPouch_o();                                       // Default destructor.
    dlistPouch_o<o>& operator = (const dlistPouch_o<o>&); // Assignment operator.
};

template<class o> class dlist_o  {
  private:
    dlistPouch_o<o>*  First;
    dlistPouch_o<o>*  Last;
    dlistPouch_o<o>*  Current;

    unsigned int      Cardinal;

  public:   
    dlist_o();                                            // Default constructor.
    dlist_o(const dlist_o<o>&);                           // Copy constructor.
   ~dlist_o();                                            // Default destructor.
    dlist_o<o>& operator = (const dlist_o<o>&);           // Assignment operator.

    void            put(o*);         // Places the given object at the tail of
                                     // the list.
    o*              get();           // Returns the object at the head of the
                                     // list and removes the object from the
                                     // list.
    o*              first();         // Returns the first object in the list
                                     // and does not remove the object.
    o*              next();          // Returns the next object on the list,
                                     // after calling first, returns successive
                                     // list objects.  Does not remove the
                                     // objects from the list.
    o*              prev();          // Returns the previous object on the list.
                                     // Does not remove the objects from the list.

    unsigned int    cardinality()     const;
                                     // Returns the number of objects in
                                     // the list.
};


/******************************************************************************/


template<class o> inline dlistPouch_o<o>::dlistPouch_o()  {
    object = NULL;
    next   = NULL;
    prev   = NULL;
}

template<class o> inline dlistPouch_o<o>::dlistPouch_o(o* obj)  {
    object = obj;
    next   = NULL;
    prev   = NULL;
}

template<class o> inline dlistPouch_o<o>::~dlistPouch_o()  {}

template<class o> inline dlist_o<o>::dlist_o()  {
    First = Last = Current  = NULL;
    Cardinal                = 0;
}

template<class o> inline dlist_o<o>::~dlist_o()  {
    dlistPouch_o<o>* lp;
    while(First)  {
        lp    = First;
        First = First->next;
        //delete lp->object;
        delete lp;
    }
}

template<class o> inline void dlist_o<o>::put(o* obj)  {
    dlistPouch_o<o>* lp = new dlistPouch_o<o>(obj);
    dlistPouch_o<o>* plp = Last;

    if(!Last)  First = Last = lp;
    else  {
        Last->next = lp;
        Last = lp;
//        Last->prev = plp;
    }
    Cardinal++;
}

template<class o> inline o* dlist_o<o>::get()  {
    dlistPouch_o<o>* lp;
    o*                  obj;

    lp = First;
    if(First)  {
        First = First->next;
        if(!First)  Last = First;
        Cardinal--;
    }

    if(lp)  {
        obj = lp->object;
        delete lp;
    }
    else  obj = NULL;
    return obj;
}

template<class o> inline unsigned int dlist_o<o>::cardinality() const  {
    return Cardinal;
}

template<class o> inline o* dlist_o<o>::first()  {
    Current = First;
    if(Current)  return First->object;
    return NULL;
}

template<class o> inline o* dlist_o<o>::next()  {
    if(Current)  Current = Current->next;
    if(Current)  return Current->object;
    return NULL;
}

template<class o> inline o* dlist_o<o>::prev()  {
    if(Current)  Current = Current->prev;
    if(Current)  return Current->object;
    return NULL;
}



#endif

/******************************************************************************/
