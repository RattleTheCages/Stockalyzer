/**  sysinfo.cc  ***************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman




changes log
Date      who       what
04.29.99  Dan       Creation.
07.14.04  Dan       Added.  Methods for time.
07.27.04  Dan       Added.  Method for day of week.
08.24.04  Dan       Added.  Methods currentDate,currentTime.

*******************************************************************************/


#include <unistd.h>
#include <time.h>
#include "../../lib/other/sysinfo.h"

sysinfo_o::sysinfo_o()  {
    NumberOfCpus                 = 1;
    ThreadCeiling                = 512;

    Pid    = ::getpid();
}

sysinfo_o::~sysinfo_o()  {}

/*
void sysinfo_o::currentTime(string_o& s) const  {
    char*  b;
    time_t time;
    time = ::time(NULL);
    b = ::ctime(&time);
    s << b;
    s.transpose("\n","\0");
}
*/

int sysinfo_o::currentYear() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_year+1900;
}

int sysinfo_o::currentMonth() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_mon;
}

int sysinfo_o::currentDay() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_mday;
}

int sysinfo_o::currentDayOfWeek() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_wday;
}

int sysinfo_o::currentHour() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_hour;
}

int sysinfo_o::currentMinute() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_min;
}

int sysinfo_o::currentSecond() const  {
    time_t time;
    struct tm* t;
    time = ::time(NULL);
    t = ::localtime(&time);
    return t->tm_sec;
}

int sysinfo_o::currentDate() const  {
    int date;

    date = currentYear() * 10000;
    date += (currentMonth()+1) * 100;
    date += currentDay();

    return date;
}

int sysinfo_o::currentTime() const  {
    int time;

    time = currentHour() * 10000;
    time += currentMinute() * 100;
    time += currentSecond();

    return time;
}


/******************************************************************************/
