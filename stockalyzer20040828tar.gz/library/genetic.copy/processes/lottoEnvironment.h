/**  lottoEnvironment.h  *******************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman



    Lotto Environment Object.


changes log
when      who      what
5.17.98   Dan      Creation of orignal lottosort executable this object
                   replaces.
5.20.00   Dan      Creation.
5.6.00    Dan      Added:    Program Counter and Winning Pick Set Index
                             registers.


*******************************************************************************/


#ifndef LOTTOENVIRONMENTOBJECT_API
#define LOTTOENVIRONMENTOBJECT_API

#include "../../lib/string/string.h"
#include "../entity/entity.h"
#include "../processes/lottoWinningPickSets.h"


#define LOTTOENVIRONMENTOBJECT_DEFAULT_PICKS_PER_SET                 6
#define LOTTOENVIRONMENTOBJECT_DEFAULT_MIN_PICK_NUMBER_INCLUSIVE     1 
#define LOTTOENVIRONMENTOBJECT_DEFAULT_MAX_PICK_NUMBER_INCLUSIVE    42
#define LOTTOENVIRONMENTOBJECT_NUMBER_OF_REGISTERS                   4

#define LOTTOENVIRONMENTOBJECT_OBJECT   "lottoEnvironment_o"
#define LOTTOENVIRONMENTOBJECT_STATE    "state"

#define LOTTOENVIRONMENTOBJECT_STATE_VOID   0
#define LOTTOENVIRONMENTOBJECT_STATE_CLEAR  1
#define LOTTOENVIRONMENTOBJECT_STATE_NORMAL 2


class lottoEnvironment_o  {

  private:
    short int   State;

    long int    ProgramCounter;
    long int    WinningPickSetIndex;
    char        inst[142];
    int*        rs;              //Register Set.
    int*        rsPick;
    int*        rsWinningPick;
    int*        rsRandom;

    int         Score;
    short int   MinPickInclusive;
    short int   MaxPickInclusive;
    short int   PicksPerSet;
    short int   NumberOfRegisters;

  protected:
    lottoWinningPickSets_o* lottoWinningPickSets;

    int executeInstruction(chromosome_o&);


  public:
    lottoEnvironment_o();                               // Default constructor.
    lottoEnvironment_o(const lottoEnvironment_o&);      // Copy constructor.
   ~lottoEnvironment_o();                               // Default destuctor.
    lottoEnvironment_o& operator = (const lottoEnvironment_o&);
                                                        // Assignment operator.
    void            operator >> (string_o&) const;      // OLP representation.
    void            operator << (const char*);          // Reconstruct.
    void            clear();
    int             state()                 const;


    int execute(const entity_o&);


    int picksPerSet() const;
    int minPickInclusive() const;
    int maxPickInclusive() const;
};


/******************************************************************************/

inline int lottoEnvironment_o::state() const  {
    return (int)State;
}

inline int lottoEnvironment_o::picksPerSet() const  {
    return (int)PicksPerSet;
}

inline int lottoEnvironment_o::minPickInclusive() const  {
    return (int)MinPickInclusive;
}

inline int lottoEnvironment_o::maxPickInclusive() const  {
    return (int)MaxPickInclusive;
}


#endif

/******************************************************************************/
