/**  lottoWinningPickSets.cc  **************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman





changes log
when      who      what
5.17.98   Dan      Creation of orignal lottosort executable this object
                   replaces.
5.20.00   Dan      Creation.


*******************************************************************************/


#include "../processes/lottoWinningPickSets.h"

lottoWinningPickSets_o::lottoWinningPickSets_o()  {
    long int x;

    State = LOTTOWINNINGPICKSETSOBJECT_STATE_CLEAR;
    NumberOfPicksPerSet =LOTTOWINNINGPICKSETSOBJECT_DEFAULT_PICKS_PER_SET;
    NumberOfWinningPickSets = LOTTOWINNINGPICKSETSOBJECT_DEFAULT_PICKS_PER_SET;
    Picks = 0;



/***The Winning Number Picks should be loaded dynamically. For now, load here.*/

    NumberOfWinningPickSets = 7;
    Picks = new int*[NumberOfWinningPickSets];
    for(x=0;x<NumberOfWinningPickSets;x++)
        Picks[x] = new int[LOTTOWINNINGPICKSETSOBJECT_DEFAULT_PICKS_PER_SET];
        //Picks[x] = new int[19];

    Picks[0][0] = 1;  Picks[0][1] = 2;  Picks[0][2] = 3;
    Picks[0][3] = 4;  Picks[0][4] = 5;  Picks[0][5] = 6;

    Picks[1][0] = 7;  Picks[1][1] = 8;  Picks[1][2] = 9;
    Picks[1][3] = 10; Picks[1][4] = 11; Picks[1][5] = 12;


    Picks[2][0] = 13; Picks[2][1] = 14; Picks[2][2] = 15;
    Picks[2][3] = 16; Picks[2][4] = 17; Picks[2][5] = 18;

    Picks[3][0] = 19; Picks[3][1] = 20; Picks[3][2] = 21;
    Picks[3][3] = 22; Picks[3][4] = 23; Picks[3][5] = 24;

    Picks[4][0] = 25; Picks[4][1] = 26; Picks[4][2] = 27;
    Picks[4][3] = 28; Picks[4][4] = 29; Picks[4][5] = 30;

    Picks[5][0] = 31; Picks[5][1] = 32; Picks[5][2] = 33;
    Picks[5][3] = 34; Picks[5][4] = 35; Picks[5][5] = 36;

    Picks[6][0] = 37; Picks[6][1] = 38; Picks[6][2] = 39;
    Picks[6][3] = 40; Picks[6][4] = 41; Picks[6][5] = 42;


    State = LOTTOWINNINGPICKSETSOBJECT_STATE_NORMAL;
}


lottoWinningPickSets_o::~lottoWinningPickSets_o()  {
    if(Picks)  delete Picks;
}

int lottoWinningPickSets_o::operator[](int)  {
return -1;//!!!
}

int lottoWinningPickSets_o::set(int x, int y)  {
    if(x < 0 || y < 0)  return -1;
    if(x >= NumberOfWinningPickSets)  return -1;
    if(y >= NumberOfPicksPerSet)  return -1;
    return Picks[x][y];
}


/******************************************************************************/
