/**  lottoEnvironment.cc  ******************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman





changes log
when      who      what
5.17.98   Dan      Creation of orignal lottosort executable this object
                   replaces.
5.20.00   Dan      Creation.
6.5.00    Dan      Added first instruction: add r1 = r1 + r2.


*******************************************************************************/


#include "../../lib/log/log.h"
#include "../../lib/error/error.h"
#include "../../lib/other/rand.h"
#include "../processes/lottoEnvironment.h"

extern log_o log;
extern rand_o rndm;

lottoEnvironment_o::lottoEnvironment_o()  {
    Score = 0;
    State = LOTTOENVIRONMENTOBJECT_STATE_CLEAR;
    PicksPerSet = LOTTOENVIRONMENTOBJECT_DEFAULT_PICKS_PER_SET;
    NumberOfRegisters = LOTTOENVIRONMENTOBJECT_NUMBER_OF_REGISTERS;
    MinPickInclusive = LOTTOENVIRONMENTOBJECT_DEFAULT_MIN_PICK_NUMBER_INCLUSIVE;
    MaxPickInclusive = LOTTOENVIRONMENTOBJECT_DEFAULT_MAX_PICK_NUMBER_INCLUSIVE;


    ProgramCounter = 0;
    WinningPickSetIndex = 0;
    rs = new int[PicksPerSet];
    rsPick = new int[PicksPerSet];
    rsWinningPick = new int[PicksPerSet];
    rsRandom = new int[PicksPerSet];

    clear();

    lottoWinningPickSets = new lottoWinningPickSets_o;//!!
}

lottoEnvironment_o::~lottoEnvironment_o()  {}

void lottoEnvironment_o::clear()  {
    long int x;

    ProgramCounter = 0;
    WinningPickSetIndex = 0;

    for(x=0;x<picksPerSet();x++)  {
        rs[x] = 0;
        rsPick[x] = 0;
        rsWinningPick[x] = 0;
        rsRandom[x] = 0;
    }
    for(x=0;x<44;x++)  {//!!
        inst[x] = 0;
    }
}


int lottoEnvironment_o::execute(const entity_o& entity)  {
    string_o message;
    int rt = 0;
    long int w = 0;
    long int x = 0;
    long int y = 0;
    long int z = 0;
    long int instPerPick = 0;
    long int geneindex   = 0;
    chromosome_o* chromosome;


if(!lottoWinningPickSets)  {
    (message = "");
    message << "lottoEnviroment_o: Null lottoWinningPickSets object.";
    ::log.error(message);
    State = LOTTOENVIRONMENTOBJECT_STATE_VOID;
    return ERROR_FAIL;
}

if(entity.numberOfChromosomes() < picksPerSet())  {
    (message = "") << "lottoEnvironment_o: Insufficient chromosomes, ";
    message << picksPerSet() << " required.";
    ::log.error(message);
    State = LOTTOENVIRONMENTOBJECT_STATE_VOID;
    return ERROR_FAIL;
}

if(lottoWinningPickSets->numberOfPicksPerSet() != picksPerSet())  {
    (message = "") << "lottoEnvironment_o: Number of winning picks per set is not ";
    message << "equal to picksPerSet(): ";
    message << lottoWinningPickSets->numberOfPicksPerSet() << ",";
    message << picksPerSet() << ".";
    ::log.error(message);
    State = LOTTOENVIRONMENTOBJECT_STATE_VOID;
    return ERROR_FAIL;
}

for(y=0;y<picksPerSet();y++)  {
  ProgramCounter = 0;
  WinningPickSetIndex = 0;
  chromosome = entity.Chromosomes[y];
  for(z=0;z<picksPerSet();z++)  {
    rs[z] = rndm.i(maxPickInclusive()-minPickInclusive())+minPickInclusive();
    rsPick[z]= rndm.i(maxPickInclusive()-minPickInclusive())+minPickInclusive();
  }


  if(::log.debug(2))  {
    (message = "") << "lottoEnvironment_o: Executing chromosome " << y;
    message << " total genes program length ";
    message << chromosome->numberOfGenes() << ".";
    ::log << message;
  }

  
  while(1)  {

        for(z=0;z<picksPerSet();z++)  {
//          rsWinningPick[z] = lottoWinningPickSets[WinningPickSetIndex][z];
            rsWinningPick[z] = lottoWinningPickSets->set(WinningPickSetIndex,z);

            rsRandom[z] = rndm.i(maxPickInclusive()-minPickInclusive())+minPickInclusive();
        }


        rt = executeInstruction(*chromosome);


//rt = -1;

        if(::log.debug(4))  {
            (message = "") << "Registers:\n";
            message << "pc " << ProgramCounter << ", wi ";
            message << WinningPickSetIndex << ", chromosome " << y;
            message << ", rt ";
            message << rt;
            message << "\n";
            message << "rs";
            for(z=0;z<picksPerSet();z++) message << ' ' << rs[z];
            message << ", rsp";
            for(z=0;z<picksPerSet();z++) message << ' ' << rsPick[z];
            message << ", rsw";
            for(z=0;z<picksPerSet();z++) message << ' ' << rsWinningPick[z];
            message << ", rsr";
            for(z=0;z<picksPerSet();z++) message << ' ' << rsRandom[z];
            message << ".";
            ::log << message;
        }

        if(rt < 0)  break;

  }
}
}

int lottoEnvironment_o::executeInstruction(chromosome_o& chromosome)  {
    string_o message;
    char     i;
    long int x;
    long int y;
    int* r1;
    int* r2;
    int e;
    int e1;
    int e2;
    int branch = 0;


    if(::log.debug(3))  {
        (message = "") << "lottoEnvironment_o: Executing instruction `";
            message << chromosome[ProgramCounter];
        message << "'.";
        ::log << message;
    }


    inst[0] = chromosome[ProgramCounter];
    ProgramCounter++;
    if(ProgramCounter >= chromosome.numberOfGenes())  return -1;

    switch(inst[0])  {


        case 'a':
        case 'm':
            if(::log.debug(22))  {
                (message = "") << "inst: noop";
                ::log << message;
            }
            break;




/******************************************************************************/
/******************************************************************************/

case 'b':
case 'n':
    if(::log.debug(22))  {
        (message = "") << "inst : add r1 = r1 + r2, element";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }


    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e = inst[3] % PicksPerSet;

    r1[e] = r1[e] + r2[e];

    while(r1[e] < MinPickInclusive)
        r1[e] = r1[e] + (MaxPickInclusive-MinPickInclusive);
    while(r1[e] > MaxPickInclusive)
        r1[e] = r1[e] - (MaxPickInclusive-MinPickInclusive);



    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " = ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " + ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "  element " << e << ".";
    
        ::log << message;
    }

    break;


/******************************************************************************/
/******************************************************************************/


case 'c':
case 'o':
    if(::log.debug(22))  {
        (message = "") << "inst : subtract r1 = r1 - r2, element";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }


    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e = inst[3] % PicksPerSet;

    r1[e] = r1[e] - r2[e];

    while(r1[e] < MinPickInclusive)
        r1[e] = r1[e] + (MaxPickInclusive-MinPickInclusive);
    while(r1[e] > MaxPickInclusive)
        r1[e] = r1[e] - (MaxPickInclusive-MinPickInclusive);


    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " = ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " - ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "  element " << e << ".";
    
        ::log << message;
    }
            
    break;



/******************************************************************************/
/******************************************************************************/
 

case 'd':
case 'p':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : multipy r1 = r1 * r2, element";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }

    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e = inst[3] % PicksPerSet;

    r1[e] = r1[e] * r2[e];

    r1[e] = (r1[e] % MaxPickInclusive) + MinPickInclusive;


    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " = ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " * ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "  element " << e << ".";
    
        ::log << message;
    }
            
    break;
*/



/******************************************************************************/
/******************************************************************************/

case 'e':
case 'q':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : divide r1 = r1 / r2, element";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }

    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e = inst[3] % PicksPerSet;

    if(r2[e] != 0)  r1[e] = r1[e] / r2[e];

    r1[e] = (r1[e] % MaxPickInclusive) + MinPickInclusive;


    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " = ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " / ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "  element " << e << ".";
    
        ::log << message;
    }
            
    break;
*/



/******************************************************************************/
/******************************************************************************/

case 'f':
case 'r':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : modulus r1 = r1 mod r2, element";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }

    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e = inst[3] % PicksPerSet;

    if(r2[e] != 0)  r1[e] = r1[e] % r2[e];

    r1[e] = (r1[e] % MaxPickInclusive) + MinPickInclusive;


    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " = ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " % ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "  element " << e << ".";
    
        ::log << message;
    }
            
    break;
*/



/******************************************************************************/
/******************************************************************************/

case 'g':
case 's':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : load r1 = gene value";
        ::log << message;
    }

    for(x=0;x<2;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }


    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    e = inst[2];

    r1[e] = e;

    r1[e] = (r1[e] % MaxPickInclusive) + MinPickInclusive;


    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << " = ";
        message << "  gene value " << e << ".";
    
        ::log << message;
    }
            
    break;
*/



/******************************************************************************/
/******************************************************************************/

case 'h':
case 't':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : move r1[element1] = r2[element2]";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }

    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e1 = (inst[3] / PicksPerSet) % PicksPerSet;
    e2 = (inst[3] % PicksPerSet) % PicksPerSet;

    r1[e1] = r2[e2];

    r1[e1] = (r1[e1] % MaxPickInclusive) + MinPickInclusive;


    if(::log.debug(22))  {
        (message = "") << "parse: ";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << "[" << e1 << "]";
        message << " = ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "[" << e2 << "]";
    
        ::log << message;
    }
            
    break;
*/



/******************************************************************************/
/******************************************************************************/

case 'i':
case 'u':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : branch r1, element";
        ::log << message;
    }

    for(x=0;x<2;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }

    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    e = inst[2] % PicksPerSet;
    if(::log.debug(22))  {
        (message = "") << "parse: pc before " << ProgramCounter << ".";
        ::log << message;
    }


    branch = r1[e];
    if(branch == 0)  branch = 1;

    for(x=0;x<branch;x++)  {
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }


    if(::log.debug(22))  {
        (message = "");
        message << "pc after " << ProgramCounter << ".";
        ::log << message;
    }


    break;
*/



/******************************************************************************/
/******************************************************************************/

case 'j':
case 'v':
/*
    if(::log.debug(22))  {
        (message = "") << "inst : conditional branch if(r1 = r2, element) branch";
        ::log << message;
    }

    for(x=0;x<3;x++)  {
        inst[x+1] = chromosome[ProgramCounter];
        ProgramCounter++;
        if(ProgramCounter >= chromosome.numberOfGenes())  return -1;
    }

    if(inst[1] % 2 == 0)  r1 = rs;
    if(inst[1] % 2 == 1)  r1 = rsPick;
    if(inst[2] % NumberOfRegisters == 0)  r2 = rs;
    if(inst[2] % NumberOfRegisters == 1)  r2 = rsPick;
    if(inst[2] % NumberOfRegisters == 2)  r2 = rsWinningPick;
    if(inst[2] % NumberOfRegisters == 3)  r2 = rsRandom;
    e1 = (inst[3] / PicksPerSet) % PicksPerSet;
    e2 = (inst[3] % PicksPerSet) % PicksPerSet;


    if(r1[e1] == r2[e2])  branch = (int)((inst[1] - 'a') % 24);
    else branch = 0;

    if(branch == 0)  branch = 1;

    ProgramCounter = ProgramCounter + branch;
    if(ProgramCounter >= chromosome.numberOfGenes())  return -1;


    if(::log.debug(22))  {
        (message = "") << "parse: if(";
        if(inst[1] % 2 == 0)  message << "rs";
        if(inst[1] % 2 == 1)  message << "rsPick";
        message << "[" << e1 << "]";
        message << " = ";
        if(inst[2] % NumberOfRegisters == 0)  message << "rs";
        if(inst[2] % NumberOfRegisters == 1)  message << "rsPick";
        if(inst[2] % NumberOfRegisters == 2)  message << "rsWinningPick";
        if(inst[2] % NumberOfRegisters == 3)  message << "rsRandom";
        message << "[" << e2 << "]";
        message << ")  branch " << (int)((inst[1] - 'a') % 10);
    
        ::log << message;
    }
            
    break;
*/



/******************************************************************************/
/******************************************************************************/

break;//!!!!
case 'k':
case 'w':
    if(::log.debug(22))  {
        (message = "") << "inst : increment winning pick set index register";
        ::log << message;
    }

    WinningPickSetIndex++;
    if(WinningPickSetIndex >= lottoWinningPickSets->numberOfWinningPickSets())
        WinningPickSetIndex = 0;

    break;



/******************************************************************************/
/******************************************************************************/
        default:
            if(::log.debug(22))  {
                (message = "") << "inst: unknown";
                ::log << message;
            }
            break;
    }


//  return branch;
return 0;

}

/******************************************************************************/
