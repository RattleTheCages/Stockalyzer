/**  sendrecv.cc  **************************************************************

12.31.1999  Performance Server Library v2.000  Daniel Huffman

Copyright Daniel Huffman 1999





changes log
when      who       what
4.28.99   Dan       Creation

*******************************************************************************/

//#include <iostream.h>///!!!!!!!!!!!!!!!!!!!!!

#include <memory.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
//#include <sys/ioctl.h>
//#include <signal.h>

#include "../../lib/error/error.h"
#include "../telenet/sendrecv.h"


sendrecv_o::sendrecv_o()  {}

sendrecv_o::~sendrecv_o()  {}

long int sendrecv_o::send(int S,const string_o& ss)  {
    long int nsend = 0;

    if(ss.length() < 1)  return 0;
    ((error_o*)this)->clear();

    //if(  ::fcntl(S,F_SETFL, O_NONBLOCK) == -1)  {
    if(  ::fcntl(S,F_SETFL,(::fcntl(S,F_GETFL,NULL) ^ O_NONBLOCK)) == -1)  {
        ((error_o*)this)->socket(errno);
    }

void* optval = new void*;
//int* optlen = new int;
socklen_t* optlen = new socklen_t;

    getsockopt(S,SOL_SOCKET,SO_KEEPALIVE,optval,optlen);
//cout<<"KKKKKK"<<*(int*)optval<<endl;

*(int*)optval = 0;

    setsockopt(S,SOL_SOCKET,SO_KEEPALIVE,optval,sizeof(void*));

//cout<<"sendrecv_o: sending " << ss.length() << " bytes.";

    while(nsend < ss.length())  {
        nsend += send(S,(ss.string()+nsend),(ss.length()-nsend));
//cout<<"sendrecv_o: sent " << nsend << " bytes.";

    }

    return  nsend;
}

#define SENDRECVOBJECT_RECV_BUFF_SIZE 16384
long int sendrecv_o::recv(int S,string_o& rs)  {
    char          buf[SENDRECVOBJECT_RECV_BUFF_SIZE];
    long int      thisrecv;
    long int      nrecv;
    long int      sflags;
    long int      retry = 4096L;

    ((error_o*)this)->clear();

    sflags =::fcntl(S,F_GETFL,NULL);
    if(  ::fcntl(S,F_SETFL, O_NONBLOCK) == -1)  {
    //if(  ::fcntl(S,F_SETFL,(::fcntl(S,F_GETFL,NULL) ^ O_NONBLOCK)) == -1)  {
        ((error_o*)this)->socket(errno);
    }
    setsockopt(S,SOL_SOCKET,SO_KEEPALIVE,0,0);

    nrecv = 0;
    while(*(error_o*)this == ERROR_OK ||
          (*(error_o*)this == ERROR_THREAD_WOULD_BLOCK && nrecv == 0) ||
          (*(error_o*)this == ERROR_THREAD_INTERRUPTED && nrecv == 0))  {
        (void)::memset(buf,0,SENDRECVOBJECT_RECV_BUFF_SIZE);
::usleep(12);
        thisrecv = recv(S,buf,SENDRECVOBJECT_RECV_BUFF_SIZE-1);
if(thisrecv > 0)  {
        nrecv += thisrecv;
    //    rs << buf;
rs.fill(thisrecv,buf);
//cout<<"sendrecv_o: recv: "<<thisrecv<<"."<<endl;
}
else  {
        retry = retry - 1;
}
        if(retry < 1)  break;
    }
    

    if(*(error_o*)this == ERROR_OK &&
       ::fcntl(S,F_SETFL,sflags) == -1)  {
        ((error_o*)this)->socket(errno);
    }

    return nrecv;
}

long int sendrecv_o::recvC(int S,string_o& rs)  {
    char     buf[8192];
    long int      thisrecv;
    long int      nrecv;
    long int      sflags;
    long int      retry = 4096L;

    ((error_o*)this)->clear();

 //   sflags =::fcntl(S,F_GETFL,NULL);
    //if(  ::fcntl(S,F_SETFL, O_NONBLOCK) == -1)  {
/*
    if(  ::fcntl(S,F_SETFL,(::fcntl(S,F_GETFL,NULL) ^ O_NONBLOCK)) == -1)  {
        ((error_o*)this)->socket(errno);
    }
*/

    nrecv = 0;
    while(*(error_o*)this == ERROR_OK ||
          (*(error_o*)this == ERROR_THREAD_WOULD_BLOCK && nrecv == 0) ||
          (*(error_o*)this == ERROR_THREAD_INTERRUPTED && nrecv == 0))  {
        (void)::memset(buf,0,8192);
::usleep(4);
        thisrecv = recv(S,buf,8192);
if(thisrecv > 0)  {
        nrecv += thisrecv;
//        rs << buf;
rs.fill(thisrecv,buf);
}else{
        retry = retry - 1;
}
        if(retry < 1)  break;
    }
    

/*
    if(error == ERROR_OK &&
       ::fcntl(S,F_SETFL,sflags) == -1)  {
        ((error_o*)this)->socket(errno);
    }
*/

    return nrecv;
}

long int sendrecv_o::recv(int S,char* buf,long int size)  {
    long int    count;
    long int    nbytes;
    long int    ndata;

    ndata   = 0;
    count   = 0;

    while(count < size)  {
        nbytes = ::recv(S,(buf+count),size-count,0);
        if(nbytes == 0)  {
            ndata++;
            if(ndata > 2220)  {
                *(error_o*)this = ERROR_SOCKET_RECV_NO_DATA;
                return count;
            }
        }
        if(nbytes < 0)  {
            ((error_o*)this)->socket(errno);
            return count;
        }
        if(nbytes > 0)  count = count + nbytes;
    }
    return count;
}


//const int off = 0;
//#include <sys/ioctl.h>
//#include <signal.h>

long int sendrecv_o::send(int S,const char* buf,long int size)  {
    long int    count;
    long int    nbytes;
    long int    ndata;


    ndata   = 0;
    count   = 0;

//ioctl(S,SIGPIPE,&off);


//    while(count != size)  {
//::usleep(4);
        nbytes = ::send(S,buf,1,0);
        if(nbytes < 0)  {
            ((error_o*)this)->socket(errno);
            return count;
        }
        nbytes = ::send(S,(buf+count+1),size-count,0);
//cout<<"sendrecv_o: send: "<<nbytes<<"."<<endl;
/*
        if(nbytes == 0)  {
            ndata++;
            if(ndata > 2220)  {
                *(error_o*)this = ERROR_SOCKET_SEND_NO_DATA;
                return count;
            }
        }
        if(nbytes < 0)  {
            ((error_o*)this)->socket(errno);
            return count;
        }
        if(nbytes > 0)  count = count + nbytes;
*/
//    }
//    return count;
return nbytes;
}


int sendrecv_o::close(int s)  {

    ::close(s);
    while(::shutdown(s,2) < 0)  {
        if(errno != EINTR)  {
            ((error_o*)this)->socket(errno);
            ::close(s);
            return error();
        }
    }

    return error();
}


/******************************************************************************/
